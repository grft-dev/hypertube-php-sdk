<?php

declare(strict_types=1);

namespace HypertubePhpSdk;

use HypertubePhpSdk\configuration\ConfigPriority;
use HypertubePhpSdk\configuration\ConfigSourceResolver;
use HypertubePhpUtils\messagehelper\MessageHelper;
use HypertubePhpUtils\connectiondata\Http2ConnectionData;
use HypertubePhpUtils\connectiondata\InMemoryConnectionData;
use HypertubePhpUtils\connectiondata\PluginConnectionData;
use HypertubePhpUtils\connectiondata\TcpConnectionData;
use HypertubePhpUtils\connectiondata\WsConnectionData;
use HypertubePhpUtils\UtilsConst;

final class RuntimeBridge
{
    private static bool $telemetryInitialized = false;

    private function __construct()
    {}

    public static function inMemory(): RuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new RuntimeFactory(new InMemoryConnectionData());
    }

    public static function tcp(TcpConnectionData $IConnectionData): RuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new RuntimeFactory($IConnectionData);
    }

    public static function plugin(PluginConnectionData $IConnectionData): RuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new RuntimeFactory($IConnectionData);
    }

    public static function webSocket(WsConnectionData $IConnectionData): RuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new RuntimeFactory($IConnectionData);
    }

    public static function http2(Http2ConnectionData $IConnectionData): RuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new RuntimeFactory($IConnectionData);
    }

    public static function withConfig(string $configSource): ConfigRuntimeFactory
    {
        self::ensureTelemetryInitialized();
        return new ConfigRuntimeFactory($configSource);
    }

    public static function activate(string $licenseKey): void
    {
        self::ensureTelemetryInitialized();
        UtilsConst::setLicenseKey($licenseKey);
    }

    public static function setConfigSource(string $configSource): void
    {
        self::ensureTelemetryInitialized();
        UtilsConst::setConfigSource($configSource);
    }

    public static function setWorkingDirectory(string $path): void
    {
        self::ensureTelemetryInitialized();
        UtilsConst::setWorkingDirectory($path);
    }

    public static function addConfig(ConfigPriority $configPriority, string $configSource): void
    {
        self::ensureTelemetryInitialized();
        ConfigSourceResolver::addConfigs($configPriority, $configSource);
    }

    public static function initializeRC(string $configName) : RuntimeContext
    {
        self::ensureTelemetryInitialized();
        return RuntimeContext::initializeRuntimeContext(ConfigSourceResolver::getConfig($configName));
    }

    private static function ensureTelemetryInitialized(): void
    {
        if (self::$telemetryInitialized) {
            return;
        }

        self::$telemetryInitialized = true;
        MessageHelper::getInstance()->sendMessageToAppInsights(
            'SdkMessage',
            'Hypertube SDK initialized'
        );
    }
}
