<?php

declare(strict_types=1);

namespace sdk;

use sdk\configuration\ConfigPriority;
use sdk\configuration\ConfigSourceResolver;
use utils\connectiondata\Http2ConnectionData;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\TcpConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\UtilsConst;

final class RuntimeBridge
{
    private function __construct()
    {}

    public static function inMemory(): RuntimeFactory
    {
        return new RuntimeFactory(new InMemoryConnectionData());
    }

    public static function tcp(TcpConnectionData $IConnectionData): RuntimeFactory
    {
        return new RuntimeFactory($IConnectionData);
    }

    public static function webSocket(WsConnectionData $IConnectionData): RuntimeFactory
    {
        return new RuntimeFactory($IConnectionData);
    }

    public static function http2(Http2ConnectionData $IConnectionData): RuntimeFactory
    {
        return new RuntimeFactory($IConnectionData);
    }

    public static function withConfig(string $configSource): ConfigRuntimeFactory
    {
        return new ConfigRuntimeFactory($configSource);
    }

    public static function activate(string $licenseKey): void
    {
        UtilsConst::setLicenseKey($licenseKey);
    }

    public static function setConfigSource(string $configSource): void
    {
        UtilsConst::setConfigSource($configSource);
    }

    public static function setWorkingDirectory(string $path): void
    {
        UtilsConst::setWorkingDirectory($path);
    }

    public static function addConfig(ConfigPriority $configPriority, string $configSource): void
    {
        ConfigSourceResolver::addConfigs($configPriority, $configSource);
    }

    public static function initializeRC(string $configName) : RuntimeContext
    {
        return RuntimeContext::initializeRuntimeContext(ConfigSourceResolver::getConfig($configName));
    }
}
