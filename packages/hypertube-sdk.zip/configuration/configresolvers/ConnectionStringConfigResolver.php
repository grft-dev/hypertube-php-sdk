<?php

namespace HypertubePhpSdk\configuration\configresolvers;

use InvalidArgumentException;
use HypertubePhpSdk\configuration\ConfigPriority;
use HypertubePhpSdk\configuration\Config;
use HypertubePhpSdk\configuration\ConfigsDictionary;
use HypertubePhpUtils\connectiondata\PluginConnectionData;
use HypertubePhpUtils\UtilsConst;


class ConnectionStringConfigResolver extends ConfigResolver
{
    /**
     * Parses configuration(s) from connection string format and adds them to ConfigsDictionary.
     * @param ConfigPriority $priority
     * @param string $connectionStringSource
     */
    public static function addConfigs(ConfigPriority $priority, string $connectionStringSource): void
    {
        if (empty(trim($connectionStringSource))) {
            throw new InvalidArgumentException('Connection string source cannot be null or empty.');
        }

        // Normalize line endings
        $normalized = str_replace(["\r\n", "\r"], "\n", $connectionStringSource);
        $lines = explode("\n", $normalized);

        foreach ($lines as $rawLine) {
            $line = trim($rawLine);
            if (empty($line)) continue;
            if (strpos($line, '#') === 0 || strpos($line, '//') === 0) continue; // allow comments

            if (stripos($line, 'licensekey') === 0) {
                self::setLicenseKey($line);
                continue;
            }

            try {
                $keyValues = self::parseKeyValues($line);

                $configName = $keyValues['name'] ?? null;
                $runtimeValue = $keyValues['runtime'] ?? null;

                if (empty(trim($configName ?? ''))) {
                    throw new InvalidArgumentException('Missing or empty config name.');
                }

                if (empty(trim($runtimeValue ?? ''))) {
                    throw new InvalidArgumentException('Missing or empty runtime.');
                }

                $runtimeName = self::tryParseRuntime($runtimeValue);
                $hostValue = $keyValues['host'] ?? null;
                $plugins = $keyValues['plugins'] ?? '';
                $plugin = $keyValues['plugin'] ?? '';
                $pluginValue = trim($plugin) !== '' ? $plugin : $plugins;
                $IConnectionData = trim($pluginValue) === ''
                    ? self::buildConnectionData($hostValue)
                    : new PluginConnectionData($hostValue, trim($pluginValue));
                $modules = $keyValues['module'] ?? '';
                if (trim($modules) === '') {
                    $modules = $keyValues['modules'] ?? '';
                }

                $statelessRaw = $keyValues['stateless'] ?? '';
                $isStateless = filter_var($statelessRaw, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? false;

                $config = new Config($runtimeName, $IConnectionData, $isStateless, $pluginValue, $modules);
                ConfigsDictionary::addConfig($configName, $priority, $config);
            } catch (InvalidArgumentException $ex) {
                echo "Failed to parse config line: '$line'. Reason: " . $ex->getMessage() . "\n";
                throw $ex;
            }
        }
    }

    private static function setLicenseKey(string $line): void
    {
        // Format: licenseKey=your-license-key
        $eq = strpos($line, '=');
        if ($eq > 0 && $eq < strlen($line) - 1) {
            $valuePortion = trim(substr($line, $eq + 1));

            // Cut at first ';' (in case someone appends extra tokens)
            $semicolon = strpos($valuePortion, ';');
            if ($semicolon !== false) {
                $valuePortion = trim(substr($valuePortion, 0, $semicolon));
            }

            // Cut at inline comment markers
            $hashIdx = strpos($valuePortion, '#');
            if ($hashIdx !== false) {
                $valuePortion = trim(substr($valuePortion, 0, $hashIdx));
            }
            $slashes = strpos($valuePortion, '//');
            if ($slashes !== false) {
                $valuePortion = trim(substr($valuePortion, 0, $slashes));
            }

            UtilsConst::setLicenseKey($valuePortion);
        }
    }

    private static function parseKeyValues(string $line): array
    {
        $result = [];
        $segments = explode(';', $line);

        foreach ($segments as $segmentRaw) {
            $segment = trim($segmentRaw);
            if (empty($segment)) continue;

            $eq = strpos($segment, '=');
            if ($eq === false || $eq <= 0 || $eq === strlen($segment) - 1) {
                echo "Ignoring malformed token '$segment' in line: $line\n";
                continue;
            }

            $key = strtolower(trim(substr($segment, 0, $eq)));
            $value = trim(substr($segment, $eq + 1));

            if (empty($key)) continue;

            // Last occurrence wins (allows overrides)
            $result[$key] = $value;
        }

        return $result;
    }
}
