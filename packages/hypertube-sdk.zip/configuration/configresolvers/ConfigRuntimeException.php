<?php

namespace HypertubePhpSdk\configuration\configresolvers;

use InvalidArgumentException;

/**
 * Thrown when the runtime of a configuration cannot be determined or is not supported.
 */
class ConfigRuntimeException extends InvalidArgumentException
{
}
