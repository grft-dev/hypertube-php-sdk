<?php

namespace HypertubePhpSdk\configuration\configresolvers;

use InvalidArgumentException;
use HypertubePhpSdk\configuration\Config;
use HypertubePhpSdk\configuration\ConfigPriority;
use HypertubePhpSdk\configuration\ConfigsDictionary;
use Symfony\Component\Yaml\Exception\ParseException;
use Symfony\Component\Yaml\Yaml;
use HypertubePhpUtils\connectiondata\PluginConnectionData;
use HypertubePhpUtils\UtilsConst;

class YamlConfigResolver extends ConfigResolver
{
    /**
     * Reads all configs from YAML string and adds them under given priority.
     * Requires symfony/yaml package (composer require symfony/yaml)
     * @param ConfigPriority $priority
     * @param string $yamlString
     */
    public static function addConfigs(ConfigPriority $priority, string $yamlString): void
    {
        if (empty(trim($yamlString))) {
            throw new InvalidArgumentException("YAML string cannot be null or empty.");
        }

        try {
            $data = Yaml::parse($yamlString);
        } catch (ParseException $ex) {
            throw new InvalidArgumentException("Failed to parse YAML: " . $ex->getMessage(), 0, $ex);
        }

        if (!is_array($data)) {
            throw new InvalidArgumentException("Root YAML node must be a mapping (object).");
        }

        // Handle license key
        $licenseKey = self::getPropertyIgnoreCase($data, 'licenseKey');
        if (is_string($licenseKey)) {
            UtilsConst::setLicenseKey(trim($licenseKey));
        }

        // Get configurations
        $configurations = self::getPropertyIgnoreCase($data, 'configurations');
        if (!is_array($configurations)) {
            throw new InvalidArgumentException("YAML must contain 'configurations' mapping.");
        }

        foreach ($configurations as $configName => $cfg) {
            if (!is_string($configName) || empty(trim($configName))) {
                echo "Skipping entry with empty config name.\n";
                continue;
            }

            if (!is_array($cfg)) {
                echo "Skipping '$configName': value is not a mapping.\n";
                continue;
            }

            try {
                $runtimeValue = self::getRequiredString($cfg, 'runtime');
                $runtimeName = self::tryParseRuntime($runtimeValue);

                $host = self::getOptionalString($cfg, 'host');
                $plugin = self::getOptionalString($cfg, 'plugin');
                $plugins = self::getOptionalString($cfg, 'plugins');
                $pluginValue = trim($plugin) !== '' ? $plugin : $plugins;
                $IConnectionData = trim($pluginValue) === ''
                    ? self::buildConnectionData($host)
                    : new PluginConnectionData($host, trim($pluginValue));

                $isStateless = self::parseOptionalStateless($cfg);
                $modules = self::getOptionalString($cfg, 'module');
                if (trim($modules) === '') {
                    $modules = self::getOptionalString($cfg, 'modules');
                }

                $config = new Config($runtimeName, $IConnectionData, $isStateless, $pluginValue, $modules);
                ConfigsDictionary::addConfig($configName, $priority, $config);
            } catch (\Exception $ex) {
                echo "Failed to add config '$configName': " . $ex->getMessage() . "\n";
            }
        }
    }

    private static function getRequiredString(array $mapping, string $key): string
    {
        $value = self::getPropertyIgnoreCase($mapping, $key);
        if (!is_string($value) || empty(trim($value))) {
            throw new InvalidArgumentException("Missing or invalid '$key' property.");
        }
        return trim($value);
    }

    private static function getOptionalString(array $mapping, string $key): string
    {
        $value = self::getPropertyIgnoreCase($mapping, $key);
        if (is_string($value)) {
            return $value;
        }
        return '';
    }

    private static function parseOptionalStateless(array $cfg): bool
    {
        $v = self::getPropertyIgnoreCase($cfg, 'stateless');
        if ($v === null) {
            return false;
        }
        if (is_bool($v)) {
            return $v;
        }
        if (is_string($v)) {
            return strcasecmp(trim($v), 'true') === 0;
        }

        return false;
    }
}
