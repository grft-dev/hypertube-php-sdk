<?php

namespace HypertubePhpSdk\configuration\configresolvers;

use Exception;
use InvalidArgumentException;
use HypertubePhpSdk\configuration\Config;
use HypertubePhpSdk\configuration\ConfigPriority;
use HypertubePhpSdk\configuration\ConfigsDictionary;
use HypertubePhpUtils\connectiondata\PluginConnectionData;
use HypertubePhpUtils\UtilsConst;

class JsonConfigResolver extends ConfigResolver
{
    /**
     * Reads all configs from JSON and adds them under given priority.
     */
    public static function addConfigs(ConfigPriority $priority, array $jsonObject): void
    {
        if (empty($jsonObject)) {
            throw new InvalidArgumentException('Root JSON element must be an object.');
        }

        // Handle license key
        $licenseKey = self::getPropertyIgnoreCase($jsonObject, 'licenseKey');
        if (is_string($licenseKey)) {
            UtilsConst::setLicenseKey(trim($licenseKey));
        }

        // Get configurations
        $configurations = self::getPropertyIgnoreCase($jsonObject, 'configurations');
        if (!is_array($configurations)) {
            throw new InvalidArgumentException("JSON must contain 'configurations' object.");
        }

        foreach ($configurations as $configName => $cfg) {
            try {
                if (!is_array($cfg)) {
                    throw new InvalidArgumentException("Configuration value must be an object.");
                }

                $runtimeValue = self::getOptionalString($cfg, 'runtime');
                $runtimeName = self::resolveRuntime($runtimeValue, (string) $configName);

                $host = self::getOptionalString($cfg, 'host');
                $plugin = self::getOptionalString($cfg, 'plugin');
                $plugins = self::getOptionalString($cfg, 'plugins');
                $pluginValue = trim($plugin) !== '' ? $plugin : $plugins;
                $IConnectionData = trim($pluginValue) === ''
                    ? self::buildConnectionData($host)
                    : new PluginConnectionData($host, trim($pluginValue));

                $isStateless = self::isStatelessStringTrue($cfg);
                $modules = self::getOptionalString($cfg, 'module');
                if (trim($modules) === '') {
                    $modules = self::getOptionalString($cfg, 'modules');
                }

                $config = new Config($runtimeName, $IConnectionData, $isStateless, $pluginValue, $modules);
                ConfigsDictionary::addConfig($configName, $priority, $config);
            } catch (ConfigRuntimeException $ex) {
                throw $ex;
            } catch (Exception $ex) {
                echo "Failed to add config '$configName': " . $ex->getMessage() . "\n";
            }
        }
    }

    private static function getRequiredString(array $obj, string $property): string
    {
        $value = self::getPropertyIgnoreCase($obj, $property);
        if (!is_string($value)) {
            throw new InvalidArgumentException("Missing or invalid '$property' property.");
        }

        $value = trim($value);
        if (empty($value)) {
            throw new InvalidArgumentException("Property '$property' cannot be empty.");
        }

        return $value;
    }

    private static function getOptionalString(array $obj, string $property): string
    {
        $value = self::getPropertyIgnoreCase($obj, $property);
        if (is_string($value)) {
            return $value;
        }
        // Object values (e.g. plugin config) are passed on as raw JSON.
        if (is_array($value) || is_object($value)) {
            $encoded = json_encode($value, JSON_UNESCAPED_SLASHES);
            return $encoded === false ? '' : $encoded;
        }
        return '';
    }

    private static function isStatelessStringTrue(array $cfg): bool
    {
        $value = self::getPropertyIgnoreCase($cfg, 'stateless');
        if (is_bool($value)) {
            return $value;
        }
        if (!is_string($value)) {
            return false;
        }

        return strcasecmp(trim($value), 'true') === 0;
    }
}
