<?php

namespace HypertubePhpSdk\configuration\configresolvers;

use InvalidArgumentException;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\RuntimeNameHandler;
use HypertubePhpUtils\connectiondata\IConnectionData;
use HypertubePhpUtils\connectiondata\InMemoryConnectionData;
use HypertubePhpUtils\connectiondata\Http2ConnectionData;
use HypertubePhpUtils\connectiondata\WsConnectionData;
use HypertubePhpUtils\connectiondata\TcpConnectionData;

abstract class ConfigResolver
{
    protected static function tryParseRuntime(string $runtime): RuntimeName
    {
        return RuntimeNameHandler::getRuntimeName($runtime);
    }

    protected static function mapConfigNameToRuntimeString(string $configName): string
    {
        $lowerConfigName = strtolower($configName);
        $runtimeByPackageManager = [
            'nuget' => 'netcore',
            'npm' => 'nodejs',
            'pypi' => 'python',
            'maven' => 'jvm',
            'packagist' => 'php',
            'rubygems' => 'ruby',
        ];

        foreach ($runtimeByPackageManager as $token => $runtime) {
            if (strpos($lowerConfigName, $token) !== false) {
                return $runtime;
            }
        }

        return '';
    }

    /**
     * Resolves the runtime from the explicit "runtime" value or, when it is not set, from the config name.
     */
    protected static function resolveRuntime(?string $runtimeValue, string $configName): RuntimeName
    {
        if ($runtimeValue === null || trim($runtimeValue) === '') {
            $inferredRuntime = self::mapConfigNameToRuntimeString($configName);
            if ($inferredRuntime === '') {
                throw new ConfigRuntimeException(
                    "Cannot determine runtime for config '$configName': set \"runtime\" explicitly or include a " .
                    'package-manager token (nuget, npm, pypi, maven, packagist, rubygems) in the name.'
                );
            }
            $runtimeValue = $inferredRuntime;
        }

        try {
            return self::tryParseRuntime($runtimeValue);
        } catch (\Exception $ex) {
            throw new ConfigRuntimeException(
                "Unknown runtime '$runtimeValue' in config '$configName'. " .
                'Supported: clr, go, jvm, netcore, perl, python, ruby, nodejs, cpp, php, python27.'
            );
        }
    }

    protected static function buildConnectionData(?string $hostValue): IConnectionData
    {
        if ($hostValue === null || trim($hostValue) === '') {
            throw new InvalidArgumentException('Host value cannot be null or whitespace.');
        }

        $hostValue = trim($hostValue);
        $lowerHostValue = strtolower($hostValue);

        if ($lowerHostValue === 'inmemory' || $lowerHostValue === 'in-memory') {
            return new InMemoryConnectionData();
        }

        if (strpos($lowerHostValue, 'ws://') === 0 || strpos($lowerHostValue, 'wss://') === 0) {
            return new WsConnectionData($hostValue);
        }

        // Http2 URL (http:// or https:// ends with h2)
        if ((strpos($lowerHostValue, 'http://') === 0 && substr($lowerHostValue, -2) === 'h2') ||
            (strpos($lowerHostValue, 'https://') === 0 && substr($lowerHostValue, -2) === 'h2')) {
            return new Http2ConnectionData($hostValue);
        }

        if (strpos($lowerHostValue, 'tcp://') === 0 || strpos($hostValue, ':') !== false) {
            return new TcpConnectionData($hostValue);
        }

        throw new InvalidArgumentException("Host value '$hostValue' is not a recognized connection format.");
    }

    protected static function getPropertyIgnoreCase(array $obj, string $property)
    {
        foreach ($obj as $key => $value) {
            if (is_string($key) && strcasecmp($key, $property) === 0) {
                return $value;
            }
        }
        return null;
    }
}
