<?php

namespace sdk\configuration\configresolvers;

use InvalidArgumentException;
use utils\RuntimeName;
use utils\RuntimeNameHandler;
use utils\connectiondata\IConnectionData;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\Http2ConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\connectiondata\TcpConnectionData;

abstract class ConfigResolver
{
    protected static function tryParseRuntime(string $runtime): RuntimeName
    {
        $runtime = trim($runtime);
        if (empty($runtime)) {
            throw new InvalidArgumentException('Runtime string cannot be null or whitespace.');
        }
        return RuntimeNameHandler::getRuntimeName($runtime);
    }

    protected static function buildConnectionData(?string $hostValue): IConnectionData
    {
        if ($hostValue === null || trim($hostValue) === '') {
            throw new InvalidArgumentException('Host value cannot be null or whitespace.');
        }

        $hostValue = trim($hostValue);
        $lowerHostValue = strtolower($hostValue);

        if ($lowerHostValue === 'inmemory' || $lowerHostValue === 'in-memory') {
            return new InMemoryConnectionData();
        }

        if (strpos($lowerHostValue, 'ws://') === 0 || strpos($lowerHostValue, 'wss://') === 0) {
            return new WsConnectionData($hostValue);
        }

        // Http2 URL (http:// or https:// ends with h2)
        if ((strpos($lowerHostValue, 'http://') === 0 && substr($lowerHostValue, -2) === 'h2') ||
            (strpos($lowerHostValue, 'https://') === 0 && substr($lowerHostValue, -2) === 'h2')) {
            return new Http2ConnectionData($hostValue);
        }

        if (strpos($lowerHostValue, 'tcp://') === 0 || strpos($hostValue, ':') !== false) {
            return new TcpConnectionData($hostValue);
        }

        throw new InvalidArgumentException("Host value '$hostValue' is not a recognized connection format.");
    }
}
