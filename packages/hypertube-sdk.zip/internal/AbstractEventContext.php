<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;

interface AbstractEventContext
{
    public function addEventListener(string $eventName, $eventHandler): InvocationContext;
}