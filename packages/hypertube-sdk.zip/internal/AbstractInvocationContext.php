<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\connectiondata\IConnectionData;

interface AbstractInvocationContext
{
    public function execute(?IConnectionData $connectionData = null): InvocationContext;
    public function getConnectionData(): IConnectionData;
    public function setConnectionData(IConnectionData $connectionData): void;
}
