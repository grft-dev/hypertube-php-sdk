<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\InvocationContext;
use utils\connectiondata\IConnectionData;

interface AbstractInvocationContext
{
    public function execute(?IConnectionData $connectionData = null): InvocationContext;
    public function getConnectionData(): IConnectionData;
    public function setConnectionData(IConnectionData $connectionData): void;
}
