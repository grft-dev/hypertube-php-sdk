<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;

interface AbstractArrayContext
{
    public function getSize(): InvocationContext;
    public function getRank(): InvocationContext;
    public function getIndex(...$indexes): InvocationContext;
    public function setIndex($indexes, $value): InvocationContext;
}