<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\RuntimeContext;

interface AbstractModuleContext
{
    public function loadLibrary(string $libraryPath): RuntimeContext;
}