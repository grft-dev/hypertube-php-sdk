<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;

interface AbstractEnumContext
{
    public function getEnumName(): InvocationContext;
    public function getEnumValue(): InvocationContext;
}
