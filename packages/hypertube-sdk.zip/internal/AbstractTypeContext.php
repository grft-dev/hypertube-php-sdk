<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;

interface AbstractTypeContext
{
    public function getType(string $typeName, ...$args): InvocationContext;
}
