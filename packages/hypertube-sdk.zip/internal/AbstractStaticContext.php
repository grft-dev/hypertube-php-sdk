<?php

declare(strict_types=1);

namespace HypertubePhpSdk\internal;

use HypertubePhpSdk\InvocationContext;

interface AbstractStaticContext
{
    public function invokeStaticMethod(string $methodName, ...$args): InvocationContext;
    public function getStaticField(string $fieldName): InvocationContext;
    public function setStaticField(string $fieldName, $value): InvocationContext;
    public function invokeGenericStaticMethod(string $methodName, ...$args): InvocationContext;
    public function getStaticMethodAsDelegate(string $methodName, ...$args): InvocationContext;
}