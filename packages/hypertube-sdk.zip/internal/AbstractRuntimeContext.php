<?php

declare(strict_types=1);

namespace sdk\internal;

use utils\connectiondata\IConnectionData;

interface AbstractRuntimeContext
{
    public function execute(): void;
    public function getConnectionData(): IConnectionData;
    public function setConnectionData(IConnectionData $connectionData): void;
}
