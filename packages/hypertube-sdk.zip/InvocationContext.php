<?php

declare(strict_types=1);

namespace sdk;

use ArrayAccess;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionType;
use RuntimeException;
use Throwable;
use IteratorAggregate;
use utils\Command;
use utils\CommandInterface;
use utils\connectiondata\IConnectionData;
use utils\error\UnsupportedPayloadItemTypeError;
use utils\exception\ExceptionThrower;
use utils\exception\UnsupportedOperationException;
use utils\RuntimeName;
use utils\type\CommandType;
use utils\TypesHandler;
use core\delegatecache\DelegatesCache;
use core\interpreter\Interpreter;
use sdk\internal\AbstractArrayContext;
use sdk\internal\AbstractEnumContext;
use sdk\internal\AbstractEventContext;
use sdk\internal\AbstractInstanceContext;
use sdk\internal\AbstractInvocationContext;
use sdk\internal\AbstractStaticContext;
use sdk\internal\InvocationContextIterator;
use sdk\tools\DtoHelper;
use utils\messagehelper\MessageHelper;
use utils\Uuid;


final class InvocationContext implements AbstractInvocationContext, AbstractInstanceContext, AbstractStaticContext, AbstractArrayContext, AbstractEnumContext, AbstractEventContext, IteratorAggregate, ArrayAccess
{
    /** @var array<string, InvocationContext> */
    private static array $instancesToBeMaterialized = [];

    private RuntimeName $runtimeName;
    private CommandInterface $currentCommand;
    private IConnectionData $connectionData;
    private bool $isExecuted;
    private bool $isDto;
    private string $guid;

    public function __construct(
        RuntimeName $runtime,
        IConnectionData $connectionData,
        CommandInterface $command,
        bool $isExecuted = false,
        bool $isDto = false
    ) {
        $this->runtimeName = $runtime;
        $this->connectionData = $connectionData;
        $this->currentCommand = $command;
        $this->isExecuted = $isExecuted;
        $this->isDto = $isDto;
        $this->guid = Uuid::uuid4()->toString();
    }

    public function getIterator(): InvocationContextIterator
    {
        if ($this->currentCommand->getCommandType()->notEqualsByValue(CommandType::REFERENCE)) {
            throw new RuntimeException('Object is not iterable');
        }
        return new InvocationContextIterator($this);
    }

    /**
     * @throws Throwable
     */
    public function execute(): InvocationContext
    {
        if ($this->isDto) {
            return $this;
        }

        $responseCommand = Interpreter::execute($this->currentCommand, $this->connectionData);
        if ($responseCommand->getCommandType()->equalsByValue(CommandType::EXCEPTION)) {
            try {
                ExceptionThrower::throwException($responseCommand);
            } catch (Throwable $throwable) {
                MessageHelper::getInstance()->sendMessageToAppInsights('SdkException', $throwable->getMessage());
                throw $throwable;
            }
        }

        $responseCommand = $this->processUpdateInvocationContextCommands($responseCommand);

        if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::PROJECT_RESULT_AS_DTO)) {
            return $this->convertResponseToDto($responseCommand);
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $responseCommand, true, $this->isDto);
    }

    public function getInstanceField(string $fieldName): InvocationContext
    {
        if ($this->isDto) {
            $value = DtoHelper::tryGetDtoFieldValue($this->currentCommand, $fieldName);

            $valueCommand = new Command($this->runtimeName, CommandType::VALUE(), [$value]);

            return new InvocationContext($this->runtimeName, $this->connectionData, $valueCommand, false, $this->isDto);
        }

        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_FIELD(), $fieldName);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setInstanceField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_INSTANCE_FIELD(), $fieldName, $value);
        $newCommand = $this->buildCommand($localCommand);

        if ($this->isDto) {
            $this->currentCommand = $newCommand;

            return $this;
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $newCommand, $this->isExecuted, $this->isDto);
    }

    public function invokeInstanceMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_INSTANCE_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function createInstance(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_INSTANCE(), ...$args);
        $createInstanceContext = new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            $this->isExecuted,
            $this->isDto
        );

        if ($this->isDto) {
            return $createInstanceContext;
        }

        return $createInstanceContext->registerForUpdate();
    }

    public function invokeGenericMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getRefValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_REF_VALUE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function createNull(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_NULL());
        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    private function buildCommand(?CommandInterface $command): CommandInterface
    {
        if ($command === null || $command->getPayload() === null) {
            return $this->currentCommand;
        }
        foreach ($command->getPayload() as $key => $item) {
            $command->setPayload($key, $this->encapsulatePayloadItem($item));
        }

        return $command->prependArgumentToPayload($this->currentCommand);
    }

    public function registerForUpdate(): InvocationContext
    {
        $registerCommand = new Command($this->runtimeName, CommandType::REGISTER_FOR_UPDATE(), $this->guid);
        $this->currentCommand = $this->buildCommand($registerCommand);
        self::$instancesToBeMaterialized[$this->guid] = $this;

        return $this;
    }

    public function asDto(bool $actAsDto = true): InvocationContext
    {
        return new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->currentCommand,
            false,
            $actAsDto
        );
    }

    public function projectResultAsDto(string ...$propertiesNames): InvocationContext
    {
        if (count($propertiesNames) === 1 && ($propertiesNames[0] === '' || $propertiesNames[0] === null)) {
            return $this;
        }

        $localCommand = new Command($this->runtimeName, CommandType::PROJECT_RESULT_AS_DTO(), $propertiesNames);

        return new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            false,
            false
        );
    }

    public function getRuntimeName(): RuntimeName
    {
        return $this->runtimeName;
    }

    private function processUpdateInvocationContextCommands(CommandInterface $responseCommand): CommandInterface
    {
        $payload = $responseCommand->getPayload();
        if (empty($payload)) {
            return $responseCommand;
        }

        $updatedPayload = [];
        foreach ($payload as $item) {
            if (
                $item instanceof CommandInterface
                && $item->getCommandType()->equalsByValue(CommandType::VALUE_FOR_UPDATE)
            ) {
                if ($item->getPayloadSize() >= 2) {
                    $contextGuid = (string) ($item->getPayload()[0] ?? '');
                    $instanceGuid = $item->getPayload()[1] ?? null;

                    if ($contextGuid !== '' && isset(self::$instancesToBeMaterialized[$contextGuid])) {
                        $invocationContext = self::$instancesToBeMaterialized[$contextGuid];
                        $invocationContext->currentCommand = new Command(
                            $this->runtimeName,
                            CommandType::REFERENCE(),
                            [$instanceGuid]
                        );
                        unset(self::$instancesToBeMaterialized[$contextGuid]);
                    }
                }

                continue;
            }

            $updatedPayload[] = $item;
        }

        return new Command(
            $responseCommand->getRuntimeName(),
            $responseCommand->getCommandType(),
            $updatedPayload
        );
    }

    private function convertResponseToDto(CommandInterface $responseCommand): InvocationContext
    {
        $payload = $responseCommand->getPayload();
        $getTypeCommand = $payload[1] ?? null;

        $dtoContext = new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            new Command($this->runtimeName, CommandType::CREATE_INSTANCE(), [$getTypeCommand]),
            true,
            true
        );

        for ($i = 2; $i < count($payload); $i++) {
            $item = $payload[$i];
            if (
                $item instanceof CommandInterface
                && $item->getCommandType()->equalsByValue(CommandType::DTO_PROPERTY)
            ) {
                $propertyName = (string) ($item->getPayload()[0] ?? '');
                $propertyValue = $item->getPayload()[1] ?? '';
                $dtoContext = $dtoContext->setInstanceField($propertyName, $propertyValue);
            }
        }

        return $dtoContext;
    }

    /**
     * @param mixed $payloadItem
     */
    private function encapsulatePayloadItem($payloadItem): CommandInterface
    {
        if ($payloadItem === null) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof CommandInterface) {
            foreach ($payloadItem->getPayload() as $key => $item) {
                $payloadItem->setPayload($key, $this->encapsulatePayloadItem($item));
            }

            return $payloadItem;
        }

        if ($payloadItem instanceof InvocationContext) {
            return $payloadItem->getCurrentCommand();
        }

        if ($payloadItem instanceof ReflectionType) {
            return new Command($this->runtimeName, CommandType::CONVERT_TYPE(), TypesHandler::convertTypeToHypertubeType($payloadItem));
        }

        if (is_array($payloadItem)) {
            $encapsulatedArray = [];

            foreach ($payloadItem as $item) {
                $encapsulatedArray[] = $this->encapsulatePayloadItem($item);
            }

            return new Command($this->runtimeName, CommandType::ARRAY(), $encapsulatedArray);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof ReflectionMethod) {
            $types = [];
            foreach ($payloadItem->getParameters() as $param) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType) {
                    $typeName = $type->getName();
                    if ($type->isBuiltin()) {
                        $types[] = $typeName;
                    } else {
                        $types[] = ($typeName[0] === '\\' ? '' : '\\') . $typeName;
                    }
                } else {
                    $types[] = 'mixed';
                }
            }

            $returnType = $payloadItem->getReturnType();
            if ($returnType instanceof ReflectionNamedType) {
                $returnTypeName = $returnType->getName();
                if ($returnType->isBuiltin()) {
                    $types[] = $returnTypeName;
                } else {
                    $types[] = ($returnTypeName[0] === '\\' ? '' : '\\') . $returnTypeName;
                }
            } else {
                $types[] = 'mixed';
            }

            $delegateId = DelegatesCache::getInstance()->addDelegate($payloadItem);
            $args = array_merge([$delegateId, RuntimeName::PHP], $types);

            $encapsulatedArgs = [];
            foreach ($args as $arg) {
                $encapsulatedArgs[] = $this->encapsulatePayloadItem($arg);
            }

            return new Command($this->runtimeName, CommandType::PASS_DELEGATE(), $encapsulatedArgs);
        }

        throw new UnsupportedPayloadItemTypeError($payloadItem);
    }

    public function getInstanceMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData,
            $this->buildCommand($localCommand));
    }
    public function invokeStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_STATIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getStaticField(string $fieldName): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_FIELD(), $fieldName);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setStaticField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_STATIC_FIELD(), $fieldName, $value);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function invokeGenericStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_STATIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getStaticMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getSize(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_SIZE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getRank(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_RANK());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getIndex(...$indexes): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_ITEM(), ...$indexes);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setIndex($indexes, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_SET_ITEM(), $indexes, $value);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getEnumName(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_NAME());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getEnumValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_VALUE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function addEventListener(string $eventName, $eventHandler): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ADD_EVENT_LISTENER(), $eventName, $eventHandler);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getCurrentCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    public function getCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->currentCommand->getPayload()[0];
    }

    /**
     * @throws Throwable
     */
    public function retrieveArray(): array
    {
        $localCommand = new Command($this->runtimeName, CommandType::RETRIEVE_ARRAY());
        $localInvCtx = new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
        $arrayInvCtx = $localInvCtx->execute();
        $responseArray = [];
        if (count($arrayInvCtx->currentCommand->getPayload()) > 0) {
            $responseArray = $arrayInvCtx->currentCommand->getPayload();
        }

        return $responseArray;
    }

    /**
     * @param $offset mixed
     */
    public function offsetExists($offset): bool
    {
        return is_int($offset) && $offset >= 0;
    }

    /**
     * @param $offset mixed
     * @throws Throwable
     */
    public function offsetGet($offset): InvocationContext
    {
        if (is_array($offset)) {
            return $this->getIndex(...$offset)->execute();
        }

        return $this->getIndex($offset)->execute();
    }

    /**
     * @param mixed $offset
     * @param mixed $value
     * @throws Throwable
     */
    public function offsetSet($offset, $value): void
    {
        $this->setIndex($offset, $value)->execute();
    }

    /**
     * @param $offset mixed
     */
    public function offsetUnset($offset): void
    {
        throw new UnsupportedOperationException('Unsetting array elements via ArrayAccess is not supported.');
    }
}
