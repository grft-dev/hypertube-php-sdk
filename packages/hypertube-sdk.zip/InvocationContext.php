<?php

declare(strict_types=1);

namespace sdk;

use ArrayAccess;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionType;
use RuntimeException;
use Throwable;
use IteratorAggregate;
use utils\Command;
use utils\CommandInterface;
use utils\connectiondata\IConnectionData;
use utils\error\UnsupportedPayloadItemTypeError;
use utils\exception\ExceptionThrower;
use utils\exception\UnsupportedOperationException;
use utils\RuntimeName;
use utils\type\CommandType;
use utils\TypesHandler;
use core\delegatecache\DelegatesCache;
use core\interpreter\Interpreter;
use sdk\internal\AbstractArrayContext;
use sdk\internal\AbstractEnumContext;
use sdk\internal\AbstractEventContext;
use sdk\internal\AbstractInstanceContext;
use sdk\internal\AbstractInvocationContext;
use sdk\internal\AbstractStaticContext;
use sdk\internal\InvocationContextIterator;
use utils\messagehelper\MessageHelper;
use utils\Uuid;
use sdk\tools\GetInstanceFieldHelper;


final class InvocationContext implements AbstractInvocationContext, AbstractInstanceContext, AbstractStaticContext, AbstractArrayContext, AbstractEnumContext, AbstractEventContext, IteratorAggregate, ArrayAccess
{
    /** @var array<string, InvocationContext> */
    private static array $instancesToBeMaterialized = [];

    private RuntimeName $runtimeName;
    private CommandInterface $currentCommand;
    private IConnectionData $connectionData;
    private bool $isExecuted;
    private bool $isStateless;
    private string $guid;

    public function __construct(
        RuntimeName $runtime,
        IConnectionData $connectionData,
        CommandInterface $command,
        bool $isExecuted = false,
        bool $isStateless = false
    ) {
        $this->runtimeName = $runtime;
        $this->connectionData = $connectionData;
        $this->currentCommand = $command;
        $this->isExecuted = $isExecuted;
        $this->isStateless = $isStateless;
        $this->guid = Uuid::uuid4()->toString();
    }

    private function buildInvocationContext(CommandInterface $localCommand): InvocationContext
    {
        return new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            $this->isExecuted,
            $this->isStateless
        );
    }

    public function getIterator(): InvocationContextIterator
    {
        if ($this->currentCommand->getCommandType()->notEqualsByValue(CommandType::REFERENCE)) {
            throw new RuntimeException('Object is not iterable');
        }
        return new InvocationContextIterator($this);
    }

    /**
     * @throws Throwable
     */
    public function execute(): InvocationContext
    {
        if ($this->currentCommand === null) {
            throw new RuntimeException('currentCommand is undefined in InvocationContext execute method');
        }

        if ($this->isStateless && !$this->currentCommand->getCommandType()->equalsByValue(CommandType::PASS_BY_VALUE)) {
            return $this;
        }

        $responseCommand = Interpreter::execute($this->currentCommand, $this->connectionData);
        if ($responseCommand->getCommandType()->equalsByValue(CommandType::EXCEPTION)) {
            try {
                ExceptionThrower::throwException($responseCommand);
            } catch (Throwable $throwable) {
                MessageHelper::getInstance()->sendMessageToAppInsights('SdkException', $throwable->getMessage());
                throw $throwable;
            }
        }

        if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::CREATE_INSTANCE)) {
            $this->currentCommand = $responseCommand;
            $this->isExecuted = true;
            return $this;
        }

        if (!$this->isStateless) {
            $responseCommand = $this->processUpdateInvocationContextCommands($responseCommand);
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $responseCommand, true, $this->isStateless);
    }

    public function getInstanceField(string $fieldName): InvocationContext
    {
        if ($this->isStateless) {
            $value = GetInstanceFieldHelper::getFieldValue($this->currentCommand, $fieldName);
            if (TypesHandler::isSimpleType($value)) {
                $returnCommand = new Command($this->runtimeName, CommandType::VALUE(), $value);
            } elseif ($value instanceof CommandInterface) {
                $returnCommand = $value;
            } else {
                throw new RuntimeException(
                    sprintf(
                        'Unsupported type for stateless getInstanceField: %s',
                        is_object($value) ? get_class($value) : gettype($value)
                    )
                );
            }

            return new InvocationContext(
                $this->runtimeName,
                $this->connectionData,
                $returnCommand,
                false,
                $this->isStateless
            );
        }

        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_FIELD(), $fieldName);

        return $this->buildInvocationContext($localCommand);
    }

    public function setInstanceField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_INSTANCE_FIELD(), $fieldName, $value);
        $newCommand = $this->buildCommand($localCommand);
        if ($this->isStateless) {
            $this->currentCommand = $newCommand;
            return $this;
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $newCommand, $this->isExecuted, $this->isStateless);
    }

    public function invokeInstanceMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_INSTANCE_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function createInstance(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_INSTANCE(), ...$args);
        $createInstanceContext = new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            $this->isExecuted,
            $this->isStateless
        );
        return $createInstanceContext->registerForUpdate();
    }

    public function invokeGenericMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getRefValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_REF_VALUE());

        return $this->buildInvocationContext($localCommand);
    }

    public function createNull(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_NULL());
        return $this->buildInvocationContext($localCommand);
    }

    private function buildCommand(?CommandInterface $command): CommandInterface
    {
        if ($command === null || $command->getPayload() === null) {
            return $this->currentCommand;
        }
        foreach ($command->getPayload() as $key => $item) {
            $command->setPayload($key, $this->encapsulatePayloadItem($item));
        }

        return $command->prependArgumentToPayload($this->currentCommand);
    }

    public function registerForUpdate(): InvocationContext
    {
        $registerCommand = new Command($this->runtimeName, CommandType::REGISTER_FOR_UPDATE(), $this->guid);
        $this->currentCommand = $this->buildCommand($registerCommand);
        self::$instancesToBeMaterialized[$this->guid] = $this;

        return $this;
    }



    public function getRuntimeName(): RuntimeName
    {
        return $this->runtimeName;
    }

    private function processUpdateInvocationContextCommands(CommandInterface $responseCommand): CommandInterface
    {
        $payload = $responseCommand->getPayload();
        if (empty($payload)) {
            return $responseCommand;
        }

        $updatedPayload = [];
        foreach ($payload as $item) {
            if (
                $item instanceof CommandInterface
                && $item->getCommandType()->equalsByValue(CommandType::VALUE_FOR_UPDATE)
            ) {
                if ($item->getPayloadSize() >= 2) {
                    $contextGuid = (string) ($item->getPayload()[0] ?? '');
                    $instanceGuid = $item->getPayload()[1] ?? null;

                    if ($contextGuid !== '' && isset(self::$instancesToBeMaterialized[$contextGuid])) {
                        $invocationContext = self::$instancesToBeMaterialized[$contextGuid];
                        $invocationContext->currentCommand = new Command(
                            $this->runtimeName,
                            CommandType::REFERENCE(),
                            [$instanceGuid]
                        );
                        unset(self::$instancesToBeMaterialized[$contextGuid]);
                    }
                }

                continue;
            }

            $updatedPayload[] = $item;
        }

        return new Command(
            $responseCommand->getRuntimeName(),
            $responseCommand->getCommandType(),
            $updatedPayload
        );
    }

    /**
     * @param mixed $payloadItem
     */
    private function encapsulatePayloadItem($payloadItem): CommandInterface
    {
        if ($payloadItem === null) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof CommandInterface) {
            if ($payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
                || $payloadItem->getCommandType()->equalsByValue(CommandType::ARRAY)) {
                return $payloadItem;
            }

            foreach ($payloadItem->getPayload() as $key => $item) {
                $payloadItem->setPayload($key, $this->encapsulatePayloadItem($item));
            }

            return $payloadItem;
        }

        if ($payloadItem instanceof InvocationContext) {
            return $payloadItem->getCurrentCommand();
        }

        if ($payloadItem instanceof ReflectionType) {
            return new Command($this->runtimeName, CommandType::CONVERT_TYPE(), TypesHandler::convertTypeToHypertubeType($payloadItem));
        }

        if (is_array($payloadItem)) {
            $encapsulatedArray = [];

            foreach ($payloadItem as $item) {
                $encapsulatedArray[] = $this->encapsulatePayloadItem($item);
            }

            return new Command($this->runtimeName, CommandType::ARRAY(), $encapsulatedArray);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof ReflectionMethod) {
            $types = [];
            foreach ($payloadItem->getParameters() as $param) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType) {
                    $typeName = $type->getName();
                    if ($type->isBuiltin()) {
                        $types[] = $typeName;
                    } else {
                        $types[] = ($typeName[0] === '\\' ? '' : '\\') . $typeName;
                    }
                } else {
                    $types[] = 'mixed';
                }
            }

            $returnType = $payloadItem->getReturnType();
            if ($returnType instanceof ReflectionNamedType) {
                $returnTypeName = $returnType->getName();
                if ($returnType->isBuiltin()) {
                    $types[] = $returnTypeName;
                } else {
                    $types[] = ($returnTypeName[0] === '\\' ? '' : '\\') . $returnTypeName;
                }
            } else {
                $types[] = 'mixed';
            }

            $delegateId = DelegatesCache::getInstance()->addDelegate($payloadItem);
            $args = array_merge([$delegateId, RuntimeName::PHP], $types);

            $encapsulatedArgs = [];
            foreach ($args as $arg) {
                $encapsulatedArgs[] = $this->encapsulatePayloadItem($arg);
            }

            return new Command($this->runtimeName, CommandType::PASS_DELEGATE(), $encapsulatedArgs);
        }

        throw new UnsupportedPayloadItemTypeError($payloadItem);
    }

    public function getInstanceMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData,
            $this->buildCommand($localCommand));
    }
    public function invokeStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_STATIC_METHOD(), $methodName, ...$args);

        if ($this->isStateless) {
            $localInvCtx = $this->buildInvocationContext($localCommand);
            return $localInvCtx->passByValue();
        }
        return $this->buildInvocationContext($localCommand);
    }

    private function passByValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::PASS_BY_VALUE());
        return $this->buildInvocationContext($localCommand);
    }

    public function getStaticField(string $fieldName): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_FIELD(), $fieldName);

        return $this->buildInvocationContext($localCommand);
    }

    public function setStaticField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_STATIC_FIELD(), $fieldName, $value);

        return $this->buildInvocationContext($localCommand);
    }

    public function invokeGenericStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_STATIC_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getStaticMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getSize(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_SIZE());

        return $this->buildInvocationContext($localCommand);
    }

    public function getRank(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_RANK());

        return $this->buildInvocationContext($localCommand);
    }

    public function getIndex(...$indexes): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_ITEM(), ...$indexes);

        return $this->buildInvocationContext($localCommand);
    }

    public function setIndex($indexes, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_SET_ITEM(), $indexes, $value);

        return $this->buildInvocationContext($localCommand);
    }

    public function getEnumName(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_NAME());

        return $this->buildInvocationContext($localCommand);
    }

    public function getEnumValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_VALUE());

        return $this->buildInvocationContext($localCommand);
    }

    public function addEventListener(string $eventName, $eventHandler): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ADD_EVENT_LISTENER(), $eventName, $eventHandler);

        return $this->buildInvocationContext($localCommand);
    }

    public function getCurrentCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    public function getCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::VALUE)) {
            if (TypesHandler::isSimpleType($this->currentCommand->getPayload()[0])) {
                return $this->currentCommand->getPayload()[0];
            }
        }
        return $this;
    }

    /**
     * @return array
     * @throws Throwable
     */
    public function retrieveArray()
    {
        $arrayInvCtx = $this;
        if (!$this->isStateless) {
            $retrieveArrayCommand = new Command($this->runtimeName, CommandType::RETRIEVE_ARRAY());
            $localInvCtx = new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($retrieveArrayCommand));
            $arrayInvCtx = $localInvCtx->execute();
        }

        $payload = $arrayInvCtx->currentCommand->getPayload();
        if (count($payload) === 0) {
            return [];
        }

        if ($payload[0] instanceof CommandInterface) {
            $invocationContexts = [];
            foreach ($payload as $item) {
                $invocationContexts[] = new InvocationContext(
                    $this->runtimeName,
                    $this->connectionData,
                    $item,
                    $this->isExecuted,
                    $this->isStateless
                );
            }

            return $invocationContexts;
        }

        return $payload;
    }

    /**
     * @param $offset mixed
     */
    public function offsetExists($offset): bool
    {
        return is_int($offset) && $offset >= 0;
    }

    /**
     * @param $offset mixed
     * @throws Throwable
     */
    public function offsetGet($offset): InvocationContext
    {
        if (is_array($offset)) {
            return $this->getIndex(...$offset)->execute();
        }

        return $this->getIndex($offset)->execute();
    }

    /**
     * @param mixed $offset
     * @param mixed $value
     * @throws Throwable
     */
    public function offsetSet($offset, $value): void
    {
        $this->setIndex($offset, $value)->execute();
    }

    /**
     * @param $offset mixed
     */
    public function offsetUnset($offset): void
    {
        throw new UnsupportedOperationException('Unsetting array elements via ArrayAccess is not supported.');
    }
}

