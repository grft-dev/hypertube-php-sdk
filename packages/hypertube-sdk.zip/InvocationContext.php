<?php

declare(strict_types=1);

namespace HypertubePhpSdk;

use ArrayAccess;
use Closure;
use IteratorAggregate;
use ReflectionFunction;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionType;
use RuntimeException;
use Throwable;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\connectiondata\IConnectionData;
use HypertubePhpUtils\exception\ExceptionThrower;
use HypertubePhpUtils\exception\UnsupportedOperationException;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\TypesHandler;
use HypertubePhpCore\delegatecache\DelegatesCache;
use HypertubePhpCore\interpreter\Interpreter;
use HypertubePhpSdk\internal\AbstractArrayContext;
use HypertubePhpSdk\internal\AbstractEnumContext;
use HypertubePhpSdk\internal\AbstractEventContext;
use HypertubePhpSdk\internal\AbstractInstanceContext;
use HypertubePhpSdk\internal\AbstractInvocationContext;
use HypertubePhpSdk\internal\AbstractStaticContext;
use HypertubePhpSdk\internal\InvocationContextIterator;
use HypertubePhpUtils\Uuid;
use HypertubePhpSdk\tools\ComplexTypeResolver;
use HypertubePhpSdk\tools\GetInstanceFieldHelper;


final class InvocationContext implements AbstractInvocationContext, AbstractInstanceContext, AbstractStaticContext, AbstractArrayContext, AbstractEnumContext, AbstractEventContext, IteratorAggregate, ArrayAccess
{
    /** @var array<string, InvocationContext> */
    private static array $instancesToBeMaterialized = [];

    /** @var array<string, CommandInterface> */
    private static array $materializedReferences = [];

    private RuntimeName $runtimeName;
    private CommandInterface $currentCommand;
    private IConnectionData $connectionData;
    private bool $isExecuted;
    private bool $isStateless;
    private string $guid;

    /** Re-entrant lock depth used to coordinate materialization updates. */
    private int $materializationLockDepth = 0;

    public function __construct(
        RuntimeName      $runtime,
        IConnectionData  $connectionData,
        CommandInterface $command,
        bool             $isExecuted = false,
        bool             $isStateless = false
    )
    {
        $this->runtimeName = $runtime;
        $this->connectionData = $connectionData;
        $this->currentCommand = $command;
        $this->isExecuted = $isExecuted;
        $this->isStateless = $isStateless;
        $this->guid = Uuid::uuid4()->toString();
    }

    public function getConnectionData(): IConnectionData
    {
        return $this->connectionData;
    }

    public function setConnectionData(IConnectionData $connectionData): void
    {
        $this->connectionData = $connectionData;
    }

    private function buildInvocationContext(CommandInterface $localCommand): InvocationContext
    {
        return new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            $this->isExecuted,
            $this->isStateless
        );
    }

    public function getIterator(): InvocationContextIterator
    {
        if ($this->currentCommand->getCommandType()->notEqualsByValue(CommandType::REFERENCE)) {
            throw new RuntimeException('Object is not iterable');
        }
        return new InvocationContextIterator($this);
    }

    /**
     * @throws Throwable
     */
    public function execute(?IConnectionData $connectionData = null): InvocationContext
    {
        if ($connectionData !== null) {
            $this->connectionData = $connectionData;
        }

        if ($this->isStateless && !$this->currentCommand->getCommandType()->equalsByValue(CommandType::PASS_BY_VALUE)) {
            return $this;
        }
        $locksToRelease = [];
        if (!$this->isStateless) {
            // Lock only materialization contexts referenced by this command.
            $locksToRelease = $this->getReferencedMaterializationLocks($this->currentCommand);
            foreach ($locksToRelease as $invocationContext) {
                $invocationContext->acquireMaterializationLock();
            }

            // Replace stale RegisterForUpdate nodes with already materialized references.
            $this->currentCommand = $this->materializeUpdatedReferences($this->currentCommand);
        }

        try {
            $responseCommand = Interpreter::execute($this->currentCommand, $this->connectionData);
            if ($responseCommand->getCommandType()->equalsByValue(CommandType::EXCEPTION)) {
                ExceptionThrower::throwException($responseCommand);
            }

            if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::CREATE_INSTANCE)) {
                $this->currentCommand = $responseCommand;
                $this->isExecuted = true;
                return $this;
            }

            $responseCommand = $this->processUpdateInvocationContextCommands($responseCommand);

            return new InvocationContext($this->runtimeName, $this->connectionData, $responseCommand, true, $this->isStateless);
        } finally {
            for ($i = count($locksToRelease) - 1; $i >= 0; $i--) {
                $locksToRelease[$i]->releaseMaterializationLock();
            }
        }
    }

    public function getInstanceField(string $fieldName): InvocationContext
    {
        if ($this->isStateless) {
            $value = GetInstanceFieldHelper::getFieldValue($this->currentCommand, $fieldName);
            if (TypesHandler::isSimpleType($value)) {
                $returnCommand = new Command($this->runtimeName, CommandType::VALUE(), $value);
            } elseif ($value instanceof CommandInterface) {
                $returnCommand = $value;
            } else {
                throw new RuntimeException(
                    sprintf(
                        'Unsupported type for stateless getInstanceField: %s',
                        is_object($value) ? get_class($value) : gettype($value)
                    )
                );
            }

            return new InvocationContext(
                $this->runtimeName,
                $this->connectionData,
                $returnCommand,
                false,
                $this->isStateless
            );
        }

        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_FIELD(), $fieldName);

        return $this->buildInvocationContext($localCommand);
    }

    public function setInstanceField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_INSTANCE_FIELD(), $fieldName, $value);
        $newCommand = $this->buildCommand($localCommand);
        if ($this->isStateless) {
            $this->currentCommand = $newCommand;
            return $this;
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $newCommand, $this->isExecuted, $this->isStateless);
    }

    public function invokeInstanceMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_INSTANCE_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function createInstance(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_INSTANCE(), ...$args);
        $createInstanceContext = new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($localCommand),
            $this->isExecuted,
            $this->isStateless
        );
        return $createInstanceContext->registerForUpdate();
    }

    public function invokeGenericMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getRefValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_REF_VALUE());

        return $this->buildInvocationContext($localCommand);
    }

    public function createNull(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_NULL());
        return $this->buildInvocationContext($localCommand);
    }

    private function buildCommand(?CommandInterface $command): CommandInterface
    {
        if ($command === null || $command->getPayload() === null) {
            return $this->currentCommand;
        }
        foreach ($command->getPayload() as $key => $item) {
            $command->setPayload($key, $this->encapsulatePayloadItem($item));
        }

        return $command->prependArgumentToPayload($this->currentCommand);
    }

    public function registerForUpdate(): InvocationContext
    {
        $registerCommand = new Command($this->runtimeName, CommandType::REGISTER_FOR_UPDATE(), $this->guid);
        $this->currentCommand = $this->buildCommand($registerCommand);
        self::$instancesToBeMaterialized[$this->guid] = $this;
        unset(self::$materializedReferences[$this->guid]);

        return $this;
    }


    public function getRuntimeName(): RuntimeName
    {
        return $this->runtimeName;
    }

    public function isStateless(): bool
    {
        return $this->isStateless;
    }

    private function processUpdateInvocationContextCommands(CommandInterface $responseCommand): CommandInterface
    {
        $payload = $responseCommand->getPayload();
        if (empty($payload)) {
            return $responseCommand;
        }

        $commandsToUpdate = [];
        foreach ($payload as $item) {
            if ($item instanceof CommandInterface
                && $item->getCommandType()->equalsByValue(CommandType::VALUE_FOR_UPDATE)) {
                $commandsToUpdate[] = $item;
            }
        }

        if (empty($commandsToUpdate)) {
            return $responseCommand;
        }

        $updatedPayload = $payload;
        if (!$this->isStateless) {
            $this->acquireMaterializationLock();
            try {
                foreach ($commandsToUpdate as $commandToUpdate) {
                    if ($commandToUpdate->getPayloadSize() >= 2) {
                        $contextGuid = $this->getStringPayloadValue($commandToUpdate->getPayload()[0] ?? null);
                        if ($contextGuid !== '' && isset(self::$instancesToBeMaterialized[$contextGuid])) {
                            $invocationContext = self::$instancesToBeMaterialized[$contextGuid];
                            $instanceGuid = $this->getStringPayloadValue($commandToUpdate->getPayload()[1] ?? null);
                            if ($instanceGuid !== '') {
                                $invocationContext->currentCommand = new Command(
                                    $this->runtimeName,
                                    CommandType::REFERENCE(),
                                    [$instanceGuid]
                                );
                                $invocationContext->isExecuted = true;
                                self::$materializedReferences[$contextGuid] = $invocationContext->currentCommand;
                                unset(self::$instancesToBeMaterialized[$contextGuid]);
                            }
                        }
                    }

                    $index = array_search($commandToUpdate, $updatedPayload, true);
                    if ($index !== false) {
                        unset($updatedPayload[$index]);
                    }
                }
            } finally {
                $this->releaseMaterializationLock();
            }
        } else {
            foreach ($commandsToUpdate as $commandToUpdate) {
                $index = array_search($commandToUpdate, $updatedPayload, true);
                if ($index !== false) {
                    unset($updatedPayload[$index]);
                }
            }
        }

        return new Command(
            $responseCommand->getRuntimeName(),
            $responseCommand->getCommandType(),
            array_values($updatedPayload)
        );
    }

    private function materializeUpdatedReferences(CommandInterface $command): CommandInterface
    {
        $materializedReference = $this->tryGetMaterializedReference($command);
        if ($materializedReference !== null) {
            return $materializedReference;
        }

        $payload = $command->getPayload();
        if (empty($payload)) {
            return $command;
        }

        $updatedPayload = $payload;
        $changed = false;
        foreach ($payload as $index => $item) {
            if ($item instanceof CommandInterface) {
                $updatedCommand = $this->materializeUpdatedReferences($item);
                $updatedPayload[$index] = $updatedCommand;
                if ($updatedCommand !== $item) {
                    $changed = true;
                }
            }
        }

        if (!$changed) {
            return $command;
        }

        return new Command($command->getRuntimeName(), $command->getCommandType(), $updatedPayload);
    }

    /**
     * @return array<int, InvocationContext>
     */
    private function getReferencedMaterializationLocks(CommandInterface $command): array
    {
        $contexts = [];
        $this->collectReferencedMaterializationLocks($command, $contexts);
        ksort($contexts);
        return array_values($contexts);
    }

    /**
     * @param array<string, InvocationContext> $contexts
     */
    private function collectReferencedMaterializationLocks(CommandInterface $command, array &$contexts): void
    {
        if ($command->getCommandType()->equalsByValue(CommandType::REGISTER_FOR_UPDATE)
            && $command->getPayloadSize() >= 2) {
            $contextGuid = $this->getStringPayloadValue($command->getPayload()[1] ?? null);
            if ($contextGuid !== '' && isset(self::$instancesToBeMaterialized[$contextGuid])) {
                $contexts[$contextGuid] = self::$instancesToBeMaterialized[$contextGuid];
            }
        }

        $payload = $command->getPayload();
        if (empty($payload)) {
            return;
        }

        foreach ($payload as $item) {
            if ($item instanceof CommandInterface) {
                $this->collectReferencedMaterializationLocks($item, $contexts);
            }
        }
    }

    private function tryGetMaterializedReference(CommandInterface $command): ?CommandInterface
    {
        if (!$command->getCommandType()->equalsByValue(CommandType::REGISTER_FOR_UPDATE)
            || $command->getPayloadSize() < 2) {
            return null;
        }

        $contextGuid = $this->getStringPayloadValue($command->getPayload()[1] ?? null);
        if ($contextGuid === '') {
            return null;
        }

        if (isset(self::$instancesToBeMaterialized[$contextGuid])) {
            $invocationContext = self::$instancesToBeMaterialized[$contextGuid];
            if ($invocationContext->isExecuted
                && $invocationContext->currentCommand->getCommandType()->equalsByValue(CommandType::REFERENCE)) {
                self::$materializedReferences[$contextGuid] = $invocationContext->currentCommand;
                return $invocationContext->currentCommand;
            }
        }

        return self::$materializedReferences[$contextGuid] ?? null;
    }

    /**
     * @param mixed $payloadItem
     */
    private function getStringPayloadValue($payloadItem): string
    {
        if ($payloadItem instanceof CommandInterface
            && $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
            && $payloadItem->getPayloadSize() > 0) {
            $payloadItem = $payloadItem->getPayload()[0];
        }

        return trim((string)($payloadItem ?? ''));
    }

    private function acquireMaterializationLock(): void
    {
        $this->materializationLockDepth++;
    }

    private function releaseMaterializationLock(): void
    {
        if ($this->materializationLockDepth > 0) {
            $this->materializationLockDepth--;
        }
    }

    /**
     * @param mixed $payloadItem
     */
    private function encapsulatePayloadItem($payloadItem): CommandInterface
    {
        if ($payloadItem === null) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof CommandInterface) {
            if ($payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
                || $payloadItem->getCommandType()->equalsByValue(CommandType::ARRAY)) {
                return $payloadItem;
            }

            foreach ($payloadItem->getPayload() as $key => $item) {
                $payloadItem->setPayload($key, $this->encapsulatePayloadItem($item));
            }

            return $payloadItem;
        }

        if ($payloadItem instanceof InvocationContext) {
            return $payloadItem->getCurrentCommand();
        }

        if ($payloadItem instanceof ReflectionType) {
            return new Command($this->runtimeName, CommandType::CONVERT_TYPE(), TypesHandler::convertTypeToHypertubeType($payloadItem));
        }

        if (is_array($payloadItem)) {
            $encapsulatedArray = [];

            foreach ($payloadItem as $item) {
                $encapsulatedArray[] = $this->encapsulatePayloadItem($item);
            }

            return new Command($this->runtimeName, CommandType::ARRAY(), $encapsulatedArray);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof ReflectionMethod || $payloadItem instanceof Closure) {
            $reflection = $payloadItem instanceof ReflectionMethod
                ? $payloadItem
                : new ReflectionFunction($payloadItem);
            $types = [];
            foreach ($reflection->getParameters() as $param) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType) {
                    $typeName = $type->getName();
                    if ($type->isBuiltin()) {
                        $types[] = $typeName;
                    } else {
                        $types[] = ($typeName[0] === '\\' ? '' : '\\') . $typeName;
                    }
                } else {
                    $types[] = 'mixed';
                }
            }

            $returnType = $reflection->getReturnType();
            if ($returnType instanceof ReflectionNamedType) {
                $returnTypeName = $returnType->getName();
                if ($returnType->isBuiltin()) {
                    $types[] = $returnTypeName;
                } else {
                    $types[] = ($returnTypeName[0] === '\\' ? '' : '\\') . $returnTypeName;
                }
            } else {
                $types[] = 'mixed';
            }

            $delegateId = DelegatesCache::getInstance()->addDelegate($payloadItem);
            $args = array_merge([$delegateId, RuntimeName::PHP], $types);

            $encapsulatedArgs = [];
            foreach ($args as $arg) {
                $encapsulatedArgs[] = $this->encapsulatePayloadItem($arg);
            }

            return new Command($this->runtimeName, CommandType::PASS_DELEGATE(), $encapsulatedArgs);
        }

        return (new ComplexTypeResolver())->convertComplexTypeToCommand($this->runtimeName, $payloadItem);
    }

    public function getInstanceMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData,
            $this->buildCommand($localCommand));
    }

    public function invokeStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_STATIC_METHOD(), $methodName, ...$args);

        if ($this->isStateless) {
            $localInvCtx = $this->buildInvocationContext($localCommand);
            return $localInvCtx->passByValue();
        }
        return $this->buildInvocationContext($localCommand);
    }

    private function passByValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::PASS_BY_VALUE());
        return $this->buildInvocationContext($localCommand);
    }

    public function getStaticField(string $fieldName): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_FIELD(), $fieldName);

        return $this->buildInvocationContext($localCommand);
    }

    public function setStaticField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_STATIC_FIELD(), $fieldName, $value);

        return $this->buildInvocationContext($localCommand);
    }

    public function invokeGenericStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_STATIC_METHOD(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getStaticMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return $this->buildInvocationContext($localCommand);
    }

    public function getSize(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_SIZE());

        return $this->buildInvocationContext($localCommand);
    }

    public function getRank(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_RANK());

        return $this->buildInvocationContext($localCommand);
    }

    public function getIndex(...$indexes): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_ITEM(), ...$indexes);

        return $this->buildInvocationContext($localCommand);
    }

    public function setIndex($indexes, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_SET_ITEM(), $indexes, $value);

        return $this->buildInvocationContext($localCommand);
    }

    public function getEnumName(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_NAME());

        return $this->buildInvocationContext($localCommand);
    }

    public function getEnumValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_VALUE());

        return $this->buildInvocationContext($localCommand);
    }

    public function addEventListener(string $eventName, $eventHandler): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ADD_EVENT_LISTENER(), $eventName, $eventHandler);

        return $this->buildInvocationContext($localCommand);
    }

    /**
     * @throws Throwable
     */
    public function getResultType()
    {
        if ($this->isStateless) {
            return GetInstanceFieldHelper::getResultType($this->currentCommand);
        }
        if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE)) {
            return (string)$this->currentCommand->getPayload()[0];
        }
        $localCommand = new Command($this->runtimeName, CommandType::GET_RESULT_TYPE());
        $localInvCtx = $this->buildInvocationContext($localCommand);

        return $localInvCtx->execute()->getValue();
    }

    public function getCurrentCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    public function getCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        if ($this->currentCommand->getCommandType()->equalsByValue(CommandType::VALUE)) {
            if (TypesHandler::isSimpleType($this->currentCommand->getPayload()[0])) {
                return $this->currentCommand->getPayload()[0];
            }
        }
        return $this;
    }

    /**
     * @throws Throwable
     */
    public function retrieveArray(): array
    {
        $arrayInvCtx = $this;
        if (!$this->isStateless) {
            $retrieveArrayCommand = new Command($this->runtimeName, CommandType::RETRIEVE_ARRAY());
            $localInvCtx = new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($retrieveArrayCommand));
            $arrayInvCtx = $localInvCtx->execute();
        }

        return $this->materializeArrayPayload($arrayInvCtx->currentCommand->getPayload());
    }

    /**
     * @param array<int, mixed> $payload
     * @return array<int, mixed>
     */
    private function materializeArrayPayload(array $payload): array
    {
        if (count($payload) === 0) {
            return [];
        }

        if ($payload[0] instanceof CommandInterface
            && !$payload[0]->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            $invocationContexts = [];
            foreach ($payload as $item) {
                $invocationContexts[] = new InvocationContext(
                    $this->runtimeName,
                    $this->connectionData,
                    $item,
                    $this->isExecuted,
                    $this->isStateless
                );
            }

            return $invocationContexts;
        }

        $materialized = [];
        foreach ($payload as $item) {
            if ($item instanceof CommandInterface
                && $item->getCommandType()->equalsByValue(CommandType::ARRAY)) {
                $materialized[] = $this->materializeArrayPayload($item->getPayload());
            } else {
                $materialized[] = $item;
            }
        }

        return $materialized;
    }

    /**
     * @param $offset mixed
     */
    public function offsetExists($offset): bool
    {
        return is_int($offset) && $offset >= 0;
    }

    /**
     * @param $offset mixed
     * @throws Throwable
     */
    public function offsetGet($offset): InvocationContext
    {
        if (is_array($offset)) {
            return $this->getIndex(...$offset)->execute();
        }

        return $this->getIndex($offset)->execute();
    }

    /**
     * @param mixed $offset
     * @param mixed $value
     * @throws Throwable
     */
    public function offsetSet($offset, $value): void
    {
        $this->setIndex($offset, $value)->execute();
    }

    /**
     * @param $offset mixed
     */
    public function offsetUnset($offset): void
    {
        throw new UnsupportedOperationException('Unsetting array elements via ArrayAccess is not supported.');
    }
}

