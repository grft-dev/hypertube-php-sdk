<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class GetIndexHelper
{
    /**
     * @param array<mixed> $indexes
     * @param mixed $value
     */
    public static function tryGetIndexValue(
        ?CommandInterface $command,
        array $indexes,
        &$value
    ): bool {
        $value = null;
        $normalized = self::normalizeIndexes($indexes);
        if ($command === null || $normalized === null) {
            return false;
        }

        return self::tryResolveKnownValue($command, $normalized, 0, $value);
    }

    public static function getLocalArrayLength(?CommandInterface $command): int
    {
        $current = $command;
        while (
            $current instanceof CommandInterface
            && $current->getCommandType()->equalsByValue(CommandType::ARRAY_SET_ITEM)
            && $current->getPayloadSize() >= 3
        ) {
            $payload = $current->getPayload();
            $current = $payload[0] instanceof CommandInterface ? $payload[0] : null;
        }

        if (
            $current instanceof CommandInterface
            && $current->getCommandType()->equalsByValue(CommandType::ARRAY)
        ) {
            return $current->getPayloadSize();
        }

        return -1;
    }

    public static function tryApplySetIndexChain(
        ?CommandInterface $command,
        ?CommandInterface &$arrayCommand
    ): bool {
        $arrayCommand = null;
        if ($command === null) {
            return false;
        }

        if ($command->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            return self::tryToLocalArray($command, $arrayCommand);
        }

        if (
            !$command->getCommandType()->equalsByValue(CommandType::ARRAY_SET_ITEM)
            || $command->getPayloadSize() < 3
        ) {
            return false;
        }

        $payload = $command->getPayload();
        if (
            !($payload[0] instanceof CommandInterface)
            || !self::tryApplySetIndexChain($payload[0], $baseArray)
        ) {
            return false;
        }

        $indexes = self::normalizeIndexes([$payload[1]]);
        if (
            $indexes === null
            || !self::tryToLocalItem($payload[2], $item)
        ) {
            return false;
        }

        return self::trySetPath($baseArray, $indexes, 0, $item, $arrayCommand);
    }

    /**
     * @param mixed $node
     * @param array<int, int> $indexes
     * @param mixed $value
     */
    private static function tryResolveKnownValue(
        $node,
        array $indexes,
        int $position,
        &$value
    ): bool {
        $value = null;
        if ($position === count($indexes)) {
            $value = self::unwrapValue($node);
            return true;
        }

        $command = self::unwrapValue($node);
        if (!($command instanceof CommandInterface)) {
            return false;
        }

        $payload = $command->getPayload();
        if (
            $command->getCommandType()->equalsByValue(CommandType::ARRAY_SET_ITEM)
            && count($payload) >= 3
        ) {
            $setIndexes = self::normalizeIndexes([$payload[1]]);
            if ($setIndexes === null) {
                return false;
            }

            $remaining = count($indexes) - $position;
            $common = min($remaining, count($setIndexes));
            for ($i = 0; $i < $common; $i++) {
                if ($indexes[$position + $i] !== $setIndexes[$i]) {
                    return self::tryResolveKnownValue($payload[0], $indexes, $position, $value);
                }
            }

            if (count($setIndexes) > $remaining) {
                if (
                    !self::tryResolveKnownValue($payload[0], $indexes, $position, $element)
                    || !($element instanceof CommandInterface)
                    || !self::tryApplySetIndexChain($element, $elementArray)
                    || !self::tryToLocalItem($payload[2], $item)
                ) {
                    return false;
                }

                $belowIndexes = array_slice($setIndexes, $remaining);
                return self::trySetPath($elementArray, $belowIndexes, 0, $item, $value);
            }

            return self::tryResolveKnownValue(
                $payload[2],
                $indexes,
                $position + count($setIndexes),
                $value
            );
        }

        if ($command->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            $index = $indexes[$position];
            if ($index < 0 || $index >= count($payload)) {
                return false;
            }

            return self::tryResolveKnownValue($payload[$index], $indexes, $position + 1, $value);
        }

        return false;
    }

    /**
     * @param array<mixed> $indexes
     * @return array<int, int>|null
     */
    private static function normalizeIndexes(array $indexes): ?array
    {
        if (count($indexes) === 0) {
            return null;
        }

        $single = count($indexes) === 1 ? self::getPayloadValue($indexes[0]) : null;
        if (
            $single instanceof CommandInterface
            && $single->getCommandType()->equalsByValue(CommandType::ARRAY)
        ) {
            $flatIndexes = $single->getPayload();
        } elseif (is_array($single)) {
            $flatIndexes = $single;
        } else {
            $flatIndexes = $indexes;
        }

        if (count($flatIndexes) === 0) {
            return null;
        }

        $result = [];
        foreach ($flatIndexes as $index) {
            $index = self::getPayloadValue($index);
            if (!is_int($index)) {
                return null;
            }
            $result[] = $index;
        }

        return $result;
    }

    /**
     * @param mixed $item
     * @param mixed $localItem
     */
    private static function tryToLocalItem($item, &$localItem): bool
    {
        $localItem = null;
        if ($item instanceof CommandInterface) {
            if ($item->getCommandType()->equalsByValue(CommandType::VALUE)) {
                $localItem = self::unwrapValue($item);
                return true;
            }

            if (
                $item->getCommandType()->equalsByValue(CommandType::ARRAY)
                || $item->getCommandType()->equalsByValue(CommandType::ARRAY_SET_ITEM)
            ) {
                return self::tryApplySetIndexChain($item, $localItem);
            }
        }

        $localItem = $item;
        return true;
    }

    private static function tryToLocalArray(
        CommandInterface $arrayCommand,
        ?CommandInterface &$localArray
    ): bool {
        $localArray = null;
        $payload = [];
        foreach ($arrayCommand->getPayload() as $item) {
            if (!self::tryToLocalItem($item, $localItem)) {
                return false;
            }
            $payload[] = $localItem;
        }

        $localArray = new Command(
            $arrayCommand->getRuntimeName(),
            CommandType::ARRAY(),
            $payload
        );
        return true;
    }

    /**
     * @param array<int, int> $indexes
     * @param mixed $item
     * @param mixed $result
     */
    private static function trySetPath(
        CommandInterface $arrayCommand,
        array $indexes,
        int $position,
        $item,
        &$result
    ): bool {
        $result = null;
        $index = $indexes[$position];
        $payload = $arrayCommand->getPayload();
        if ($index < 0 || $index >= count($payload)) {
            return false;
        }

        if ($position === count($indexes) - 1) {
            $payload[$index] = $item;
        } else {
            $child = $payload[$index];
            if (
                !($child instanceof CommandInterface)
                || !$child->getCommandType()->equalsByValue(CommandType::ARRAY)
                || !self::trySetPath($child, $indexes, $position + 1, $item, $updatedChild)
            ) {
                return false;
            }
            $payload[$index] = $updatedChild;
        }

        $result = new Command(
            $arrayCommand->getRuntimeName(),
            CommandType::ARRAY(),
            $payload
        );
        return true;
    }

    /**
     * @param mixed $payloadItem
     * @return mixed
     */
    private static function unwrapValue($payloadItem)
    {
        $value = self::getPayloadValue($payloadItem);
        if (
            $value instanceof CommandInterface
            && $value->getCommandType()->equalsByValue(CommandType::VALUE)
            && $value->getPayloadSize() === 0
        ) {
            return null;
        }

        return $value;
    }

    /**
     * @param mixed $payloadItem
     * @return mixed
     */
    private static function getPayloadValue($payloadItem)
    {
        if (
            $payloadItem instanceof CommandInterface
            && $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
            && $payloadItem->getPayloadSize() > 0
        ) {
            return $payloadItem->getPayload()[0];
        }

        return $payloadItem;
    }
}
