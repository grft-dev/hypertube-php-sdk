<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;

final class NodejsTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'Date' => [self::class, 'parseDate'],
                'URL' => [self::class, 'parseUrl'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseDate(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseUrl(InvocationContext $invocationContext): Uri
    {
        return new Uri((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

}
