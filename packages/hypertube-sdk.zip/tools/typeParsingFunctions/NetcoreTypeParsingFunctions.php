<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateInterval;
use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\Color;
use HypertubePhpUtils\Point;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

final class NetcoreTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'System.DateTime' => [self::class, 'parseDateTime'],
                'System.DateTimeOffset' => [self::class, 'parseDateTimeOffset'],
                'System.Guid' => [self::class, 'parseGuid'],
                'System.Drawing.Point' => [self::class, 'parsePoint'],
                'System.Drawing.Color' => [self::class, 'parseColor'],
                'System.TimeOnly' => [self::class, 'parseTimeOnly'],
                'System.TimeSpan' => [self::class, 'parseTimeSpan'],
                'System.Uri' => [self::class, 'parseUri'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseDateTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseDateTimeOffset(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseGuid(InvocationContext $invocationContext): Uuid
    {
        return Uuid::fromString((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseUri(InvocationContext $invocationContext): Uri
    {
        return new Uri((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseTimeSpan(InvocationContext $invocationContext): DateInterval
    {
        return TypeParsingUtils::intervalFromTicks((int) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseTimeOnly(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseTimeOnEpochDay((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parsePoint(InvocationContext $invocationContext): Point
    {
        $payload = TypeParsingUtils::payload($invocationContext);

        return new Point((int) $payload[1], (int) $payload[2]);
    }

    public static function parseColor(InvocationContext $invocationContext): Color
    {
        $payload = TypeParsingUtils::payload($invocationContext);

        return new Color(
            TypeParsingUtils::colorChannel((int) $payload[2]),
            TypeParsingUtils::colorChannel((int) $payload[3]),
            TypeParsingUtils::colorChannel((int) $payload[4]),
            TypeParsingUtils::colorChannel((int) $payload[1])
        );
    }

}
