<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateInterval;
use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\Color;
use HypertubePhpUtils\Point;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

final class JavaTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'java.time.Instant' => [self::class, 'parseInstant'],
                'java.time.OffsetDateTime' => [self::class, 'parseOffsetDateTime'],
                'java.util.UUID' => [self::class, 'parseUuid'],
                'java.awt.Point' => [self::class, 'parsePoint'],
                'java.awt.Color' => [self::class, 'parseColor'],
                'java.time.LocalTime' => [self::class, 'parseLocalTime'],
                'java.time.Duration' => [self::class, 'parseDuration'],
                'java.net.URI' => [self::class, 'parseUri'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseInstant(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseOffsetDateTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseUuid(InvocationContext $invocationContext): Uuid
    {
        return Uuid::fromString((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseUri(InvocationContext $invocationContext): Uri
    {
        return new Uri((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseDuration(InvocationContext $invocationContext): DateInterval
    {
        $payload = TypeParsingUtils::payload($invocationContext);

        return TypeParsingUtils::intervalFromSecondsAndNanos((int) $payload[1], (int) $payload[2]);
    }

    /**
     * @throws Exception
     */
    public static function parseLocalTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseTimeOnEpochDay((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parsePoint(InvocationContext $invocationContext): Point
    {
        $payload = TypeParsingUtils::payload($invocationContext);

        return new Point((int) $payload[1], (int) $payload[2]);
    }

    public static function parseColor(InvocationContext $invocationContext): Color
    {
        $payload = TypeParsingUtils::payload($invocationContext);

        return new Color(
            TypeParsingUtils::colorChannel((int) $payload[2]),
            TypeParsingUtils::colorChannel((int) $payload[3]),
            TypeParsingUtils::colorChannel((int) $payload[4]),
            TypeParsingUtils::colorChannel((int) $payload[1])
        );
    }
}
