<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateInterval;
use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

final class PythonTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'datetime.datetime' => [self::class, 'parseDatetime'],
                'uuid.UUID' => [self::class, 'parseUuid'],
                'datetime.time' => [self::class, 'parseTime'],
                'datetime.timedelta' => [self::class, 'parseTimedelta'],
                'urllib.parse.ParseResult' => [self::class, 'parseUrl'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseDatetime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime(
            (string) TypeParsingUtils::payload($invocationContext)[1],
            true
        );
    }

    public static function parseUuid(InvocationContext $invocationContext): Uuid
    {
        return Uuid::fromString((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseTimeOnEpochDay((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseTimedelta(InvocationContext $invocationContext): DateInterval
    {
        return TypeParsingUtils::intervalFromMicroseconds((int) TypeParsingUtils::payload($invocationContext)[1]);
    }

    public static function parseUrl(InvocationContext $invocationContext): Uri
    {
        return new Uri((string) TypeParsingUtils::payload($invocationContext)[1]);
    }
}
