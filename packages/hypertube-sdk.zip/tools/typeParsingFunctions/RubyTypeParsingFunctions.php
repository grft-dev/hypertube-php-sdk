<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateInterval;
use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\Color;
use HypertubePhpUtils\type\CommandType;
use InvalidArgumentException;
use HypertubePhpUtils\Point;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

final class RubyTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'Time' => [self::class, 'parseTime'],
                'URI' => [self::class, 'parseUri'],
                'Hypertube::Utils::Uuid' => [self::class, 'parseUuid'],
                'Uuid' => [self::class, 'parseUuid'],
                'Hypertube::Utils::Duration' => [self::class, 'parseDuration'],
                'Duration' => [self::class, 'parseDuration'],
                'Hypertube::Utils::TimeOfDay' => [self::class, 'parseTimeOfDay'],
                'TimeOfDay' => [self::class, 'parseTimeOfDay'],
                'Hypertube::Utils::Point' => [self::class, 'parsePoint'],
                'Point' => [self::class, 'parsePoint'],
                'Hypertube::Utils::Color' => [self::class, 'parseColor'],
                'Color' => [self::class, 'parseColor'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return TypeParsingUtils::parseIsoDateTime(self::rubyTimeIsoFromInvocation($invocationContext));
    }

    /**
     * @throws Exception
     */
    private static function rubyTimeIsoFromInvocation(InvocationContext $invocationContext): string
    {
        $command = $invocationContext->getCurrentCommand();
        if ($command->getCommandType()->equalsByValue(CommandType::REFERENCE)) {
            $iso = (string) $invocationContext->invokeInstanceMethod('iso8601', 3)->execute()->getValue();

            return self::normalizeRubyTimeIso($iso);
        }

        $payload = TypeParsingUtils::payload($invocationContext);

        if (array_key_exists(1, $payload)) {
            $second = $payload[1];
            if ($second instanceof CommandInterface) {
                if ($second->getCommandType()->equalsByValue(CommandType::VALUE) && $second->getPayloadSize() > 0) {
                    return self::normalizeRubyTimeIso((string) $second->getPayload()[0]);
                }
            }

            return self::normalizeRubyTimeIso((string) $second);
        }

        foreach ($payload as $item) {
            if (!$item instanceof CommandInterface) {
                continue;
            }

            if ($item->getCommandType()->equalsByValue(CommandType::VALUE) && $item->getPayloadSize() > 0) {
                $candidate = (string) $item->getPayload()[0];
                if (str_contains($candidate, 'T')) {
                    return self::normalizeRubyTimeIso($candidate);
                }
            }

            if ($item->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE) && $item->getPayloadSize() >= 2) {
                return self::normalizeRubyTimeIso((string) $item->getPayloadByIndex(1));
            }
        }

        throw new InvalidArgumentException('Ruby Time result is missing an ISO timestamp in the command payload.');
    }

    private static function normalizeRubyTimeIso(string $iso): string
    {
        return str_replace('Z', '+00:00', $iso);
    }

    public static function parseUri(InvocationContext $invocationContext): Uri
    {
        if (self::isRubyReference($invocationContext)) {
            return new Uri((string) self::referenceMethodValue($invocationContext, 'to_s'));
        }

        return new Uri((string) self::wireValueAt($invocationContext, 1, 'Ruby URI'));
    }

    public static function parseUuid(InvocationContext $invocationContext): Uuid
    {
        if (self::isRubyReference($invocationContext)) {
            return Uuid::fromString((string) self::referenceMethodValue($invocationContext, 'to_s'));
        }

        return Uuid::fromString((string) self::wireValueAt($invocationContext, 1, 'Ruby Uuid'));
    }

    /**
     * @throws Exception
     */
    public static function parseDuration(InvocationContext $invocationContext): DateInterval
    {
        if (self::isRubyReference($invocationContext)) {
            $milliseconds = (float) self::referenceFieldValue($invocationContext, 'milliseconds');
        } else {
            $milliseconds = (float) self::wireValueAt($invocationContext, 1, 'Ruby Duration');
        }
        $microseconds = (int) round($milliseconds * 1000);

        return TypeParsingUtils::intervalFromMicroseconds($microseconds);
    }

    /**
     * @throws Exception
     */
    public static function parseTimeOfDay(InvocationContext $invocationContext): DateTimeImmutable
    {
        if (self::isRubyReference($invocationContext)) {
            $iso = sprintf(
                '%02d:%02d:%02d',
                (int) self::referenceFieldValue($invocationContext, 'hour'),
                (int) self::referenceFieldValue($invocationContext, 'min'),
                (int) self::referenceFieldValue($invocationContext, 'sec')
            );

            return TypeParsingUtils::parseTimeOnEpochDay($iso);
        }

        return TypeParsingUtils::parseTimeOnEpochDay((string) self::wireValueAt($invocationContext, 1, 'Ruby TimeOfDay'));
    }

    public static function parsePoint(InvocationContext $invocationContext): Point
    {
        if (self::isRubyReference($invocationContext)) {
            return new Point(
                (int) self::referenceFieldValue($invocationContext, 'x'),
                (int) self::referenceFieldValue($invocationContext, 'y')
            );
        }

        return new Point(
            (int) self::wireValueAt($invocationContext, 1, 'Ruby Point x'),
            (int) self::wireValueAt($invocationContext, 2, 'Ruby Point y')
        );
    }

    public static function parseColor(InvocationContext $invocationContext): Color
    {
        if (self::isRubyReference($invocationContext)) {
            return new Color(
                TypeParsingUtils::colorChannel((int) self::referenceFieldValue($invocationContext, 'r')),
                TypeParsingUtils::colorChannel((int) self::referenceFieldValue($invocationContext, 'g')),
                TypeParsingUtils::colorChannel((int) self::referenceFieldValue($invocationContext, 'b')),
                TypeParsingUtils::colorChannel((int) self::referenceFieldValue($invocationContext, 'a'))
            );
        }

        return new Color(
            TypeParsingUtils::colorChannel((int) self::wireValueAt($invocationContext, 2, 'Ruby Color r')),
            TypeParsingUtils::colorChannel((int) self::wireValueAt($invocationContext, 3, 'Ruby Color g')),
            TypeParsingUtils::colorChannel((int) self::wireValueAt($invocationContext, 4, 'Ruby Color b')),
            TypeParsingUtils::colorChannel((int) self::wireValueAt($invocationContext, 1, 'Ruby Color a'))
        );
    }

    private static function isRubyReference(InvocationContext $invocationContext): bool
    {
        return $invocationContext->getCurrentCommand()->getCommandType()->equalsByValue(CommandType::REFERENCE);
    }

    /**
     * @param mixed ...$args
     * @return mixed
     */
    private static function referenceMethodValue(InvocationContext $invocationContext, string $method, ...$args)
    {
        return $invocationContext->invokeInstanceMethod($method, ...$args)->execute()->getValue();
    }

    /**
     * @return mixed
     */
    private static function referenceFieldValue(InvocationContext $invocationContext, string $fieldName)
    {
        return $invocationContext->getInstanceField($fieldName)->execute()->getValue();
    }

    /**
     * @return mixed
     */
    private static function wireValueAt(InvocationContext $invocationContext, int $index, string $context)
    {
        $payload = TypeParsingUtils::payload($invocationContext);
        if (array_key_exists($index, $payload)) {
            return self::unwrapWireValue($payload[$index]);
        }

        $command = $invocationContext->getCurrentCommand();
        if ($command->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE)
            && $command->getPayloadSize() > $index) {
            return self::unwrapWireValue($command->getPayloadByIndex($index));
        }

        foreach ($payload as $item) {
            if (!$item instanceof CommandInterface) {
                continue;
            }

            if ($item->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE)
                && $item->getPayloadSize() > $index) {
                return self::unwrapWireValue($item->getPayloadByIndex($index));
            }
        }

        throw new InvalidArgumentException($context . ' is missing a value at wire index ' . $index . '.');
    }

    /**
     * @param mixed $item
     * @return mixed
     */
    private static function unwrapWireValue($item)
    {
        if ($item instanceof CommandInterface
            && $item->getCommandType()->equalsByValue(CommandType::VALUE)
            && $item->getPayloadSize() > 0) {
            return $item->getPayload()[0];
        }

        return $item;
    }

}
