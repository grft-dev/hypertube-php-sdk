<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools\typeParsingFunctions;

use DateInterval;
use DateTime;
use DateTimeImmutable;
use Exception;
use HypertubePhpCore\referencecache\ReferencesCache;
use HypertubePhpSdk\InvocationContext;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\typeParsing\TypeParsingUtils;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;
use Throwable;

final class PhpTypeParsingFunctions
{
    /** @var array<string, callable>|null */
    private static ?array $parsingFunctions = null;

    /**
     * @return array<string, callable>
     */
    public static function parsingFunctions(): array
    {
        if (self::$parsingFunctions === null) {
            self::$parsingFunctions = [
                'DateTime' => [self::class, 'parseDateTime'],
                'DateTimeImmutable' => [self::class, 'parseDateTimeImmutable'],
                'DateInterval' => [self::class, 'parseDateInterval'],
                Uuid::class => [self::class, 'parseUuid'],
                Uri::class => [self::class, 'parseUri'],
            ];
        }

        return self::$parsingFunctions;
    }

    /**
     * @throws Exception
     */
    public static function parseDateTime(InvocationContext $invocationContext): DateTimeImmutable
    {
        return self::parseDateTimeValue($invocationContext);
    }

    /**
     * @throws Exception
     */
    public static function parseDateTimeImmutable(InvocationContext $invocationContext): DateTimeImmutable
    {
        return self::parseDateTimeValue($invocationContext);
    }

    public static function parseUuid(InvocationContext $invocationContext): Uuid
    {
        $resolved = self::resolveReference($invocationContext);
        if ($resolved instanceof Uuid) {
            return $resolved;
        }

        $payload = TypeParsingUtils::payload($invocationContext);
        $command = $invocationContext->getCurrentCommand();
        if (
            $command->getCommandType()->equalsByValue(CommandType::INVOKE_STATIC_METHOD)
            && isset($payload[1])
            && (string) $payload[1] === 'fromString'
            && isset($payload[2])
        ) {
            return Uuid::fromString((string) $payload[2]);
        }

        return Uuid::fromString((string) $payload[1]);
    }

    public static function parseUri(InvocationContext $invocationContext): Uri
    {
        $resolved = self::resolveReference($invocationContext);
        if ($resolved instanceof Uri) {
            return $resolved;
        }

        return new Uri((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @throws Exception
     */
    public static function parseDateInterval(InvocationContext $invocationContext): DateInterval
    {
        $resolved = self::resolveReference($invocationContext);
        if ($resolved instanceof DateInterval) {
            return $resolved;
        }

        return TypeParsingUtils::createDateInterval([TypeParsingUtils::payload($invocationContext)[1]]);
    }

    /**
     * @throws Exception
     */
    private static function parseDateTimeValue(InvocationContext $invocationContext): DateTimeImmutable
    {
        $resolved = self::resolveReference($invocationContext);
        if ($resolved instanceof DateTimeImmutable) {
            return $resolved;
        }
        if ($resolved instanceof DateTime) {
            return DateTimeImmutable::createFromMutable($resolved);
        }

        return TypeParsingUtils::parseIsoDateTime((string) TypeParsingUtils::payload($invocationContext)[1]);
    }

    /**
     * @return mixed
     */
    private static function resolveReference(InvocationContext $invocationContext)
    {
        $command = $invocationContext->getCurrentCommand();
        if (!$command->getCommandType()->equalsByValue(CommandType::REFERENCE)) {
            return null;
        }

        $uuid = (string) $command->getPayloadByIndex(0);
        try {
            return ReferencesCache::getInstance()->resolveReference($uuid);
        } catch (Throwable $exception) {
            return null;
        }
    }
}
