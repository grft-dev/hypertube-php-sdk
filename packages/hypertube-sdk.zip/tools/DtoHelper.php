<?php

declare(strict_types=1);

namespace sdk\tools;

use utils\CommandInterface;
use utils\type\CommandType;

final class DtoHelper
{
	/**
	 * @return mixed
     */
	public static function tryGetDtoFieldValue(CommandInterface $command, string $fieldName)
	{
		$currentCommand = $command;

		while ($currentCommand !== null) {
			if (
				$currentCommand->getCommandType()->equalsByValue(CommandType::SET_INSTANCE_FIELD)
				&& self::tryGetDtoFieldName($currentCommand)
				&& self::getDtoFieldName($currentCommand) === $fieldName
			) {
				return self::tryGetDtoFieldValueFromCommand($currentCommand);
			}

			$payload = $currentCommand->getPayload();
			if ($payload === null || count($payload) === 0) {
				break;
			}

			$firstPayload = $payload[0];
			$currentCommand = $firstPayload instanceof CommandInterface ? $firstPayload : null;
		}

		return null;
	}

	private static function tryGetDtoFieldName(CommandInterface $command): bool
	{
		if ($command->getPayloadSize() < 2) {
			return false;
		}

		$nameValue = self::tryGetPayloadValue($command->getPayload()[1]);

		return is_string($nameValue);
	}

	private static function getDtoFieldName(CommandInterface $command): string
	{
		if ($command->getPayloadSize() < 2) {
			return '';
		}

		$nameValue = self::tryGetPayloadValue($command->getPayload()[1]);

		return is_string($nameValue) ? $nameValue : '';
	}

	/**
	 * @return mixed
	 */
	private static function tryGetDtoFieldValueFromCommand(CommandInterface $command)
	{
		if ($command->getPayloadSize() < 3) {
			return null;
		}

		return self::tryGetPayloadValue($command->getPayload()[2]);
	}

	/**
	 * @param mixed $payloadItem
	 * @return mixed
	 */
	private static function tryGetPayloadValue($payloadItem)
	{
		if (
			$payloadItem instanceof CommandInterface
			&& $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
			&& $payloadItem->getPayloadSize() > 0
		) {
			return $payloadItem->getPayload()[0];
		}

		return $payloadItem;
	}
}
