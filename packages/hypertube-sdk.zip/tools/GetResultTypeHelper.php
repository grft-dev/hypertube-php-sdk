<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class GetResultTypeHelper
{
    public static function getResultType(?CommandInterface $command): ?string
    {
        return self::resolveResultType($command, 0);
    }

    /**
     * @param mixed $node
     */
    private static function resolveResultType($node, int $depth): ?string
    {
        if ($node instanceof CommandInterface) {
            return self::resolveCommandResultType($node, $depth);
        }

        if (is_array($node)) {
            return self::resolvePayloadResultType($node, $depth + 1);
        }

        return null;
    }

    private static function resolveCommandResultType(CommandInterface $command, int $depth): ?string
    {
        if ($command === null || $command->getPayload() === null || $command->getPayloadSize() === 0) {
            return null;
        }

        if (
            $command->getCommandType()->equalsByValue(CommandType::GET_RESULT_TYPE)
            || $command->getCommandType()->equalsByValue(CommandType::GET_TYPE)
            || $command->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE)
        ) {
            foreach ($command->getPayload() as $item) {
                $val = self::getPayloadValue($item);
                if (is_string($val)) {
                    return self::applyArrayDepth($val, $depth);
                }
                if ($val !== null) {
                    return self::resolveResultType($val, $depth);
                }
            }

            return null;
        }

        if ($command->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            return self::resolvePayloadResultType($command->getPayload(), $depth + 1);
        }

        return self::resolveResultType($command->getPayload()[0] ?? null, $depth);
    }

    /**
     * @param array<mixed> $payload
     */
    private static function resolvePayloadResultType(array $payload, int $depth): ?string
    {
        foreach ($payload as $item) {
            $result = self::resolveResultType($item, $depth);
            if ($result !== null) {
                return $result;
            }
        }

        return null;
    }

    private static function applyArrayDepth(string $typeName, int $depth): string
    {
        if ($depth <= 0) {
            return $typeName;
        }

        return $typeName . str_repeat('[]', $depth);
    }

    /**
     * @param mixed $payloadItem
     * @return mixed
     */
    private static function getPayloadValue($payloadItem)
    {
        if (
            $payloadItem instanceof CommandInterface
            && $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
            && $payloadItem->getPayloadSize() > 0
        ) {
            return $payloadItem->getPayload()[0];
        }

        return $payloadItem;
    }
}
