<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class GetInstanceFieldHelper
{
    /**
     * @return mixed
     */
    public static function getFieldValue(?CommandInterface $command, string $fieldName)
    {
        if ($command === null || $command->getPayload() === null || $command->getPayloadSize() === 0) {
            return null;
        }

        if (
            $command->getCommandType()->equalsByValue(CommandType::SET_INSTANCE_FIELD)
            && $command->getPayloadSize() >= 3
        ) {
            $name = self::getPayloadValue($command->getPayload()[1]);
            if (is_string($name) && $name === $fieldName) {
                return self::getPayloadValue($command->getPayload()[2]);
            }
        }

        if ($command->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            foreach ($command->getPayload() as $item) {
                if ($item instanceof CommandInterface) {
                    $result = self::getFieldValue($item, $fieldName);
                    if ($result !== null) {
                        return $result;
                    }
                }
            }

            return null;
        }

        $firstPayload = $command->getPayload()[0] ?? null;
        return $firstPayload instanceof CommandInterface
            ? self::getFieldValue($firstPayload, $fieldName)
            : null;
    }

    public static function getResultType(?CommandInterface $command): ?string
    {
        if ($command === null || $command->getPayload() === null || $command->getPayloadSize() === 0) {
            return null;
        }

        if (
            $command->getCommandType()->equalsByValue(CommandType::GET_RESULT_TYPE)
            || $command->getCommandType()->equalsByValue(CommandType::GET_TYPE)
            || $command->getCommandType()->equalsByValue(CommandType::COMPLEX_VALUE_TYPE)
        ) {
            $val = self::getPayloadValue($command->getPayload()[0]);
            return is_string($val) ? $val : null;
        }

        if ($command->getCommandType()->equalsByValue(CommandType::ARRAY)) {
            foreach ($command->getPayload() as $item) {
                if ($item instanceof CommandInterface) {
                    $result = self::getResultType($item);
                    if ($result !== null) {
                        return $result;
                    }
                }
            }

            return null;
        }

        $firstPayload = $command->getPayload()[0] ?? null;
        return $firstPayload instanceof CommandInterface
            ? self::getResultType($firstPayload)
            : null;
    }

    /**
     * @param mixed $payloadItem
     * @return mixed
     */
    private static function getPayloadValue($payloadItem)
    {
        if (
            $payloadItem instanceof CommandInterface
            && $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
            && $payloadItem->getPayloadSize() > 0
        ) {
            return $payloadItem->getPayload()[0];
        }

        return $payloadItem;
    }
}
