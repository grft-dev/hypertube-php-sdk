<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

final class ActivatorDetails
{
    public string $type;

    /** @var array<int, mixed>|null */
    public ?array $arguments;

    /**
     * @param array<int, mixed>|null $arguments
     */
    public function __construct(string $type, ?array $arguments)
    {
        $this->type = $type;
        $this->arguments = $arguments;
    }
}
