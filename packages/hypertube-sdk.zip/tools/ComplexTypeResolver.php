<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use HypertubePhpSdk\InvocationContext;
use HypertubePhpSdk\tools\typeParsingFunctions\JavaTypeParsingFunctions;
use HypertubePhpSdk\tools\typeParsingFunctions\NetcoreTypeParsingFunctions;
use HypertubePhpSdk\tools\typeParsingFunctions\NodejsTypeParsingFunctions;
use HypertubePhpSdk\tools\typeParsingFunctions\PhpTypeParsingFunctions;
use HypertubePhpSdk\tools\typeParsingFunctions\PythonTypeParsingFunctions;
use HypertubePhpSdk\tools\typeParsingFunctions\RubyTypeParsingFunctions;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\error\UnsupportedPayloadItemTypeError;
use HypertubePhpUtils\parsableValueType\ParsableValueTypeOutbound;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;
use InvalidArgumentException;
use Throwable;

final class ComplexTypeResolver
{
    /** @var array<string, ActivatorDetails> */
    private array $typeMap = [];

    /** @var array<int, array<string, callable>>|null */
    private static ?array $typeParsingFunctions = null;

    /**
     * @param array<int, mixed>|null $args
     */
    public function register(string $resultType, string $type, ?array $args): void
    {
        $this->typeMap[$resultType] = new ActivatorDetails($type, $args);
    }

    /**
     * @return mixed
     * @throws Throwable
     */
    public function convertResult(InvocationContext $ic)
    {
        $runtimeName = $ic->getRuntimeName();

        if ($ic->isStateless()) {
            $currentCommand = $ic->getCurrentCommand();

            if ($currentCommand->getCommandType()->equalsByValue(CommandType::ARRAY)) {
                $arr = $ic->retrieveArray();
                $result = [];
                foreach ($arr as $payloadItem) {
                    /** @var InvocationContext $payloadItem */
                    $itemResultType = $payloadItem->getResultType();
                    if ($itemResultType === null || $itemResultType === '') {
                        $result[] = $payloadItem;
                        continue;
                    }

                    if (!isset($this->typeMap[$itemResultType])) {
                        throw new InvalidArgumentException('No type registered for key: ' . $itemResultType);
                    }

                    $className = $this->typeMap[$itemResultType]->type;
                    $result[] = new $className($payloadItem);
                }

                return $result;
            }

            $resultType = $ic->getResultType();
            if ($resultType === null || $resultType === '') {
                return $ic->getValue();
            }

            $parsingFn = $this->findParsingFunction($runtimeName, (string) $resultType);
            if ($parsingFn !== null) {
                return $parsingFn($ic);
            }

            if (!isset($this->typeMap[$resultType])) {
                throw new InvalidArgumentException('No type registered for key: '. $resultType);
            }

            $className = $this->typeMap[$resultType]->type;

            return new $className($ic);
        }

        $resultType = $ic->getResultType();
        $materializedResultType = is_string($resultType) ? $resultType : '';

        $elementType = null;
        if ($this->tryGetUnderlyingArrayType($materializedResultType, $elementType)) {
            if ($elementType === null) {
                throw new InvalidArgumentException('No underlying type registered for array type '. $materializedResultType);
            }

            $array = $ic->retrieveArray();
            $objectArray = [];
            foreach ($array as $item) {
                $objectArray[] = new $elementType($item);
            }

            return $objectArray;
        }

        $parsingFn = $this->findParsingFunction($runtimeName, $materializedResultType);
        if ($parsingFn !== null) {
            return $parsingFn($ic);
        }

        if (!isset($this->typeMap[$materializedResultType])) {
            throw new InvalidArgumentException('No type registered for key: ' . $materializedResultType);
        }

        $details = $this->typeMap[$materializedResultType];
        $className = $details->type;
        $arguments = $details->arguments === null ? [] : $details->arguments;

        if ($arguments === []) {
            return new $className();
        }

        return new $className(...$arguments);
    }

    /**
     * @param mixed $payloadItem
     */
    public function convertComplexTypeToCommand(RuntimeName $runtimeName, $payloadItem): CommandInterface
    {
        if (!is_object($payloadItem)) {
            throw new UnsupportedPayloadItemTypeError($payloadItem);
        }

        return ParsableValueTypeOutbound::toCommand($runtimeName, $payloadItem);
    }

    /**
     * @param mixed $elementType
     */
    private function tryGetUnderlyingArrayType(string $type, &$elementType): bool
    {
        $elementType = null;

        if (trim($type) === '') {
            return false;
        }

        $trimmed = trim($type);
        $typePart = $trimmed;
        $assemblyComma = strpos($typePart, ',');
        if ($assemblyComma !== false && $assemblyComma > 0) {
            $typePart = trim(substr($typePart, 0, $assemblyComma));
        }

        $baseTypeName = null;

        if (strpos($typePart, '[]') !== false) {
            $tmp = $typePart;
            while (substr($tmp, -2) === '[]') {
                $tmp = substr($tmp, 0, -2);
            }
            $baseTypeName = $tmp;
        }

        if ($baseTypeName === null) {
            $idx = strpos($typePart, '[');
            if ($idx !== false && $idx > 0 && substr($typePart, -1) === ']') {
                $baseTypeName = substr($typePart, 0, $idx);
            }
        }

        if ($baseTypeName === null || trim($baseTypeName) === '') {
            return false;
        }

        $commaIndex = strpos($baseTypeName, ',');
        if ($commaIndex !== false && $commaIndex > 0) {
            $baseTypeName = trim(substr($baseTypeName, 0, $commaIndex));
        }

        $baseTypeName = trim($baseTypeName);

        $primitives = [
            'bool' => true,
            'boolean' => true,
            'system.boolean' => true,
            'byte' => true,
            'system.byte' => true,
            'sbyte' => true,
            'system.sbyte' => true,
            'char' => true,
            'system.char' => true,
            'decimal' => true,
            'system.decimal' => true,
            'double' => true,
            'system.double' => true,
            'float' => true,
            'system.single' => true,
            'single' => true,
            'int' => true,
            'system.int32' => true,
            'system.int' => true,
            'uint' => true,
            'system.uint32' => true,
            'long' => true,
            'system.int64' => true,
            'ulong' => true,
            'system.uint64' => true,
            'short' => true,
            'system.int16' => true,
            'ushort' => true,
            'system.uint16' => true,
            'object' => true,
            'system.object' => true,
            'string' => true,
            'system.string' => true,
        ];

        if (isset($primitives[strtolower($baseTypeName)])) {
            throw new InvalidArgumentException('Primitive array element types are not supported.');
        }

        $candidates = [
            $baseTypeName,
            str_replace('/', '.', $baseTypeName),
            str_replace('+', '.', $baseTypeName),
            str_replace(['/', '+'], '.', $baseTypeName),
        ];

        foreach ($candidates as $candidate) {
            if ($candidate === '') {
                continue;
            }
            if (isset($this->typeMap[$candidate]) && $this->typeMap[$candidate]->type !== '') {
                $elementType = $this->typeMap[$candidate]->type;

                return true;
            }
        }

        return false;
    }

    private function findParsingFunction(RuntimeName $runtimeName, string $resultType): ?callable
    {
        $tables = self::typeParsingFunctions();
        $runtimeKey = $runtimeName->getValue();
        if (!isset($tables[$runtimeKey])) {
            return null;
        }

        $runtimeDict = $tables[$runtimeKey];
        if (isset($runtimeDict[$resultType])) {
            return $runtimeDict[$resultType];
        }

        $bestFn = null;
        $bestLen = -1;
        foreach ($runtimeDict as $key => $fn) {
            if (!$this->isParsingKeyPrefixMatch($resultType, $key)) {
                continue;
            }
            $keyLen = strlen($key);
            if ($keyLen > $bestLen) {
                $bestFn = $fn;
                $bestLen = $keyLen;
            }
        }

        return $bestFn;
    }

    private function isParsingKeyPrefixMatch(string $resultType, string $key): bool
    {
        if ($key === '') {
            return false;
        }

        if (strpos($resultType, $key) !== 0) {
            return false;
        }

        $keyLen = strlen($key);
        if (strlen($resultType) === $keyLen) {
            return true;
        }

        if ($resultType[$keyLen] === ',') {
            return true;
        }

        return $key === 'URI' && $resultType[$keyLen] === ':';
    }

    /**
     * @return array<int, array<string, callable>>
     */
    private static function typeParsingFunctions(): array
    {
        if (self::$typeParsingFunctions === null) {
            self::$typeParsingFunctions = [
                RuntimeName::NETCORE => NetcoreTypeParsingFunctions::parsingFunctions(),
                RuntimeName::JVM => JavaTypeParsingFunctions::parsingFunctions(),
                RuntimeName::NODEJS => NodejsTypeParsingFunctions::parsingFunctions(),
                RuntimeName::PYTHON => PythonTypeParsingFunctions::parsingFunctions(),
                RuntimeName::PHP => PhpTypeParsingFunctions::parsingFunctions(),
                RuntimeName::RUBY => RubyTypeParsingFunctions::parsingFunctions(),
            ];
        }

        return self::$typeParsingFunctions;
    }

}
