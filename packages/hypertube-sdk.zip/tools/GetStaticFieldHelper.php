<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class GetStaticFieldHelper
{
    /**
     * @param mixed $value
     */
    public static function tryGetFieldValue(
        ?CommandInterface $command,
        string $fieldName,
        &$value
    ): bool {
        $value = null;
        $current = $command;
        while (
            $current instanceof CommandInterface
            && $current->getCommandType()->equalsByValue(CommandType::SET_STATIC_FIELD)
            && $current->getPayloadSize() >= 3
        ) {
            $payload = $current->getPayload();
            $name = self::getPayloadValue($payload[1]);
            if (is_string($name) && $name === $fieldName) {
                return self::tryUnwrapValue($payload[2], $value);
            }

            $current = $payload[0] instanceof CommandInterface ? $payload[0] : null;
        }

        return false;
    }

    /**
     * @param mixed $payloadItem
     * @param mixed $value
     */
    private static function getPayloadValue($payloadItem)
    {
        if (
            $payloadItem instanceof CommandInterface
            && $payloadItem->getCommandType()->equalsByValue(CommandType::VALUE)
            && $payloadItem->getPayloadSize() > 0
        ) {
            return $payloadItem->getPayload()[0];
        }

        return $payloadItem;
    }

    /**
     * @param mixed $payloadItem
     * @return mixed
     */
    private static function tryUnwrapValue($payloadItem, &$value): bool
    {
        $value = self::getPayloadValue($payloadItem);
        if (
            $value instanceof CommandInterface
            && $value->getCommandType()->equalsByValue(CommandType::VALUE)
            && $value->getPayloadSize() === 0
        ) {
            $value = null;
            return false;
        }

        return true;
    }
}
