<?php

declare(strict_types=1);

namespace HypertubePhpSdk\tools;

use GuzzleHttp\Promise\Create;
use GuzzleHttp\Promise\Promise;
use GuzzleHttp\Promise\PromiseInterface;
use HypertubePhpUtils\Uri;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

class HttpConnection
{
    private const REQUEST_TIMEOUT_SECONDS = 3;
    private URI $uri;
    private HttpClientInterface $client;

    public function __construct(URI $uri, ?HttpClientInterface $client = null)
    {
        $this->uri = $uri;
        $this->client = $client ?? HttpClient::create([
            'timeout' => self::REQUEST_TIMEOUT_SECONDS,
        ]);
    }

    public function sendAsync(string $payload): PromiseInterface
    {
        try {
            $response = $this->client->request('POST', $this->uri->toString(), [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                ],
                'body' => $payload,
                'timeout' => self::REQUEST_TIMEOUT_SECONDS,
            ]);

            $promise = null;
            $promise = new Promise(
                static function () use (&$promise, $response): void {
                    try {
                        // false = do not throw on 4xx/5xx; also clears initializer so
                        // Response::__destruct will not throw ClientException later.
                        $response->getContent(false);
                        $promise->resolve($response->getStatusCode());
                    } catch (Throwable $throwable) {
                        try {
                            $response->cancel();
                        } catch (Throwable $ignored) {
                        }
                        $promise->reject($throwable);
                    }
                },
                static function () use ($response): void {
                    $response->cancel();
                }
            );

            return $promise;
        } catch (Throwable $throwable) {
            return Create::rejectionFor($throwable);
        }
    }
}
