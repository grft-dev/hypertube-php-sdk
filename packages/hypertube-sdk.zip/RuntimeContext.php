<?php

declare(strict_types=1);

namespace sdk;

use ReflectionMethod;
use ReflectionType;
use RuntimeException;
use Throwable;
use core\delegatecache\DelegatesCache;
use core\interpreter\Interpreter;
use core\transmitter\Transmitter;
use sdk\configuration\Config;
use sdk\internal\AbstractModuleContext;
use sdk\internal\AbstractRuntimeContext;
use sdk\internal\AbstractTypeContext;
use utils\Command;
use utils\CommandInterface;
use utils\connectiondata\IConnectionData;
use utils\connectiondata\Http2ConnectionData;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\PluginConnectionData;
use utils\connectiondata\TcpConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\error\UnsupportedPayloadItemTypeError;
use utils\exception\ExceptionThrower;
use utils\messagehelper\MessageHelper;
use utils\RuntimeName;
use utils\type\CommandType;
use utils\type\ConnectionType;
use utils\TypesHandler;
use utils\UtilsConst;

final class RuntimeContext implements AbstractTypeContext, AbstractModuleContext, AbstractRuntimeContext
{
    /** @var array<string, RuntimeContext> */
    private static array $memoryRuntimeContexts = [];

    /** @var array<string, RuntimeContext> */
    private static array $networkRuntimeContexts = [];
    /** @var array<string, RuntimeContext> */
    private static array $pluginRuntimeContexts = [];

    /** @var array<string, RuntimeContext> */
    private static array $webSocketRuntimeContexts = [];
    /** @var array<string, RuntimeContext> */
    private static array $http2RuntimeContexts = [];
    private RuntimeName $runtimeName;
    private IConnectionData $connectionData;
    private ?CommandInterface $currentCommand = null;
    public bool $isStateless = false;
    public function getRuntimeName(): RuntimeName
    {
        return $this->runtimeName;
    }

    public function getConnectionData(): IConnectionData
    {
        return $this->connectionData;
    }

    public function setConnectionData(IConnectionData $connectionData): void
    {
        $this->connectionData = $connectionData;
    }


    private function __construct(
        RuntimeName $runtimeName,
        IConnectionData $IConnectionData
    ) {
        $this->runtimeName = $runtimeName;
        $this->connectionData = $IConnectionData;
        // Interpreter is now static, no instance needed

        MessageHelper::getInstance()->sendMessageToAppInsights('SdkMessage', $runtimeName->getName() . ' initialized');

        $connectionType = $this->connectionData->getConnectionType();
        if ($connectionType->equalsByValue(ConnectionType::WEB_SOCKET) || $connectionType->equalsByValue(ConnectionType::HTTP2)) {
            return;
        }

        if ($this->runtimeName->equalsByValue(RuntimeName::PHP)
            && $connectionType->equalsByValue(ConnectionType::IN_MEMORY)
        ) {
            return;
        }

        Transmitter::setWorkingDirectory(UtilsConst::getWorkingDirectory());

        if (UtilsConst::isNotEmptyConfigSource()) {
            Transmitter::setConfigSource(UtilsConst::getConfigSource());
        }

        Transmitter::activate(UtilsConst::getLicenseKey());
    }

    public static function initializeRuntimeContext(Config $config): RuntimeContext
    {
        try {
            $connectionData = $config->getConnectionData();
            $runtime = $config->getRuntime();

            $runtimeCtx = self::getInstance($runtime, $connectionData);

            $runtimeCtx->isStateless = $config->isStateless();

            if ($connectionData instanceof InMemoryConnectionData) {
                $modulesStr = $config->getModules() ?? '';
                if ($modulesStr !== '' && trim($modulesStr) !== '') {
                    $modules = array_filter(array_map('trim', explode(',', $modulesStr)), static function ($m) {
                        return $m !== '';
                    });
                    foreach ($modules as $module) {
                        $path = realpath($module) ?: $module;
                        $runtimeCtx->loadLibrary($path);
                    }
                }
            }

            return $runtimeCtx;
        } catch (Throwable $t) {
            error_log(sprintf(
                'initializeRuntimeContext failed: %s in %s:%d',
                $t->getMessage(),
                $t->getFile(),
                $t->getLine()
            ));
            throw new RuntimeException('Failed to initialize RuntimeContext', 0, $t);
        }
    }

    public static function getInstance(RuntimeName $runtimeName, IConnectionData $IConnectionData): RuntimeContext
    {
        $connectionType = $IConnectionData->getConnectionType();
        switch ($connectionType->getValue()) {
            case ConnectionType::IN_MEMORY:
                if (isset(self::$memoryRuntimeContexts[$runtimeName->getName()])) {
                    $runtimeCtx = self::$memoryRuntimeContexts[$runtimeName->getName()];
                } else {
                    $runtimeCtx = new RuntimeContext($runtimeName, $IConnectionData);
                    self::$memoryRuntimeContexts[$runtimeName->getName()] = $runtimeCtx;
                }
                break;

            case ConnectionType::TCP:
                $key = self::buildConnectionCacheKey($runtimeName, $IConnectionData);
                if (isset(self::$networkRuntimeContexts[$key])) {
                    $runtimeCtx = self::$networkRuntimeContexts[$key];
                } else {
                    $runtimeCtx = new RuntimeContext($runtimeName, $IConnectionData);
                    self::$networkRuntimeContexts[$key] = $runtimeCtx;
                }
                break;
            case ConnectionType::PLUGIN:
                $key = self::buildConnectionCacheKey($runtimeName, $IConnectionData);
                if (isset(self::$pluginRuntimeContexts[$key])) {
                    $runtimeCtx = self::$pluginRuntimeContexts[$key];
                } else {
                    $runtimeCtx = new RuntimeContext($runtimeName, $IConnectionData);
                    self::$pluginRuntimeContexts[$key] = $runtimeCtx;
                }
                break;

            case ConnectionType::WEB_SOCKET:
                $key = self::buildConnectionCacheKey($runtimeName, $IConnectionData);
                if (isset(self::$webSocketRuntimeContexts[$key])) {
                    $runtimeCtx = self::$webSocketRuntimeContexts[$key];
                } else {
                    $runtimeCtx = new RuntimeContext($runtimeName, $IConnectionData);
                    self::$webSocketRuntimeContexts[$key] = $runtimeCtx;
                }
                break;
            case ConnectionType::HTTP2:
                $key = self::buildConnectionCacheKey($runtimeName, $IConnectionData);
                if (isset(self::$http2RuntimeContexts[$key])) {
                    $runtimeCtx = self::$http2RuntimeContexts[$key];
                } else {
                    $runtimeCtx = new RuntimeContext($runtimeName, $IConnectionData);
                    self::$http2RuntimeContexts[$key] = $runtimeCtx;
                }
                break;

            default:
                throw new RuntimeException('Unknown connection type: ' . $connectionType->getName());
        }

        $runtimeCtx->currentCommand = null;

        return $runtimeCtx;
    }

    private static function buildConnectionCacheKey(RuntimeName $runtimeName, IConnectionData $IConnectionData): string
    {
        if ($IConnectionData === null) {
            throw new RuntimeException('Connection data cannot be null for network connections.');
        }
        return $runtimeName->getName() . '|' . $IConnectionData->toCanonicalKey();
    }

    /**
     * @throws Throwable
     */
    public function loadLibrary(string $libraryPath): RuntimeContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::LOAD_LIBRARY(), $libraryPath);
        $this->currentCommand = $this->buildCommand($localCommand);
        $this->execute();

        return $this;
    }

    /**
     * @throws Throwable
     */
    public function execute(): void
    {
        if ($this->currentCommand === null) {
            return;
        }

        $responseCommand = null;
        $responseCommand = Interpreter::execute($this->currentCommand, $this->connectionData);
        $this->currentCommand = null;

        if ($responseCommand->getCommandType()->equalsByValue(CommandType::EXCEPTION)) {
            ExceptionThrower::throwException($responseCommand);
        }
    }

    public function getType(string $typeName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_TYPE(), $typeName, ...$args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    private function buildInvocationContext(CommandInterface $command): InvocationContext
    {
        return new InvocationContext(
            $this->runtimeName,
            $this->connectionData,
            $this->buildCommand($command),
            false,
            $this->isStateless
        );
    }

    private function buildCommand(?CommandInterface $command): CommandInterface
    {
        if ($command === null || $command->getPayload() === null) {
            return $this->currentCommand;
        }

        foreach ($command->getPayload() as $key => $item) {
            $command->setPayload($key, $this->encapsulatePayloadItem($item));
        }

        return $command->prependArgumentToPayload($this->currentCommand);
    }

    /**
     * @param mixed $payloadItem
     */
    private function encapsulatePayloadItem($payloadItem): CommandInterface
    {
        if ($payloadItem === null) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof CommandInterface) {
            if ($payloadItem->getCommandType()->equalsByValue(CommandType::VALUE())
                || $payloadItem->getCommandType()->equalsByValue(CommandType::ARRAY())) {
                return $payloadItem;
            }

            foreach ($payloadItem->getPayload() as $key => $item) {
                $payloadItem->setPayload($key, $this->encapsulatePayloadItem($item));
            }

            return $payloadItem;
        }

        if ($payloadItem instanceof InvocationContext) {
            return $payloadItem->getCurrentCommand();
        }

        if ($payloadItem instanceof ReflectionType) {
            return new Command($this->runtimeName, CommandType::CONVERT_TYPE(), TypesHandler::convertTypeToHypertubeType($payloadItem));
        }

        if (is_array($payloadItem)) {
            $encapsulatedArray = [];
            foreach ($payloadItem as $item) {
                $encapsulatedArray[] = $this->encapsulatePayloadItem($item);
            }
            return new Command($this->runtimeName, CommandType::ARRAY(), $encapsulatedArray);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof ReflectionMethod) {
            $types = [];
            foreach ($payloadItem->getParameters() as $param) {
                $types[] = $param->getType() ? $param->getType()->getName() : 'mixed';
            }

            $returnType = $payloadItem->getReturnType();
            $types[] = $returnType ? $returnType->getName() : 'mixed';

            $delegateId = DelegatesCache::getInstance()->addDelegate($payloadItem);
            $args = array_merge([$delegateId, RuntimeName::PHP], $types);

            $encapsulatedArgs = [];
            foreach ($args as $arg) {
                $encapsulatedArgs[] = $this->encapsulatePayloadItem($arg);
            }

            return new Command($this->runtimeName, CommandType::PASS_DELEGATE(), $encapsulatedArgs);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        throw new UnsupportedPayloadItemTypeError($payloadItem);
    }

    public function invokeGlobalFunction(string $functionName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GLOBAL_FUNCTION(), $functionName, ...$args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    public function getEnumItem(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_ITEM(), $args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    public function cast(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CAST(), $args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    public function invokeGlobalMethod(string $functionName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GLOBAL_FUNCTION(), $functionName, ...$args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    public function asOut(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::AS_OUT(), $args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }

    public function asRef(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::AS_REF(), $args);
        $this->currentCommand = null;

        return $this->buildInvocationContext($localCommand);
    }
}
