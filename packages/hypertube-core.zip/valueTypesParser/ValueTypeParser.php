<?php

declare(strict_types=1);

namespace HypertubePhpCore\valueTypesParser;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\parsableValueType\ParsableValueTypes;
use HypertubePhpUtils\RuntimeName;
use InvalidArgumentException;
use ReflectionClass;

final class ValueTypeParser
{
    /**
     * @param mixed $type
     */
    public static function isParsableValueType($type): bool
    {
        $className = self::resolveClassName($type);
        if ($className === null) {
            return false;
        }

        return ParsableValueTypes::isParsableClassName($className);
    }

    /**
     * Whether a handler response object should be serialized as a parsable value command (not REFERENCE).
     *
     * @param mixed $value
     */
    public static function isParsableValueTypeInstance($value): bool
    {
        if (!is_object($value) || $value instanceof ReflectionClass) {
            return false;
        }

        return ParsableValueTypes::isParsableInstance($value);
    }

    /**
     * @param mixed $value
     */
    public static function getCommandForParsableValueType($value, RuntimeName $runtimeName): CommandInterface
    {
        if (!is_object($value)) {
            throw new InvalidArgumentException('Parsable value type must be an object.');
        }

        return ParsableValueTypes::toCommand($value, $runtimeName);
    }

    /**
     * @param mixed $type
     */
    private static function resolveClassName($type): ?string
    {
        if (is_string($type)) {
            return $type;
        }

        if ($type instanceof ReflectionClass) {
            return $type->getName();
        }

        if (is_object($type)) {
            return get_class($type);
        }

        return null;
    }
}
