<?php

declare(strict_types=1);

namespace HypertubePhpCore\valueTypesParser;

use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;

final class ValueTypeParser
{
    /**
     * @param mixed $type
     */
    public static function isParsableValueType($type): bool
    {
        return false;
    }

    /**
     * @param mixed $value
     */
    public static function getCommandForParsableValueType($value, RuntimeName $runtimeName): CommandInterface
    {
        return new Command($runtimeName, CommandType::VALUE(), []);
    }
}
