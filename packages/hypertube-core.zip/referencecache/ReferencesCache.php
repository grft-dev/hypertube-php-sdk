<?php

declare(strict_types=1);

namespace HypertubePhpCore\referencecache;

use Exception;
use HypertubePhpUtils\exception\SingletonUnserializeException;
use HypertubePhpUtils\Uuid;

/**
 * Process-local reference cache.
 *
 * Standard PHP SAPIs (FPM/CGI/CLI without the parallel extension) are single-threaded
 * per worker, so a mutex is unnecessary. When pecl-sync SyncMutex is available
 * (multi-threaded hosts), map ops are locked.
 */
final class ReferencesCache
{
    private static ?ReferencesCache $instance = null;
    private array $references = [];

    /** @var object|null pecl-sync SyncMutex when available */
    private $mutex = null;

    private function __construct()
    {
        if (class_exists(\SyncMutex::class, false)) {
            $this->mutex = new \SyncMutex();
        }
    }

    public static function getInstance(): ReferencesCache
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * @param mixed $reference
     */
    public function cacheReference($reference): string
    {
        $uuid = Uuid::uuid4()->toString();
        $this->withLock(function () use ($uuid, $reference): void {
            $this->references[$uuid] = $reference;
        });

        return $uuid;
    }

    /**
     * @return mixed
     * @throws Exception
     */
    public function resolveReference(string $uuid)
    {
        return $this->withLock(function () use ($uuid) {
            if (array_key_exists($uuid, $this->references)) {
                return $this->references[$uuid];
            }
            throw new Exception('Reference not found');
        });
    }

    /**
     * @return mixed
     * @throws Exception
     */
    public function &resolveReferenceByRef(string $uuid)
    {
        // By-ref return cannot be wrapped in withLock (finally would run before the
        // caller receives the reference). Standard PHP workers are single-threaded.
        if (array_key_exists($uuid, $this->references)) {
            return $this->references[$uuid];
        }
        throw new Exception('Reference not found');
    }

    public function deleteReference(string $uuid): bool
    {
        return $this->withLock(function () use ($uuid): bool {
            if (isset($this->references[$uuid])) {
                unset($this->references[$uuid]);
                return true;
            }

            return false;
        });
    }

    /**
     * @template T
     * @param callable(): T $fn
     * @return T
     */
    private function withLock(callable $fn)
    {
        if ($this->mutex !== null) {
            $this->mutex->lock();
            try {
                return $fn();
            } finally {
                $this->mutex->unlock();
            }
        }

        return $fn();
    }

    private function __clone()
    {
    }

    /**
     * @throws Exception
     */
    public function __wakeup()
    {
        throw new SingletonUnserializeException();
    }
}
