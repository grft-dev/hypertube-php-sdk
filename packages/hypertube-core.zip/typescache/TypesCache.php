<?php

declare(strict_types=1);

namespace HypertubePhpCore\typescache;

/**
 * Process-local type allow-list cache.
 *
 * Standard PHP SAPIs (FPM/CGI/CLI without the parallel extension) are single-threaded
 * per worker, so a mutex is unnecessary. When pecl-sync SyncMutex is available
 * (multi-threaded hosts), map ops are locked (see ReferencesCache).
 */
final class TypesCache
{
    private static ?TypesCache $instance = null;
    private array $typeCache = [];

    /** @var object|null pecl-sync SyncMutex when available */
    private $mutex = null;

    private function __construct()
    {
        if (class_exists(\SyncMutex::class, false)) {
            $this->mutex = new \SyncMutex();
        }
    }

    public static function getInstance(): TypesCache
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function cacheType(string $typeRegex): int
    {
        $this->withLock(function () use ($typeRegex): void {
            $this->typeCache[] = $typeRegex;
        });

        return 0;
    }

    public function isTypeCacheEmpty(): bool
    {
        return $this->withLock(function (): bool {
            return empty($this->typeCache);
        });
    }

    public function isTypeAllowed(string $typeToCheck): bool
    {
        return $this->withLock(function () use ($typeToCheck): bool {
            foreach ($this->typeCache as $typePattern) {
                if ($typePattern === $typeToCheck) {
                    return true;
                }

                $typeRegex = str_replace(['\\', '*'], ['\\\\', '.*'], $typePattern);
                $typeRegex = '/^' . $typeRegex . '$/';

                if (preg_match($typeRegex, $typeToCheck)) {
                    return true;
                }
            }
            return false;
        });
    }

    public function getTypeCache(): array
    {
        return $this->withLock(function (): array {
            return $this->typeCache;
        });
    }

    public function clearCache(): void
    {
        $this->withLock(function (): void {
            $this->typeCache = [];
        });
    }

    /**
     * @template T
     * @param callable(): T $fn
     * @return T
     */
    private function withLock(callable $fn)
    {
        if ($this->mutex !== null) {
            $this->mutex->lock();
            try {
                return $fn();
            } finally {
                $this->mutex->unlock();
            }
        }

        return $fn();
    }
}
