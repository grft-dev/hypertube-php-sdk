<?php

declare(strict_types=1);

namespace core\http2Client;

use RuntimeException;
use Symfony\Component\HttpClient\HttpClient;
use Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;
use utils\connectiondata\Http2ConnectionData;

final class Http2Client
{
    private const MAX_ATTEMPTS = 2;
    private const DEFAULT_CONNECT_TIMEOUT_SECONDS = 120;
    /** @var array<string, true> */
    private const RESTRICTED_HTTP2_HEADERS = [
        'connection' => true,
        'keep-alive' => true,
        'proxy-connection' => true,
        'transfer-encoding' => true,
        'upgrade' => true,
        'host' => true,
    ];

    /** @var array<string,Http2Client> */
    private static array $cache = [];

    private Http2ConnectionData $connectionData;
    private string $url;
    private string $scheme;
    private int $responseTimeoutInSeconds;
    private HttpClientInterface $httpClient;

    private function __construct(Http2ConnectionData $connectionData)
    {
        $this->connectionData = $connectionData;
        $this->url = $connectionData->getHostname();
        $this->responseTimeoutInSeconds = $connectionData->getResponseTimeoutInSeconds();
        $this->scheme = strtolower((string) parse_url($this->url, PHP_URL_SCHEME));
        if ($this->scheme !== 'http' && $this->scheme !== 'https') {
            throw new RuntimeException(
                "Http2Client requires 'http' (h2c) or 'https' (h2 over TLS) scheme. Provided URL: {$this->url}"
            );
        }
        $this->httpClient = $this->createHttpClient();
    }

    private static function connectionKey(Http2ConnectionData $connectionData): string
    {
        return $connectionData->toCanonicalKey();
    }

    private static function addOrGetClient(Http2ConnectionData $connectionData): Http2Client
    {
        $key = self::connectionKey($connectionData);
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }
        return self::$cache[$key] = new Http2Client($connectionData);
    }

    public static function sendMessage(Http2ConnectionData $connectionData, array $message): array
    {
        $client = self::addOrGetClient($connectionData);
        $lastException = null;

        for ($attempt = 0; $attempt < self::MAX_ATTEMPTS; $attempt++) {
            try {
                return $client->sendByteArray($message);
            } catch (Throwable $e) {
                $lastException = $e;
                if ($attempt === self::MAX_ATTEMPTS - 1 || !self::isTransientError($e)) {
                    break;
                }
                self::closeClient($connectionData);
                $client = self::addOrGetClient($connectionData);
            }
        }

        throw new RuntimeException(
            'HTTP/2 send to ' . $connectionData->getHostname() . ' failed after ' . self::MAX_ATTEMPTS .
            ' attempts. Last error: ' . ($lastException ? $lastException->getMessage() : 'unknown error'),
            0,
            $lastException
        );
    }

    /**
     * @param array<int, int> $message
     * @return array<int, int>
     */
    private function sendByteArray(array $message): array
    {
        $payload = $this->packMessage($message);
        if ($this->scheme === 'http') {
            return $this->sendByteArrayViaCurlH2c($payload);
        }

        $requestOptions = $this->buildRequestOptions($payload);
        try {
            $response = $this->httpClient->request('POST', $this->url, $requestOptions);
        } catch (Throwable $e) {
            throw new RuntimeException("HTTP/2 request to {$this->url} failed: {$e->getMessage()}", 0, $e);
        }

        $statusCode = $response->getStatusCode();
        $responseBody = $response->getContent(false);
        $responseHeaders = $response->getHeaders(false);
        $responseReason = isset($responseHeaders['x-http2-reason'][0]) ? (string) $responseHeaders['x-http2-reason'][0] : '';

        $httpVersion = (string) ($response->getInfo('http_version') ?? '');
        if ($httpVersion !== '' && strpos($httpVersion, '2') !== 0) {
            throw new RuntimeException(
                "HTTP/2 request to {$this->url} failed: the endpoint did not negotiate HTTP/2."
            );
        }

        if ($statusCode < 200 || $statusCode >= 300) {
            throw new RuntimeException(
                "HTTP/2 request to {$this->url} failed with status {$statusCode} {$responseReason}. "
            );
        }

        if ($responseBody === '') {
            return [];
        }

        $bytes = unpack('C*', $responseBody);
        if ($bytes === false) {
            throw new RuntimeException("HTTP/2 request to {$this->url} failed: invalid binary response payload.");
        }

        return array_values($bytes);
    }

    /**
     * h2c (cleartext HTTP/2) requires prior-knowledge mode for this server.
     *
     * @return array<int, int>
     */
    private function sendByteArrayViaCurlH2c(string $payload): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('HTTP/2 h2c requires PHP cURL extension, but it is not available.');
        }
        if (!defined('CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE')) {
            throw new RuntimeException(
                'HTTP/2 h2c requires CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE, but this cURL build does not provide it.'
            );
        }

        $curlHandle = curl_init($this->url);
        if ($curlHandle === false) {
            throw new RuntimeException("HTTP/2 request to {$this->url} failed: unable to initialize cURL.");
        }

        $responseReason = '';
        $headers = $this->buildRequestHeaders();
        $responseTimeout = $this->responseTimeoutInSeconds;

        try {
            $result = curl_setopt_array($curlHandle, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $payload,
                CURLOPT_HTTP_VERSION => constant('CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE'),
                CURLOPT_CONNECTTIMEOUT => self::DEFAULT_CONNECT_TIMEOUT_SECONDS,
                CURLOPT_TIMEOUT => $responseTimeout < 0 ? 0 : $responseTimeout,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$responseReason): int {
                    $normalized = strtolower($line);
                    if (strpos($normalized, 'x-http2-reason:') === 0) {
                        $responseReason = trim(substr($line, strlen('x-http2-reason:')));
                    }
                    return strlen($line);
                },
            ]);

            if ($result === false) {
                throw new RuntimeException("HTTP/2 request to {$this->url} failed: unable to configure cURL.");
            }

            $responseBody = curl_exec($curlHandle);
            if ($responseBody === false) {
                $errno = curl_errno($curlHandle);
                $error = curl_error($curlHandle);
                throw new RuntimeException(
                    "HTTP/2 request to {$this->url} failed: {$error}",
                    $errno
                );
            }

            $httpCode = (int) curl_getinfo($curlHandle, CURLINFO_RESPONSE_CODE);
            if ($httpCode < 200 || $httpCode >= 300) {
                throw new RuntimeException(
                    "HTTP/2 request to {$this->url} failed with status {$httpCode} {$responseReason}. "
                );
            }

            $httpVersion = (int) curl_getinfo($curlHandle, CURLINFO_HTTP_VERSION);
            $validVersions = [constant('CURL_HTTP_VERSION_2_PRIOR_KNOWLEDGE')];
            if (defined('CURL_HTTP_VERSION_2_0')) {
                $validVersions[] = constant('CURL_HTTP_VERSION_2_0');
            }
            if (defined('CURL_HTTP_VERSION_2TLS')) {
                $validVersions[] = constant('CURL_HTTP_VERSION_2TLS');
            }
            if (!in_array($httpVersion, $validVersions, true)) {
                throw new RuntimeException(
                    "HTTP/2 request to {$this->url} failed: the endpoint did not negotiate HTTP/2."
                );
            }

            if ($responseBody === '') {
                return [];
            }
            $bytes = unpack('C*', $responseBody);
            if ($bytes === false) {
                throw new RuntimeException("HTTP/2 request to {$this->url} failed: invalid binary response payload.");
            }
            return array_values($bytes);
        } finally {
            curl_close($curlHandle);
        }
    }

    private function createHttpClient(): HttpClientInterface
    {
        if (!class_exists(HttpClient::class)) {
            throw new RuntimeException(
                'HTTP/2 requires symfony/http-client dependency, but it is not available. ' .
                'Install it with: composer require symfony/http-client'
            );
        }

        return HttpClient::create([
            'http_version' => '2.0',
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function buildRequestOptions(string $payload): array
    {
        $options = [
            'http_version' => '2.0',
            'headers' => $this->buildRequestHeaders(),
            'body' => $payload,
        ];

        if ($this->responseTimeoutInSeconds >= 0) {
            $options['timeout'] = $this->responseTimeoutInSeconds;
        }

        return $options;
    }

    /**
     * @param array<int, int> $message
     */
    private function packMessage(array $message): string
    {
        if (count($message) === 0) {
            return '';
        }

        $normalized = [];
        foreach ($message as $byte) {
            $normalized[] = ((int) $byte) & 0xFF;
        }
        return pack('C*', ...$normalized);
    }

    /**
     * @return array<int, string>
     */
    private function buildRequestHeaders(): array
    {
        $contentType = 'application/octet-stream';
        $headers = [];

        foreach ($this->connectionData->getHeaders() as $key => $value) {
            $headerKey = strtolower(trim((string) $key));
            if ($headerKey === '' || strpos($headerKey, ':') === 0 || $value === null) {
                continue;
            }
            if (isset(self::RESTRICTED_HTTP2_HEADERS[$headerKey])) {
                error_log("HTTP/2 header '{$key}' is restricted and was ignored.");
                continue;
            }
            if ($headerKey === 'te' && strtolower(trim((string) $value)) !== 'trailers') {
                error_log("HTTP/2 header '{$key}' with value '{$value}' is invalid and was ignored.");
                continue;
            }
            if ($headerKey === 'content-type') {
                $contentType = (string) $value;
                continue;
            }
            $headers[] = $headerKey . ': ' . (string) $value;
        }

        $headers[] = 'content-type: ' . $contentType;
        return $headers;
    }

    private static function isTransientError(Throwable $error): bool
    {
        if ($error instanceof TransportExceptionInterface) {
            return true;
        }

        $message = strtolower($error->getMessage());
        foreach (['timed out', 'timeout', 'connection refused', 'connection reset', 'network is unreachable', 'broken pipe'] as $needle) {
            if (strpos($message, $needle) !== false) {
                return true;
            }
        }

        return false;
    }

    public static function closeClient(Http2ConnectionData $connectionData): void
    {
        unset(self::$cache[self::connectionKey($connectionData)]);
    }

    public static function getState(Http2ConnectionData $connectionData): ?string
    {
        return isset(self::$cache[self::connectionKey($connectionData)]) ? 'OPEN' : null;
    }
}
