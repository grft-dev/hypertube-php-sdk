<?php

declare(strict_types=1);

namespace HypertubePhpCore\delegatecache;

use Exception;
use ReflectionMethod;
use HypertubePhpUtils\exception\DelegateNotFoundException;
use HypertubePhpUtils\exception\SingletonUnserializeException;
use HypertubePhpUtils\Uuid;

/**
 * Process-local delegate cache.
 *
 * Standard PHP SAPIs (FPM/CGI/CLI without the parallel extension) are single-threaded
 * per worker, so a mutex is unnecessary. When pecl-sync SyncMutex is available
 * (multi-threaded hosts), map ops are locked (see ReferencesCache).
 */
final class DelegatesCache
{
    private static ?DelegatesCache $instance = null;

    /** @var array<Uuid, ReflectionMethod> */
    private static array $delegatesCache = [];

    /** @var object|null pecl-sync SyncMutex when available */
    private $mutex = null;

    private function __construct()
    {
        if (class_exists(\SyncMutex::class, false)) {
            $this->mutex = new \SyncMutex();
        }
    }

    public static function getInstance(): DelegatesCache
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function addDelegate(ReflectionMethod $delegateInstance): string
    {
        return $this->withLock(function () use ($delegateInstance): string {
            $delegateId = Uuid::uuid4()->toString();
            self::$delegatesCache[$delegateId] = $delegateInstance;

            return $delegateId;
        });
    }

    public function getDelegate(string $delegateId): ReflectionMethod
    {
        return $this->withLock(function () use ($delegateId): ReflectionMethod {
            $delegateInstance = self::$delegatesCache[$delegateId] ?? null;
            if ($delegateInstance === null) {
                throw new DelegateNotFoundException($delegateId);
            }

            return $delegateInstance;
        });
    }

    /**
     * @template T
     * @param callable(): T $fn
     * @return T
     */
    private function withLock(callable $fn)
    {
        if ($this->mutex !== null) {
            $this->mutex->lock();
            try {
                return $fn();
            } finally {
                $this->mutex->unlock();
            }
        }

        return $fn();
    }

    private function __clone()
    {
    }

    /**
     * @throws Exception
     */
    public function __wakeup()
    {
        throw new SingletonUnserializeException();
    }
}
