<?php

declare(strict_types=1);

namespace HypertubePhpCore\namespacescache;

use ReflectionClass;

/**
 * Process-local namespace allow-list cache.
 *
 * Standard PHP SAPIs (FPM/CGI/CLI without the parallel extension) are single-threaded
 * per worker, so a mutex is unnecessary. When pecl-sync SyncMutex is available
 * (multi-threaded hosts), map ops are locked (see ReferencesCache).
 */
final class NamespacesCache
{
    private static ?NamespacesCache $instance = null;
    private static array $namespacesCache = [];

    /** @var object|null pecl-sync SyncMutex when available */
    private $mutex = null;

    private function __construct()
    {
        if (class_exists(\SyncMutex::class, false)) {
            $this->mutex = new \SyncMutex();
        }
    }

    public static function getInstance(): NamespacesCache
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }


    public function cacheNamespace(string $namespaceRegex): void
    {
        $this->withLock(function () use ($namespaceRegex): void {
            self::$namespacesCache[] = $namespaceRegex;
        });
    }

    public function isNamespaceCacheEmpty(): bool
    {
        return $this->withLock(function (): bool {
            return empty(self::$namespacesCache);
        });
    }

    public function isTypeAllowed(object $typeToCheck): bool
    {
        return $this->withLock(function () use ($typeToCheck): bool {
            $typeNamespace = $this->getTypeNamespace($typeToCheck);
            foreach (self::$namespacesCache as $namespacePattern) {
                if ($typeNamespace === $namespacePattern) {
                    return true;
                }

                $normalizedPattern = str_replace('\\', '.', $namespacePattern);
                $normalizedNamespace = str_replace('\\', '.', $typeNamespace);

                if (substr($normalizedPattern, -2) === '.*') {
                    $basePattern = substr($normalizedPattern, 0, -2);
                    if ($normalizedNamespace === $basePattern || strpos($normalizedNamespace, $basePattern . '.') === 0) {
                        return true;
                    }
                }

                if (substr($normalizedPattern, -1) === '*') {
                    $basePattern = substr($normalizedPattern, 0, -1);
                    if ($normalizedNamespace === $basePattern || strpos($normalizedNamespace, $basePattern) === 0) {
                        return true;
                    }
                }

                if ($normalizedNamespace === $normalizedPattern) {
                    return true;
                }
            }

            return false;
        });
    }

    private function getTypeNamespace(object $typeToCheck): string
    {
        if ($typeToCheck instanceof ReflectionClass) {

            return $typeToCheck->getNamespaceName();
        }
        $reflection = new ReflectionClass($typeToCheck);

        return $reflection->getNamespaceName();
    }

    public function getCachedNamespaces(): array
    {
        return $this->withLock(function (): array {
            return self::$namespacesCache;
        });
    }

    public function clearCache(): void
    {
        $this->withLock(function (): void {
            self::$namespacesCache = [];
        });
    }

    /**
     * @template T
     * @param callable(): T $fn
     * @return T
     */
    private function withLock(callable $fn)
    {
        if ($this->mutex !== null) {
            $this->mutex->lock();
            try {
                return $fn();
            } finally {
                $this->mutex->unlock();
            }
        }

        return $fn();
    }
}
