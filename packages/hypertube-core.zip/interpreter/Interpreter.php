<?php

declare(strict_types=1);

namespace HypertubePhpCore\interpreter;

use HypertubePhpCore\handler\Handler;
use HypertubePhpCore\http2Client\Http2Client;
use HypertubePhpCore\protocol\CommandDeserializer;
use HypertubePhpCore\protocol\CommandSerializer;
use HypertubePhpCore\receiver\Receiver;
use HypertubePhpCore\transmitter\Transmitter;
use HypertubePhpCore\webSocketClient\WebSocketClient;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\connectiondata\Http2ConnectionData;
use HypertubePhpUtils\connectiondata\IConnectionData;
use HypertubePhpUtils\connectiondata\WsConnectionData;
use HypertubePhpUtils\messagehelper\MessageHelper;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\type\ConnectionType;
use Throwable;


final class Interpreter
{
    private function __construct()
    {
    }

    private static function isDebugMode(): bool
    {
        $debugMode = getenv('HYPERTUBE_DEBUG');
        if ($debugMode === false) {
            $debugMode = '';
        }

        return strtolower((string) $debugMode) === 'true';
    }

    public static function execute(CommandInterface $command, IConnectionData $IConnectionData): CommandInterface
    {
        if (self::isDebugMode()) {
            self::logDebug('Command sent from calling side', $command);
        }

        $responseByteArray = self::getResponseByteArray($command, $IConnectionData);

        $response = CommandDeserializer::deserialize($responseByteArray);
        if (self::isDebugMode()) {
            self::logDebug('Command received on calling side', $response);
        }

        return $response;
    }

    private static function getResponseByteArray(CommandInterface $command, IConnectionData $IConnectionData)
    {
        $messageByteArray = CommandSerializer::serialize($command, $IConnectionData);
        if ($IConnectionData instanceof WsConnectionData)
        {
           return WebSocketClient::sendMessage($IConnectionData, $messageByteArray);
        }

        if ($IConnectionData instanceof Http2ConnectionData)
        {
            return Http2Client::sendMessage($IConnectionData, $messageByteArray);
        }

        if (count($IConnectionData->getHeaders()) > 0) {
            $contextMetadataPayload = self::buildContextMetadataPayload($command, $IConnectionData);
            $command = new Command($command->getRuntimeName(), CommandType::CONTEXT_METADATA(), [$contextMetadataPayload, $command]);
            $messageByteArray = CommandSerializer::serialize($command, $IConnectionData);
        }

        if (self::isInMemoryAndSameRuntime($command, $IConnectionData)) {
            return Receiver::sendCommand($messageByteArray);
        }

        return Transmitter::sendCommand($messageByteArray, $IConnectionData->getConfig());
    }

    private static function isInMemoryAndSameRuntime(CommandInterface $command, IConnectionData $IConnectionData): bool
    {
        return $command->getRuntimeName()->equalsByValue(RuntimeName::PHP)
            && $IConnectionData->getConnectionType()->equalsByValue(ConnectionType::IN_MEMORY);
    }

    private static function buildContextMetadataPayload(CommandInterface $command, IConnectionData $IConnectionData): CommandInterface
    {
        $metadataPayload = [];
        $headers = $IConnectionData->getHeaders();

        foreach ($headers as $key => $value) {
            $metadataPayload[] = $key;
            $metadataPayload[] = $value;
        }

        return new Command($command->getRuntimeName(), CommandType::ARRAY(), $metadataPayload);
    }

    public static function process(array $byteArray): CommandInterface
    {
        $receivedCommand = CommandDeserializer::deserialize($byteArray);
        if (self::isDebugMode()) {
            self::logDebug('Command received on called side', $receivedCommand);
        }

        $response = Handler::handleCommand($receivedCommand);
        if (self::isDebugMode()) {
            self::logDebug('Response sent from called side', $response);
        }

        return $response;
    }

    private static function logDebug(string $label, $details): void
    {
        try {
            $message = $label . ': ' . $details;
            echo $message . PHP_EOL;
            MessageHelper::getInstance()->sendMessageToAppInsights('SdkMessage', $message);
        } catch (Throwable $ignored) {
            // Debug telemetry must never affect interpreter execution.
        }
    }
}
