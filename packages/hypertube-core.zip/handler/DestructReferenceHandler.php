<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpCore\referencecache\ReferencesCache;

final class DestructReferenceHandler extends AbstractHandler
{
    public function process(CommandInterface $command): bool
    {
        try {
            if ($command->getPayloadSize() < 1) {
                return false;
            }

            $referenceId = $command->getPayload()[0] ?? null;
            if (!is_string($referenceId)) {
                return false;
            }

            return ReferencesCache::getInstance()->deleteReference($referenceId);
        } catch (\Throwable $e) {
            return false;
        }
    }
}
