<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpCore\delegatecache\DelegatesCache;
use HypertubePhpUtils\CommandInterface;

final class InvokeDelegateHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    /**
     * @return mixed
     */
    public function process(CommandInterface $command)
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);

        $guid = (string) $command->getPayload()[0];
        $delegate = DelegatesCache::getInstance()->getDelegate($guid);
        $parameters = array_slice($command->getPayload(), 1);

        return $delegate->invokeArgs(null, $parameters);
    }
}
