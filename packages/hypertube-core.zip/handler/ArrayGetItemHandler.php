<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use ArrayAccess;
use Exception;
use HypertubePhpUtils\CommandInterface;

final class ArrayGetItemHandler extends AbstractHandler
{
    /**
     * @return mixed
     * @throws Exception
     */
    public function process(CommandInterface $command)
    {
        $payload = $command->getPayload();
        if (empty($payload)) {
            throw new Exception('Payload cannot be empty.');
        }

        if (is_array($payload[0]) || $payload[0] instanceof ArrayAccess) {
            $indexes = array_slice($payload, 1);

            return $this->getElement($payload[0], $indexes);
        }

        throw new Exception(sprintf('Cannot get element from type: %s', gettype($payload[0])));
    }

    /**
     * @param mixed $value
     * @return mixed
     * @throws Exception
     */
    private function getElement($value, array $indexes)
    {
        if (count($indexes) === 1 && is_array($indexes[0])) {
            $indexes = $indexes[0];
        }

        if (empty($indexes)) {
            throw new Exception('Index not provided.');
        }

        foreach ($indexes as $index) {
            if (
                (is_array($value) && array_key_exists($index, $value))
                || ($value instanceof ArrayAccess && $value->offsetExists($index))
            ) {
                $value = $value[$index];
            } else {
                throw new Exception(sprintf('Invalid index: %s or key not found.', $index));
            }
        }
        return $value;
    }
}
