<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use Exception;
use HypertubePhpUtils\CommandInterface;

final class AddEventListenerHandler extends AbstractHandler
{
    function process(CommandInterface $command): void
    {
        throw new Exception(__CLASS__ . ' is not implemented in PHP');
    }
}
