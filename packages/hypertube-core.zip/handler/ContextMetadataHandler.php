<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use Exception;
use ReflectionClass;
use ReflectionException;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class ContextMetadataHandler extends AbstractHandler
{
    private const REQUIRED_PARAMETERS_COUNT = 1;
    /**
     * @throws Exception
     */
    public function process(CommandInterface $command): int
    {
        $this->validate($command, self::REQUIRED_PARAMETERS_COUNT, self::class);

        if ($command->getPayloadSize() < 1) {
            throw new Exception('Context metadata payload must contain an array command.');
        }

        $arrayCommand = $command->getPayload()[0];
        if (!($arrayCommand instanceof CommandInterface)
            || !$arrayCommand->getCommandType()->equalsByValue(CommandType::ARRAY()->getValue())) {
            throw new Exception('Context metadata payload must be an array');
        }

        $values = (new ArrayHandler())->process($arrayCommand);
        if (count($values) % 2 !== 0) {
            throw new Exception('Context metadata payload must contain key/value pairs.');
        }

        $getTypeCommand = new Command(
            $command->getRuntimeName(),
            CommandType::GET_TYPE(),
            'Graftcode\\Context\\RequestContext'
        );
        $contextType = (new GetTypeHandler())->process($getTypeCommand);

        if (!$contextType instanceof ReflectionClass) {
            throw new Exception('RequestContext type not found.');
        }

        try {
            $currentMethod = $contextType->getMethod('current');
        } catch (ReflectionException $e) {
            throw new Exception('RequestContext.current not found.', 0, $e);
        }

        if (!$currentMethod->isStatic()) {
            throw new Exception('RequestContext.current is not static.');
        }

        $currentContext = $currentMethod->invoke(null);
        if ($currentContext === null) {
            throw new Exception('RequestContext.current() returned null.');
        }

        /** @var array<string, mixed> $newHeaders */
        $newHeaders = [];

        for ($i = 0; $i < count($values); $i += 2) {
            $key = $values[$i];
            if ($key === null || trim((string) $key) === '') {
                throw new Exception('Context metadata key cannot be null or empty.');
            }
            $stringKey = (string) $key;
            $rawValue = $values[$i + 1] ?? null;
            $newHeaders[$stringKey] = $rawValue === null ? null : (string) $rawValue;
        }

        try {
            $setHeadersMethod = $contextType->getMethod('setHeaders');
        } catch (ReflectionException $e) {
            throw new Exception('RequestContext.setHeaders not found.', 0, $e);
        }

        $setHeadersMethod->invoke($currentContext, $newHeaders);

        return 0;
    }
}
