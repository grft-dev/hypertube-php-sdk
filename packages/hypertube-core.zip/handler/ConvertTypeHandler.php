<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\TypesHandler;

final class ConvertTypeHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    public function process(CommandInterface $command): string
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);

        return TypesHandler::convertTypeToHypertubeType($command->getPayload()[0]);
    }
}
