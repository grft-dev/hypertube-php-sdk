<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use Exception;
use HypertubePhpUtils\CommandInterface;

final class HeartBeatHandler extends AbstractHandler
{
    /**
     * @throws Exception
     */
    public function process(CommandInterface $command)
    {
        throw new Exception(__CLASS__ . ' is not implemented in PHP');
    }
}

