<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpUtils\CommandInterface;

final class ArrayReferenceHandler extends AbstractHandler
{
    public function process(CommandInterface $command)
    {
        throw new \Exception(__CLASS__ . ' is not implemented in PHP');
    }
}

