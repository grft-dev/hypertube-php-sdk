<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpCore\typescache\TypesCache;
use HypertubePhpUtils\CommandInterface;

final class EnableTypeHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    public function process(CommandInterface $command): int
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);

        $typesCache = TypesCache::getInstance();
        foreach ($command->getPayload() as $payload) {
            if (is_string($payload)) {
                $typesCache->cacheType($payload);
            }

            if (is_array($payload)) {
                foreach ($payload as $namespaceToEnable) {
                    $typesCache->cacheType($namespaceToEnable);
                }
            }
        }

        return 0;
    }
}
