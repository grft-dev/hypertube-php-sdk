<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpCore\referencecache\ReferencesCache;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;

final class ResolveInstanceHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    public function process(CommandInterface $command)
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);
        if ($command->getRuntimeName()->equalsByValue(RuntimeName::PHP)) {
            return ReferencesCache::getInstance()->resolveReference($command->getPayload()[0]);
        }

        return new Command($command->getRuntimeName(), CommandType::REFERENCE(), $command->getPayload()[0]);
    }
}
