<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use HypertubePhpCore\namespacescache\NamespacesCache;
use HypertubePhpUtils\CommandInterface;

final class EnableNamespaceHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    public function process(CommandInterface $command): int
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);

        $namespacesCache = NamespacesCache::getInstance();

        foreach ($command->getPayload() as $payload) {
            if (is_string($payload)) {
                $namespacesCache->cacheNamespace($payload);
            }

            if (is_array($payload)) {
                foreach ($payload as $namespaceToEnable) {
                    if (is_string($namespaceToEnable)) {
                        $namespacesCache->cacheNamespace($namespaceToEnable);
                    }
                }
            }
        }

        return 0;
    }
}
