<?php

declare(strict_types=1);

namespace HypertubePhpCore\handler;

use TypeError;
use Traversable;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\type\CommandType;

final class RetrieveArrayHandler extends AbstractHandler
{
    private const REQUIRED_ARGUMENTS_COUNT = 1;

    public function process(CommandInterface $command): CommandInterface
    {
        $this->validate($command, self::REQUIRED_ARGUMENTS_COUNT, self::class);

        $response = $command->getPayload()[0];
        $runtimeName = $command->getRuntimeName();

        if (is_array($response)) {
            return new Command($runtimeName, CommandType::ARRAY(), $this->toNestedPayload($response, $runtimeName));
        }

        if (is_string($response)) {
            $unpacked = unpack('C*', $response);
            if ($unpacked === false) {
                throw new TypeError('Invalid argument type for RetrieveArrayHandler. Expected an array.');
            }

            return new Command($runtimeName, CommandType::ARRAY(), array_values($unpacked));
        }

        if ($response instanceof Traversable) {
            $array = iterator_to_array($response);
            return new Command($runtimeName, CommandType::ARRAY(), $this->toNestedPayload($array, $runtimeName));
        }

        throw new TypeError('Invalid argument type for RetrieveArrayHandler. Expected an array.');
    }

    /**
     * @param array<int, mixed> $items
     * @return array<int, mixed>
     */
    private function toNestedPayload(array $items, $runtimeName): array
    {
        $payload = [];
        foreach ($items as $item) {
            if (is_array($item)) {
                $payload[] = new Command($runtimeName, CommandType::ARRAY(), $this->toNestedPayload($item, $runtimeName));
            } else {
                $payload[] = $item;
            }
        }

        return $payload;
    }
}
