<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\exception\TypeByteNotSupportedException;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\StringEncodingMode;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\type\JType;

final class CommandDeserializer
{
    private function __construct()
    {
    }

    public static function deserialize(string $buffer): CommandInterface
    {
        $position = 11;
        $bufferLength = strlen($buffer);

        $runtimeName = new RuntimeName(ord($buffer[0]));
        $commandType = new CommandType(ord($buffer[10]));
        $payload = [];

        while ($position < $bufferLength) {
            $payload[] = self::readObject($buffer, $position);
        }

        return new Command($runtimeName, $commandType, $payload);
    }

    /**
     * @return mixed
     */
    private static function readObject(string $buffer, int &$position)
    {
        $typeByte = new JType(ord($buffer[$position]));

        switch ($typeByte->getValue()) {
            case JType::HYPERTUBE_COMMAND:
                return self::readCommand($buffer, $position);
            case JType::HYPERTUBE_STRING:
                return self::readString($buffer, $position);
            case JType::HYPERTUBE_INTEGER:
                return self::readInt($buffer, $position);
            case JType::HYPERTUBE_BOOLEAN:
                return self::readBool($buffer, $position);
            case JType::HYPERTUBE_FLOAT:
                return self::readFloat($buffer, $position);
            case JType::HYPERTUBE_BYTE:
                return self::readByte($buffer, $position);
            case JType::HYPERTUBE_CHAR:
                return self::readChar($buffer, $position);
            case JType::HYPERTUBE_LONG:
                return self::readLong($buffer, $position);
            case JType::HYPERTUBE_DOUBLE:
                return self::readDouble($buffer, $position);
            case JType::HYPERTUBE_UNSIGNED_LONG_LONG:
                return self::readUnsignedLong($buffer, $position);
            case JType::HYPERTUBE_UNSIGNED_INTEGER:
                return self::readUnsignedInteger($buffer, $position);
            case JType::HYPERTUBE_NULL:
                return self::readNull($position);
            case JType::HYPERTUBE_UNDEFINED:
                return self::readUndefined($position);
            default:
                throw new TypeByteNotSupportedException(ord($buffer[$position]));
        }
    }

    protected static function readCommand(string $buffer, int &$position): CommandInterface
    {
        $p = $position;

        $numberOfElementsInPayload = TypeDeserializer::deserializeInt($buffer, $p + 1);

        $runtime     = ord($buffer[$p + 5]);
        $commandType = ord($buffer[$p + 6]);

        $position += 7;

        $payload = [];
        for ($i = 0; $i < $numberOfElementsInPayload; $i++) {
            $payload[$i] = self::readObject($buffer, $position);
        }

        return new Command(
            new RuntimeName($runtime),
            new CommandType($commandType),
            $payload
        );
    }

    private static function readString(string $buffer, int &$position): string
    {
        $p = $position;

        $stringEncodingMode = new StringEncodingMode(ord($buffer[$p + 1]));

        $size = TypeDeserializer::deserializeInt($buffer, $p + 2);

        $position += 6;
        $dataStart = $position;
        $position += $size;

        return TypeDeserializer::deserializeString($stringEncodingMode, $buffer, $dataStart, $size);
    }

    private static function readInt(string $buffer, int &$position): int
    {
        $size = 4;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeInt($buffer, $p);
    }

    private static function readBool(string $buffer, int &$position): bool
    {
        $size = 1;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeBool($buffer, $p);
    }

    private static function readFloat(string $buffer, int &$position): float
    {
        $size = 4;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeFloat($buffer, $p);
    }

    private static function readByte(string $buffer, int &$position): int
    {
        $size = 1;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeByte(ord($buffer[$p]));
    }

    private static function readChar(string $buffer, int &$position): string
    {
        $size = 1;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeChar(ord($buffer[$p]));
    }

    private static function readLong(string $buffer, int &$position): int
    {
        $size = 8;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeLong($buffer, $p);
    }

    private static function readDouble(string $buffer, int &$position): float
    {
        $size = 8;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeDouble($buffer, $p);
    }

    private static function readUnsignedLong(string $buffer, int &$position): int
    {
        $size = 8;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeLong($buffer, $p);
    }

    private static function readUnsignedInteger(string $buffer, int &$position): int
    {
        $size = 4;
        $position += 2;
        $p = $position;
        $position += $size;

        return TypeDeserializer::deserializeInt($buffer, $p);
    }

    /**
     * @return mixed
     */
    private static function readNull(int &$position)
    {
        $size = 1;
        $position += 2;
        $position += $size;

        return TypeDeserializer::deserializeNull();
    }

    /**
     * @return mixed
     */
    private static function readUndefined(int &$position)
    {
        $size = 1;
        $position += 2;
        $position += $size;

        return TypeDeserializer::deserializeUndefined();
    }
}
