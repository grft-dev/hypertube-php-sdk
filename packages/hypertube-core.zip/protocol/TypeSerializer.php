<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\exception\TypeSerializationNotSupportedException;
use HypertubePhpUtils\StringEncodingMode;
use HypertubePhpUtils\type\{
    JType,
    SizeType
};
use HypertubePhpUtils\UtilsSimpleType;

final class TypeSerializer
{
    private function __construct()
    {}

    // -------- Buffer-writing API: appends bytes directly to an int[] buffer --------
    // -------- by reference, avoiding the per-field temporary array + merge. --------

    /**
     * Writes the 7-byte command header (type, 4-byte length, runtime, command type)
     * straight into $buffer, instead of building an array and merging it in.
     *
     * @param int[] $buffer
     */
    public static function writeCommandHeader(array &$buffer, CommandInterface $cmd): void
    {
        $buffer[] = JType::HYPERTUBE_COMMAND;
        self::writeInt32Bytes($buffer, $cmd->getPayloadSize());
        $buffer[] = $cmd->getRuntimeName()->getValue();
        $buffer[] = $cmd->getCommandType()->getValue();
    }

    /**
     * Writes a primitive payload item straight into $buffer, instead of
     * building a per-field array and merging it in.
     *
     * @param int[] $buffer
     * @param mixed $value
     */
    public static function writePrimitive(array &$buffer, $value): void
    {
        if (is_null($value)) {
            self::writeNull($buffer);
            return;
        }

        if (is_string($value)) {
            self::writeString($buffer, $value);
            return;
        }

        if (is_bool($value)) {
            self::writeBool($buffer, $value);
            return;
        }

        if (is_float($value)) {
            self::writeDouble($buffer, $value);
            return;
        }

        if (UtilsSimpleType::isInteger($value)) {
            self::writeInt($buffer, $value);
            return;
        }

        if (UtilsSimpleType::isLong($value)) {
            self::writeLong($buffer, $value);
            return;
        }

        throw new TypeSerializationNotSupportedException($value);
    }

    /**
     * @param int[] $buffer
     */
    public static function writeNull(array &$buffer): void
    {
        $buffer[] = JType::HYPERTUBE_NULL;
        $buffer[] = SizeType::HYPERTUBE_NULL_SIZE;
        $buffer[] = 0;
    }

    /**
     * @param int[] $buffer
     */
    public static function writeString(array &$buffer, string $val): void
    {
        $bytes = unpack('C*', iconv('UTF-8', 'UTF-8', $val));
        $buffer[] = JType::HYPERTUBE_STRING;
        $buffer[] = StringEncodingMode::HYPERTUBE_UTF8;
        self::writeInt32Bytes($buffer, count($bytes));
        foreach ($bytes as $byte) {
            $buffer[] = $byte;
        }
    }

    /**
     * @param int[] $buffer
     */
    public static function writeInt(array &$buffer, int $intVal): void
    {
        $buffer[] = JType::HYPERTUBE_INTEGER;
        $buffer[] = SizeType::HYPERTUBE_INTEGER_SIZE;
        self::writeInt32Bytes($buffer, $intVal);
    }

    /**
     * @param int[] $buffer
     */
    public static function writeBool(array &$buffer, bool $boolValue): void
    {
        $buffer[] = JType::HYPERTUBE_BOOLEAN;
        $buffer[] = SizeType::HYPERTUBE_BOOLEAN_SIZE;
        $buffer[] = $boolValue ? 1 : 0;
    }

    /**
     * @param int[] $buffer
     */
    public static function writeFloat(array &$buffer, float $floatValue): void
    {
        // 'g' = IEEE-754 float little-endian (host-independent)
        $bytesFloat = unpack('V', pack('g', $floatValue))[1];
        $buffer[] = JType::HYPERTUBE_FLOAT;
        $buffer[] = SizeType::HYPERTUBE_FLOAT_SIZE;
        self::writeInt32Bytes($buffer, $bytesFloat);
    }

    /**
     * @param int[] $buffer
     */
    public static function writeByte(array &$buffer, int $byteValue): void
    {
        $buffer[] = JType::HYPERTUBE_BYTE;
        $buffer[] = SizeType::HYPERTUBE_BYTE_SIZE;
        $buffer[] = $byteValue & 0xFF;
    }

    /**
     * @param int[] $buffer
     */
    public static function writeChar(array &$buffer, string $charValue): void
    {
        $buffer[] = JType::HYPERTUBE_CHAR;
        $buffer[] = SizeType::HYPERTUBE_CHAR_SIZE;
        $buffer[] = ord($charValue);
    }

    /**
     * @param int[] $buffer
     */
    public static function writeLong(array &$buffer, int $longValue): void
    {
        $buffer[] = JType::HYPERTUBE_LONG;
        $buffer[] = SizeType::HYPERTUBE_LONG_SIZE;
        self::writeInt64Bytes($buffer, $longValue);
    }

    /**
     * @param int[] $buffer
     */
    public static function writeDouble(array &$buffer, float $doubleValue): void
    {
        // 'e' = IEEE-754 double little-endian; 'P' = uint64 little-endian
        $value = unpack('P', pack('e', $doubleValue))[1];
        $buffer[] = JType::HYPERTUBE_DOUBLE;
        $buffer[] = SizeType::HYPERTUBE_DOUBLE_SIZE;
        self::writeInt64Bytes($buffer, $value);
    }

    /**
     * Appends the 4 little-endian bytes of $value directly to $buffer.
     *
     * @param int[] $buffer
     */
    private static function writeInt32Bytes(array &$buffer, int $value): void
    {
        $buffer[] = $value & 0xFF;
        $buffer[] = ($value >> 8) & 0xFF;
        $buffer[] = ($value >> 16) & 0xFF;
        $buffer[] = ($value >> 24) & 0xFF;
    }

    /**
     * Appends the 8 little-endian bytes of $value directly to $buffer.
     *
     * @param int[] $buffer
     */
    private static function writeInt64Bytes(array &$buffer, int $value): void
    {
        $buffer[] = $value & 0xFF;
        $buffer[] = ($value >> 8) & 0xFF;
        $buffer[] = ($value >> 16) & 0xFF;
        $buffer[] = ($value >> 24) & 0xFF;
        $buffer[] = ($value >> 32) & 0xFF;
        $buffer[] = ($value >> 40) & 0xFF;
        $buffer[] = ($value >> 48) & 0xFF;
        $buffer[] = ($value >> 56) & 0xFF;
    }
}
