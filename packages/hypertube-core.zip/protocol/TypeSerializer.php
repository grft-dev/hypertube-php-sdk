<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\exception\TypeSerializationNotSupportedException;
use HypertubePhpUtils\protocol\StringEncodingHelper;
use HypertubePhpUtils\StringEncodingMode;
use HypertubePhpUtils\type\{
    JType,
    SizeType
};
use HypertubePhpUtils\UtilsSimpleType;

final class TypeSerializer
{
    private function __construct()
    {}

    // -------- Buffer-writing API: appends bytes directly to a binary string buffer --------

    public static function writeCommandHeader(string &$buffer, CommandInterface $cmd): void
    {
        $buffer .= chr(JType::HYPERTUBE_COMMAND);
        self::writeInt32Bytes($buffer, $cmd->getPayloadSize());
        $buffer .= chr($cmd->getRuntimeName()->getValue());
        $buffer .= chr($cmd->getCommandType()->getValue());
    }

    /**
     * @param mixed $value
     */
    public static function writePrimitive(string &$buffer, $value): void
    {
        if (is_null($value)) {
            self::writeNull($buffer);
            return;
        }

        if (is_string($value)) {
            self::writeString($buffer, $value);
            return;
        }

        if (is_bool($value)) {
            self::writeBool($buffer, $value);
            return;
        }

        if (is_float($value)) {
            self::writeDouble($buffer, $value);
            return;
        }

        if (UtilsSimpleType::isInteger($value)) {
            self::writeInt($buffer, $value);
            return;
        }

        if (UtilsSimpleType::isLong($value)) {
            self::writeLong($buffer, $value);
            return;
        }

        throw new TypeSerializationNotSupportedException($value);
    }

    public static function writeNull(string &$buffer): void
    {
        $buffer .= chr(JType::HYPERTUBE_NULL);
        $buffer .= chr(SizeType::HYPERTUBE_NULL_SIZE);
        $buffer .= "\x00";
    }

    public static function writeString(string &$buffer, string $val): void
    {
        StringEncodingHelper::assertValidUtf8($val);
        $byteLength = strlen($val);
        $buffer .= chr(JType::HYPERTUBE_STRING);
        $buffer .= chr(StringEncodingMode::HYPERTUBE_UTF8);
        self::writeInt32Bytes($buffer, $byteLength);
        if ($byteLength > 0) {
            $buffer .= $val;
        }
    }

    public static function writeInt(string &$buffer, int $intVal): void
    {
        $buffer .= chr(JType::HYPERTUBE_INTEGER);
        $buffer .= chr(SizeType::HYPERTUBE_INTEGER_SIZE);
        self::writeInt32Bytes($buffer, $intVal);
    }

    public static function writeBool(string &$buffer, bool $boolValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_BOOLEAN);
        $buffer .= chr(SizeType::HYPERTUBE_BOOLEAN_SIZE);
        $buffer .= $boolValue ? "\x01" : "\x00";
    }

    public static function writeFloat(string &$buffer, float $floatValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_FLOAT);
        $buffer .= chr(SizeType::HYPERTUBE_FLOAT_SIZE);
        $buffer .= pack('g', $floatValue);
    }

    public static function writeByte(string &$buffer, int $byteValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_BYTE);
        $buffer .= chr(SizeType::HYPERTUBE_BYTE_SIZE);
        $buffer .= chr($byteValue & 0xFF);
    }

    public static function writeChar(string &$buffer, string $charValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_CHAR);
        $buffer .= chr(SizeType::HYPERTUBE_CHAR_SIZE);
        $buffer .= chr(ord($charValue));
    }

    public static function writeLong(string &$buffer, int $longValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_LONG);
        $buffer .= chr(SizeType::HYPERTUBE_LONG_SIZE);
        self::writeInt64Bytes($buffer, $longValue);
    }

    public static function writeDouble(string &$buffer, float $doubleValue): void
    {
        $buffer .= chr(JType::HYPERTUBE_DOUBLE);
        $buffer .= chr(SizeType::HYPERTUBE_DOUBLE_SIZE);
        $buffer .= pack('e', $doubleValue);
    }

    private static function writeInt32Bytes(string &$buffer, int $value): void
    {
        $buffer .= pack('V', $value);
    }

    private static function writeInt64Bytes(string &$buffer, int $value): void
    {
        $buffer .= pack('P', $value);
    }
}
