<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpUtils\protocol\StringEncodingHelper;
use HypertubePhpUtils\StringEncodingMode;

final class TypeDeserializer
{
    private function __construct()
    {}

    public static function deserializeString(StringEncodingMode $stringEncodingMode, array $bytes): string
    {
        return StringEncodingHelper::bytesToString($bytes);
    }


    /**
     * Offset-based: reads directly from $bytes at $offset using bit-shift
     * arithmetic, so callers can pass the full command buffer instead of
     * slicing out a 4-byte sub-array first.
     */
    public static function deserializeInt(array $bytes, int $offset = 0): int
    {
        $int = ($bytes[$offset] & 0xFF)
            | (($bytes[$offset + 1] & 0xFF) << 8)
            | (($bytes[$offset + 2] & 0xFF) << 16)
            | (($bytes[$offset + 3] & 0xFF) << 24);

        return $int & 0x80000000 ? $int - 0x100000000 : $int;
    }

    public static function deserializeBool(array $bytes, int $offset = 0): bool
    {
        return $bytes[$offset] === 1;
    }

    public static function deserializeFloat(array $bytes, int $offset = 0): float
    {
        // 'V'/'g' = little-endian int32 bits / IEEE-754 float (host-independent)
        return unpack(
            'g',
            pack('V', self::deserializeInt($bytes, $offset) & 0xFFFFFFFF)
        )[1];
    }

    public static function deserializeByte(int $byteVal): int
    {
        return $byteVal & 0xFF;
    }

    public static function deserializeChar(int $byteVal): string
    {
        return chr($byteVal & 0xFF);
    }

    /**
     * Offset-based: reads directly from $bytes at $offset without slicing.
     */
    public static function deserializeLong(array $bytes, int $offset = 0): int
    {
        return (($bytes[$offset] & 0xFF)
            | (($bytes[$offset + 1] & 0xFF) << 8)
            | (($bytes[$offset + 2] & 0xFF) << 16)
            | (($bytes[$offset + 3] & 0xFF) << 24)
            | (($bytes[$offset + 4] & 0xFF) << 32)
            | (($bytes[$offset + 5] & 0xFF) << 40)
            | (($bytes[$offset + 6] & 0xFF) << 48)
            | (($bytes[$offset + 7] & 0xFF) << 56));
    }

    public static function deserializeDouble(array $bytes, int $offset = 0): float
    {
        // 'P'/'e' = little-endian uint64 bits / IEEE-754 double (host-independent)
        return unpack('e', pack('P', self::deserializeLong($bytes, $offset)))[1];
    }

    public static function deserializeNull()
    {
        return null;
    }

    public static function deserializeUndefined()
    {
        return null;
    }
}
