<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpUtils\protocol\StringEncodingHelper;
use HypertubePhpUtils\StringEncodingMode;

final class TypeDeserializer
{
    private function __construct()
    {}

    public static function deserializeString(
        StringEncodingMode $stringEncodingMode,
        string $wire,
        int $offset = 0,
        ?int $length = null
    ): string {
        if ($length === null) {
            $length = strlen($wire) - $offset;
        }

        if ($length <= 0) {
            return '';
        }

        return StringEncodingHelper::decode($stringEncodingMode, $wire, $offset, $length);
    }

    public static function deserializeInt(string $wire, int $offset = 0): int
    {
        $int = (ord($wire[$offset]) & 0xFF)
            | ((ord($wire[$offset + 1]) & 0xFF) << 8)
            | ((ord($wire[$offset + 2]) & 0xFF) << 16)
            | ((ord($wire[$offset + 3]) & 0xFF) << 24);

        return $int & 0x80000000 ? $int - 0x100000000 : $int;
    }

    public static function deserializeBool(string $wire, int $offset = 0): bool
    {
        return ord($wire[$offset]) === 1;
    }

    public static function deserializeFloat(string $wire, int $offset = 0): float
    {
        return unpack(
            'g',
            pack('V', self::deserializeInt($wire, $offset))
        )[1];
    }

    public static function deserializeByte(int $byteVal): int
    {
        return $byteVal & 0xFF;
    }

    public static function deserializeChar(int $byteVal): string
    {
        return chr($byteVal & 0xFF);
    }

    public static function deserializeLong(string $wire, int $offset = 0): int
    {
        return ((ord($wire[$offset]) & 0xFF)
            | ((ord($wire[$offset + 1]) & 0xFF) << 8)
            | ((ord($wire[$offset + 2]) & 0xFF) << 16)
            | ((ord($wire[$offset + 3]) & 0xFF) << 24)
            | ((ord($wire[$offset + 4]) & 0xFF) << 32)
            | ((ord($wire[$offset + 5]) & 0xFF) << 40)
            | ((ord($wire[$offset + 6]) & 0xFF) << 48)
            | ((ord($wire[$offset + 7]) & 0xFF) << 56));
    }

    public static function deserializeDouble(string $wire, int $offset = 0): float
    {
        return unpack('e', pack('P', self::deserializeLong($wire, $offset)))[1];
    }

    public static function deserializeNull()
    {
        return null;
    }

    public static function deserializeUndefined()
    {
        return null;
    }
}
