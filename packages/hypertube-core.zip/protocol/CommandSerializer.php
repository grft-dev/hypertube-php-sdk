<?php

declare(strict_types=1);

namespace HypertubePhpCore\protocol;

use HypertubePhpCore\referencecache\ReferencesCache;
use Exception;
use RuntimeException;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\connectiondata\IConnectionData;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\TypesHandler;

final class CommandSerializer
{
    private const DEFAULT_SERIALIZER_CONNECTION_DATA = [0, 0, 0, 0, 0, 0, 0];

    private function __construct()
    {
    }

    /**
     * Serialize command to a binary wire string (raw bytes 0–255).
     */
    public static function serialize(CommandInterface $rootCommand, ?IConnectionData $IConnectionData): string
    {
        try {
            $buffer = '';

            $buffer .= chr($rootCommand->getRuntimeName()->getValue());
            $buffer .= "\x00"; // runtimeVersion

            self::appendConnectionData($buffer, self::getDataByIConnectionData($IConnectionData));

            $buffer .= chr(RuntimeName::PHP);
            $buffer .= chr($rootCommand->getCommandType()->getValue());

            self::serializeRecursively($rootCommand, $buffer);

            return $buffer;
        } catch (Exception $e) {
            throw new RuntimeException(
                'Error during serialization: ' . $e->getMessage(),
                0,
                $e
            );
        }
    }

    /**
     * @return int[]
     */
    private static function getDataByIConnectionData(?IConnectionData $IConnectionData): array
    {
        if ($IConnectionData !== null) {
            return $IConnectionData->serializeConnectionData();
        }

        return self::DEFAULT_SERIALIZER_CONNECTION_DATA;
    }

    private static function appendConnectionData(string &$buffer, array $data): void
    {
        foreach ($data as $value) {
            $buffer .= chr((int) $value & 0xFF);
        }
    }

    private static function serializeRecursively(CommandInterface $command, string &$buffer): void
    {
        foreach ($command->getPayload() as $payloadItem) {
            if ($payloadItem instanceof CommandInterface) {
                TypeSerializer::writeCommandHeader($buffer, $payloadItem);
                self::serializeRecursively($payloadItem, $buffer);
            } elseif (TypesHandler::isSimpleType($payloadItem)) {
                TypeSerializer::writePrimitive($buffer, $payloadItem);
            } else {
                $referenceId = ReferencesCache::getInstance()->cacheReference($payloadItem);

                $refCommand = new Command(
                    new RuntimeName(RuntimeName::PHP),
                    CommandType::REFERENCE(),
                    [$referenceId]
                );

                TypeSerializer::writeCommandHeader($buffer, $refCommand);
                self::serializeRecursively($refCommand, $buffer);
            }
        }
    }
}
