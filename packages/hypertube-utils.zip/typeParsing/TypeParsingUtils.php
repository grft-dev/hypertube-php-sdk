<?php

declare(strict_types=1);

namespace HypertubePhpUtils\typeParsing;

use DateInterval;
use DateTimeImmutable;
use Exception;
use HypertubePhpSdk\InvocationContext;
use InvalidArgumentException;
use ReflectionException;

final class TypeParsingUtils
{
    public const TICKS_PER_SECOND = 10000000;

    /**
     * @return array<int, mixed>
     */
    public static function payload(InvocationContext $invocationContext): array
    {
        $command = $invocationContext->getCurrentCommand();

        return $command->getPayload();
    }

    public static function colorChannel(int $value): int
    {
        return TypeParsingWire::colorChannel($value);
    }

    /**
     * @throws Exception
     */
    public static function parseIsoDateTime(string $iso, bool $naiveAsUtc = false): DateTimeImmutable
    {
        $normalized = self::normalizeIsoFractionalSeconds(str_replace('Z', '+00:00', $iso));

        if ($naiveAsUtc && preg_match('/[+-]\d{2}:\d{2}$/', $normalized) !== 1) {
            $normalized .= '+00:00';
        }

        return new DateTimeImmutable($normalized);
    }

    /**
     * @throws Exception
     */
    public static function parseTimeOnEpochDay(string $iso): DateTimeImmutable
    {
        $normalized = self::normalizeIsoFractionalSeconds(str_replace('Z', '+00:00', $iso));
        if (preg_match('/[+-]\d{2}:\d{2}$/', $normalized) === 1) {
            return new DateTimeImmutable('1970-01-01T' . $normalized);
        }

        return new DateTimeImmutable('1970-01-01T' . $normalized . '+00:00');
    }

    private static function normalizeIsoFractionalSeconds(string $iso): string
    {
        $truncated = preg_replace('/\.(\d{6})\d+/', '.$1', $iso);
        if (is_string($truncated)) {
            return $truncated;
        }

        return $iso;
    }

    /**
     * @throws Exception
     */
    public static function intervalFromTicks(int $ticks): DateInterval
    {
        $totalMicroseconds = intdiv($ticks, 10);
        $negative = $totalMicroseconds < 0;
        $absoluteMicroseconds = $negative ? -$totalMicroseconds : $totalMicroseconds;

        $seconds = intdiv($absoluteMicroseconds, 1000000);
        $microseconds = $absoluteMicroseconds % 1000000;

        $interval = new DateInterval('PT' . $seconds . 'S');
        $interval->f = $microseconds / 1000000;
        if ($negative) {
            $interval->invert = 1;
        }

        return $interval;
    }

    /**
     * @throws Exception
     */
    public static function intervalFromSecondsAndNanos(int $seconds, int $nanoAdjustment): DateInterval
    {
        $ticks = $seconds * self::TICKS_PER_SECOND + intdiv($nanoAdjustment, 100);

        return self::intervalFromTicks($ticks);
    }

    /**
     * @throws Exception
     */
    public static function intervalFromMicroseconds(int $microseconds): DateInterval
    {
        if (self::microsecondsConvertibleToTicksViaMultiply($microseconds)) {
            return self::intervalFromTicks($microseconds * 10);
        }

        return self::dateIntervalFromSignedTotalMicroseconds($microseconds);
    }

    private static function microsecondsConvertibleToTicksViaMultiply(int $microseconds): bool
    {
        if ($microseconds === 0) {
            return true;
        }
        if ($microseconds > 0) {
            return $microseconds <= intdiv(PHP_INT_MAX, 10);
        }

        return $microseconds > intdiv(PHP_INT_MIN, 10);
    }

    private static function dateIntervalFromSignedTotalMicroseconds(int $totalMicroseconds): DateInterval
    {
        $negative = $totalMicroseconds < 0;
        $seconds = intdiv($totalMicroseconds, 1000000);
        $remainder = $totalMicroseconds % 1000000;
        $absSeconds = $seconds < 0 ? -$seconds : $seconds;
        $absRemainder = $remainder < 0 ? -$remainder : $remainder;

        try {
            $interval = new DateInterval('PT' . $absSeconds . 'S');
        } catch (Exception $exception) {
            throw new InvalidArgumentException(
                'Duration microseconds value is out of range for DateInterval.',
                0,
                $exception
            );
        }

        $interval->f = $absRemainder / 1000000;
        if ($negative) {
            $interval->invert = 1;
        }

        return $interval;
    }

    public static function intervalToTicks(DateInterval $interval): int
    {
        return TypeParsingWire::intervalToTicks($interval);
    }

    /**
     * PHP 7.4: DateInterval::__construct accepts only ISO duration spec; complex-type wire uses .NET-style ticks.
     *
     * @param array<int, mixed> $arguments
     * @throws ReflectionException
     * @throws Exception
     */
    public static function createDateInterval(array $arguments): DateInterval
    {
        if (count($arguments) !== 1) {
            throw new ReflectionException('DateInterval wire expects exactly one argument (ticks or spec).');
        }

        $argument = $arguments[0];
        if (is_int($argument)) {
            return self::intervalFromTicks($argument);
        }

        if (is_string($argument) && preg_match('/^-?\d+$/', $argument) === 1) {
            return self::intervalFromTicks((int) $argument);
        }

        return new DateInterval((string) $argument);
    }
}
