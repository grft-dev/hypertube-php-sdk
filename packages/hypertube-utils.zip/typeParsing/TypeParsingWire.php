<?php

declare(strict_types=1);

namespace HypertubePhpUtils\typeParsing;

use DateInterval;
use DateTime;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Exception;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;

final class TypeParsingWire
{
    public const TICKS_PER_SECOND = 10000000;

    public static function colorChannel(int $value): int
    {
        return $value & 0xFF;
    }

    public static function getTypeCommand(RuntimeName $runtimeName, string $typeName): Command
    {
        return new Command($runtimeName, CommandType::GET_TYPE(), $typeName);
    }

    /**
     * @throws Exception
     */
    public static function toIso(DateTimeInterface $dateTime, bool $useZ = true): string
    {
        if ($dateTime instanceof DateTimeImmutable) {
            $immutable = $dateTime;
        } elseif ($dateTime instanceof DateTime) {
            $immutable = DateTimeImmutable::createFromMutable($dateTime);
        } else {
            $immutable = new DateTimeImmutable($dateTime->format('Y-m-d\TH:i:s.uP'));
        }

        $utc = $immutable->setTimezone(new DateTimeZone('UTC'));
        $iso = $utc->format('Y-m-d\TH:i:s.uP');
        if ($useZ) {
            $replaced = preg_replace('/\+00:00$/', 'Z', $iso);
            if (is_string($replaced)) {
                return $replaced;
            }
        }

        return $iso;
    }

    public static function intervalToTicks(DateInterval $interval): int
    {
        $parts = self::intervalToSecondsAndMicros($interval);

        return $parts['seconds'] * self::TICKS_PER_SECOND + $parts['microseconds'] * 10;
    }

    /**
     * @return array{seconds: int, microseconds: int, milliseconds: int, nanos: int}
     */
    public static function intervalToSecondsAndMicros(DateInterval $interval): array
    {
        if ($interval->days !== false) {
            $totalMicroseconds = $interval->days * 86400 * 1000000
                + $interval->h * 3600000000
                + $interval->i * 60000000
                + (int) round(($interval->s + $interval->f) * 1000000);

            if ($interval->invert) {
                $totalMicroseconds = -$totalMicroseconds;
            }

            $seconds = intdiv($totalMicroseconds, 1000000);
            $microseconds = $totalMicroseconds % 1000000;
            if ($microseconds < 0) {
                $seconds -= 1;
                $microseconds += 1000000;
            } elseif ($microseconds > 0 && $seconds < 0) {
                $seconds += 1;
                $microseconds -= 1000000;
            }

            return [
                'seconds' => $seconds,
                'microseconds' => $microseconds,
                'milliseconds' => $seconds * 1000 + intdiv($microseconds, 1000),
                'nanos' => $microseconds * 1000,
            ];
        }

        $start = new DateTimeImmutable('1970-01-01T00:00:00+00:00');
        $end = $start->add($interval);

        $seconds = $end->getTimestamp() - $start->getTimestamp();
        $microseconds = (int) $end->format('u') - (int) $start->format('u');
        if ($microseconds < 0) {
            $seconds -= 1;
            $microseconds += 1000000;
        } elseif ($microseconds > 0 && $seconds < 0) {
            $seconds += 1;
            $microseconds -= 1000000;
        }

        return [
            'seconds' => $seconds,
            'microseconds' => $microseconds,
            'milliseconds' => $seconds * 1000 + intdiv($microseconds, 1000),
            'nanos' => $microseconds * 1000,
        ];
    }
}
