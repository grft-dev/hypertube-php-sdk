<?php

declare(strict_types=1);

namespace utils;

final class UtilsSimpleType
{
    private function __construct()
    {}

    public static function isInteger($value): bool
    {
        return is_int($value) && $value >= -2147483648 && $value <= 2147483647;
    }

    public static function isLong($value): bool
    {
        return is_int($value) && $value >= -9223372036854775808 && $value <= 9223372036854775807;
    }
}
