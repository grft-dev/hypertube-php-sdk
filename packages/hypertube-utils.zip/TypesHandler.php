<?php

declare(strict_types=1);

namespace HypertubePhpUtils;

use ReflectionType;
use HypertubePhpUtils\type\JType;

final class TypesHandler
{
    private function __construct()
    {
    }

    public static function convertTypeToHypertubeType(ReflectionType $type): string
    {
        $typeName = $type->getName();
        switch ($typeName) {
            case 'bool':
                return JType::HYPERTUBE_BOOLEAN()->getName();
            case 'string':
                return JType::HYPERTUBE_STRING()->getName();
            case 'char':
                return JType::HYPERTUBE_CHAR()->getName();
            case 'int':
                return JType::HYPERTUBE_INTEGER()->getName();
            case 'float':
                return JType::HYPERTUBE_FLOAT()->getName();
            case 'double':
                return JType::HYPERTUBE_DOUBLE()->getName();
            case 'null':
                return JType::HYPERTUBE_NULL()->getName();
            default:
                return $typeName;
        }
    }


    /**
     * @param mixed $item
     */
    public static function isSimpleType($item): bool
    {
        return $item === null || is_scalar($item);
    }
}
