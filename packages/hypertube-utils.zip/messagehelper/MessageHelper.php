<?php

declare(strict_types=1);

namespace HypertubePhpUtils\messagehelper;

use DateTimeImmutable;
use DateTimeZone;
use GuzzleHttp\Promise\Create;
use GuzzleHttp\Promise\PromiseInterface;
use HypertubePhpSdk\tools\HttpConnection;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\UtilsConst;
use Throwable;

final class MessageHelper
{
    private const FALLBACK_ADDRESS = 'https://polandcentral-0.in.applicationinsights.azure.com/v2/track';
    private const APPINSIGHTS_CONNECTION_STRING_ENV_NAME = 'HYPERTUBE_APPLICATIONINSIGHTS_CONNECTION_STRING';
    private const DEFAULT_INSTRUMENTATION_KEY = '87e949af-cf27-489c-8518-591b3b55b667';
    private const DEFAULT_PACKAGE_VER = '2.0.0';
    private static ?MessageHelper $instance = null;
    private HttpConnection $connection;
    private string $instrumentationKey;
    private string $hypertubeVersion;
    private string $nodeName;
    private string $osName;

    public function __construct(?HttpConnection $connection = null)
    {
        [$address, $instrumentationKey] = $this->resolveTelemetryTarget(
            getenv(self::APPINSIGHTS_CONNECTION_STRING_ENV_NAME) ?: ''
        );
        $this->connection = $connection ?? new HttpConnection(new Uri($address));
        $this->instrumentationKey = $instrumentationKey;
        $this->hypertubeVersion = $this->getHypertubeVersion();
        $this->nodeName = $this->getHostName();
        $this->osName = php_uname('s');
    }

    public static function getInstance(): MessageHelper
    {
        if (self::$instance === null) {
            self::$instance = new MessageHelper();
        }
        return self::$instance;
    }

    public function sendMessageToAppInsights(string $operationName, string $message): PromiseInterface
    {
        try {
            $licenseKey = UtilsConst::getLicenseKey();
            $isBinaryException = strpos($message, 'BinariesUnloader exception') !== false
                || strpos($message, 'BinariesExtractor exception') !== false;
            if ($isBinaryException && $licenseKey === 'functional-tests-key') {
                return Create::promiseFor(0);
            }

            $promise = $this->connection
                ->sendAsync($this->buildPayload($operationName, $message, $licenseKey))
                ->otherwise(static function (): int {
                    return -1;
                });

            // Settle immediately so Symfony Response objects are fully consumed.
            // Unsettled 4xx responses throw ClientException from __destruct during later GC
            // (e.g. while building large payloads in InvocationContext).
            try {
                $promise->wait(false);
            } catch (Throwable $ignored) {
            }

            return $promise;
        } catch (Throwable $throwable) {
            return Create::promiseFor(-1);
        }
    }

    private function buildPayload(string $operationName, string $message, string $licenseKey): string
    {
        return json_encode([
            'name' => 'AppEvents',
            'time' => (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z'),
            'iKey' => $this->instrumentationKey,
            'tags' => [
                'ai.application.ver' => $this->hypertubeVersion,
                'ai.cloud.roleInstance' => $this->nodeName,
                'ai.operation.id' => '0',
                'ai.operation.parentId' => '0',
                'ai.operation.name' => $operationName,
                'ai.internal.sdkVersion' => 'hypertube',
                'ai.internal.nodeName' => $this->nodeName,
            ],
            'data' => [
                'baseType' => 'EventData',
                'baseData' => [
                    'ver' => 2,
                    'name' => $message,
                    'properties' => [
                        'OperatingSystem' => $this->osName,
                        'LicenseKey' => $licenseKey,
                        'CallingTechnology' => 'Php',
                    ],
                ],
            ],
        ], JSON_THROW_ON_ERROR);
    }

    private function getHypertubeVersion(): string
    {
        $composerJsonPath = dirname(__DIR__,4) . '/composer.json';
        if (!file_exists($composerJsonPath)) {
            return self::DEFAULT_PACKAGE_VER;
        }

        $composerJsonFile = json_decode(file_get_contents($composerJsonPath));
        if (json_last_error() !== JSON_ERROR_NONE || !isset($composerJsonFile->name)) {
            return self::DEFAULT_PACKAGE_VER;
        }

        $composerInstalledJsonPath = dirname(__DIR__, 3) . '/composer/installed.json';
        if (!file_exists($composerInstalledJsonPath)) {
            return self::DEFAULT_PACKAGE_VER;
        }

        $composerInstalledFile = json_decode(file_get_contents($composerInstalledJsonPath), true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return self::DEFAULT_PACKAGE_VER;
        }

        foreach ($composerInstalledFile['packages'] ?? [] as $package)
        {
            if ($package['name'] === $composerJsonFile->name) {
                return $package['version'] ?? self::DEFAULT_PACKAGE_VER;
            }
        }

        return self::DEFAULT_PACKAGE_VER;
    }

    private function getHostName(): string
    {
        return gethostname() ?: 'Unknown Host';
    }

    /**
     * @return array{0:string,1:string}
     */
    private function resolveTelemetryTarget(string $connectionString): array
    {
        if (trim($connectionString) === '') {
            return [self::FALLBACK_ADDRESS, self::DEFAULT_INSTRUMENTATION_KEY];
        }

        $values = $this->parseConnectionString($connectionString);
        $ingestionEndpoint = $values['ingestionendpoint'] ?? '';
        $instrumentationKey = $values['instrumentationkey'] ?? '';

        $address = self::FALLBACK_ADDRESS;
        if ($ingestionEndpoint !== '') {
            $address = rtrim($ingestionEndpoint, '/') . '/v2/track';
        }

        if ($instrumentationKey === '') {
            $instrumentationKey = self::DEFAULT_INSTRUMENTATION_KEY;
        }

        return [$address, $instrumentationKey];
    }

    /**
     * @return array<string,string>
     */
    private function parseConnectionString(string $connectionString): array
    {
        $values = [];
        $segments = explode(';', $connectionString);
        foreach ($segments as $rawSegment) {
            $segment = trim($rawSegment);
            if ($segment === '') {
                continue;
            }

            $separatorIndex = strpos($segment, '=');
            if ($separatorIndex === false || $separatorIndex === 0 || $separatorIndex >= strlen($segment) - 1) {
                continue;
            }

            $key = strtolower(trim(substr($segment, 0, $separatorIndex)));
            $value = trim(substr($segment, $separatorIndex + 1));
            if ($key === '' || $value === '') {
                continue;
            }

            $values[$key] = $value;
        }

        return $values;
    }
}