<?php

declare(strict_types=1);

namespace HypertubePhpUtils\exception;

use RuntimeException;

final class TypeNotSupportedException extends RuntimeException
{
    public function __construct(string $typeName)
    {
        parent::__construct(
            'Unsupported Reflection Type conversion for Hypertube type : ' . $typeName
        );
    }
}