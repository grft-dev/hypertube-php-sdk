<?php

declare(strict_types=1);

namespace HypertubePhpUtils\exception;

use RuntimeException;

final class UnsupportedOperationException extends RuntimeException
{
}