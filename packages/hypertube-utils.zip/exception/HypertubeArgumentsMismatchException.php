<?php

declare(strict_types=1);

namespace HypertubePhpUtils\exception;

use RuntimeException;

final class HypertubeArgumentsMismatchException extends RuntimeException
{
    public function __construct(string $commandName, int $requiredArgumentsCount)
    {
        parent::__construct('Wrong argument number for command: '
            . $commandName . ' minimal required for this command is: '
            . $requiredArgumentsCount);
    }
}
