<?php

declare(strict_types=1);

namespace HypertubePhpUtils\exception;

use ArithmeticError;
use DivisionByZeroError;
use InvalidArgumentException;
use OutOfBoundsException;
use RuntimeException;
use Throwable;
use TypeError;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\messagehelper\MessageHelper;
use HypertubePhpUtils\type\ExceptionType;

final class ExceptionThrower
{
    /**
     * @throws Throwable
     */
    public static function throwException(CommandInterface $commandException): void
    {
        try {
            $exceptionMessage = 'PHP Exception with empty message';
            $exceptionName = 'PHP Exception';
            $stackTrace = 'Hypertube Exception with empty stack trace';
            $hypertubeStackCommand = 'Hypertube Exception with empty stack command';
            $exceptionType = ExceptionType::EXCEPTION();

            switch ($commandException->getPayloadSize()) {
                case ExceptionType::DIVIDE_BY_ZERO_EXCEPTION:
                    $stackTrace = self::getLocalStackTrace($commandException->getPayload());
                case ExceptionType::ARITHMETIC_EXCEPTION:
                    $exceptionMessage = (string) ($commandException->getPayloadByIndex(3));
                case ExceptionType::RUNTIME_EXCEPTION:
                    $exceptionName = (string) ($commandException->getPayloadByIndex(2));
                case ExceptionType::FILE_NOT_FOUND_EXCEPTION:
                    $hypertubeStackCommand = (string) ($commandException->getPayloadByIndex(1));
                case ExceptionType::IO_EXCEPTION:
                    $exceptionType = ExceptionType::from($commandException->getPayloadByIndex(0));
                    break;
                default:
                    throw new RuntimeException('Error while processing exception: ' . $commandException);
            }

            $finalMessage = sprintf('[%s]: %s: %s: %s: %s', $exceptionName, $exceptionMessage, $stackTrace, $hypertubeStackCommand, $exceptionType->getName());

            $fallbackNotice = ExceptionType::consumeFallbackNotice();
            if ($fallbackNotice !== null) {
                $finalMessage = $fallbackNotice . ' , ' . $finalMessage;
            }

            switch ($exceptionType->getValue()) {
                case ExceptionType::EXCEPTION:
                case ExceptionType::RUNTIME_EXCEPTION:
                case ExceptionType::IO_EXCEPTION:
                case ExceptionType::FILE_NOT_FOUND_EXCEPTION:
                case ExceptionType::PLUGIN_NOT_FOUND:
                case ExceptionType::INVALID_OPERATION_EXCEPTION:
                case ExceptionType::PLUGIN_OPERATION_EXCEPTION:
                case ExceptionType::PLUGIN_RESOLVING_EXCEPTION:
                    throw new RuntimeException($finalMessage);
                case ExceptionType::ARITHMETIC_EXCEPTION:
                    throw new ArithmeticError($finalMessage);
                case ExceptionType::DIVIDE_BY_ZERO_EXCEPTION:
                    throw new DivisionByZeroError($finalMessage);
                case ExceptionType::NULL_POINTER_EXCEPTION:
                    throw new TypeError($finalMessage);
                case ExceptionType::ILLEGAL_ARGUMENT_EXCEPTION:
                    throw new InvalidArgumentException($finalMessage);
                case ExceptionType::INDEX_OUT_OF_BOUNDS_EXCEPTION:
                    throw new OutOfBoundsException($finalMessage);
                default:
                    throw new RuntimeException('Error while processing unknown exception type: ' . $finalMessage);
            }
        } catch (Throwable $e) {
            MessageHelper::getInstance()->sendMessageToAppInsights('SdkException', $e->getMessage());
            throw $e;
        }
    }

    private static function getLocalStackTrace(array $commandExceptionPayload): string
    {
        $stackClasses = self::splitIfNotEmpty($commandExceptionPayload[4]);
        $stackMethods = self::splitIfNotEmpty($commandExceptionPayload[5]);
        $stackLines = self::splitIfNotEmpty($commandExceptionPayload[6]);
        $stackFiles = self::splitIfNotEmpty($commandExceptionPayload[7]);

        $stackTrace = '';
        foreach ($stackClasses as $i => $class)
        {
            if (!empty($stackFiles[$i])) {
                $stackTrace .= sprintf('File "%s"', $stackFiles[$i]);
            }

            if (!empty($stackLines[$i])) {
                $stackTrace .= sprintf(', line %s', self::getStackLine($stackLines[$i]));
            }

            if (!empty($stackMethods[$i])) {
                $stackTrace .= sprintf(', in %s', $stackMethods[$i]);
            }

            $stackTrace .= "\n";
            if (!empty($class)) {
                $stackTrace .= sprintf("    %s\n", $class);
            }
        }

        return $stackTrace;
    }

    private static function splitIfNotEmpty(?string $input): array
    {
        return empty($input) ? [] : explode('|', $input);
    }

    private static function getStackLine($stackLine): int
    {
        if (is_numeric($stackLine)) {
            return (int) $stackLine;
        }

        return 0;
    }
}
