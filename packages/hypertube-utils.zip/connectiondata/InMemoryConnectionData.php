<?php

declare(strict_types=1);

namespace utils\connectiondata;

use utils\type\ConnectionType;

final class InMemoryConnectionData extends ConnectionData
{
    public function getConnectionType(): ConnectionType
    {
        return ConnectionType::IN_MEMORY();
    }

    public function getHostname(): string
    {
        return 'inmemory';
    }

    public function serializeConnectionData(): array
    {
        return [$this->getConnectionType()->getValue(), 0, 0, 0, 0, 0, 0 ];
    }
}
