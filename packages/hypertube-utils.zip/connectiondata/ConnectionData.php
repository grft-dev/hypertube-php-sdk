<?php

declare(strict_types=1);

namespace utils\connectiondata;

use utils\type\ConnectionType;

abstract class ConnectionData implements IConnectionData
{
    protected array $headers = [];

    abstract public function getConnectionType(): ConnectionType;
    abstract public function getHostname(): string;
    abstract public function serializeConnectionData(): array;

    public function getHeaders(): array
    {
        return $this->headers;
    }

    public function addHeader(string $key, string $value): void
    {
        $this->headers[$key] = $value;
    }

    public function addHeaders(array $headers): void
    {
        foreach ($headers as $key => $value) {
            $this->headers[(string)$key] = (string)$value;
        }
    }

    public function setHeaders(array $headers): void
    {
        $this->headers = [];
        $this->addHeaders($headers);
    }

    public function toString(): string
    {
        return $this->connectionTypeAsString() . '|' . $this->getHostname();
    }

    public function __toString(): string
    {
        return $this->toString();
    }

    public function toCanonicalKey(): string
    {
        $key = $this->toString();
        $headers = $this->serializeHeadersForKey();
        if ($headers !== '') {
            $key .= '|h:' . $headers;
        }
        return $key;
    }

    private function serializeHeadersForKey(): string
    {
        if (empty($this->headers)) {
            return '';
        }

        $ordered = $this->headers;
        ksort($ordered);
        $pairs = [];
        foreach ($ordered as $key => $value) {
            $pairs[] = (string)$key . '=' . (string)$value;
        }
        return implode(';', $pairs);
    }

    private function connectionTypeAsString(): string
    {
        switch ($this->getConnectionType()->getValue()) {
            case ConnectionType::IN_MEMORY:
                return 'inmemory';
            case ConnectionType::TCP:
                return 'tcp';
            case ConnectionType::WEB_SOCKET:
                return 'websocket';
            case ConnectionType::HTTP2:
                return 'http2';
            default:
                return 'unknown';
        }
    }
}
