<?php

declare(strict_types=1);

namespace HypertubePhpUtils\connectiondata;

use HypertubePhpUtils\type\ConnectionType;

interface IConnectionData
{
    public function getConnectionType(): ConnectionType;
    public function getHostname(): string;
    public function serializeConnectionData(): array;
    public function getHeaders(): array;
    public function setHeaders(array $headers): void;
    public function setThreadLocalHeaders(array $headers): void;
    public function getThreadLocalHeaders(): array;
    public function getConfig(): string;
    public function toString(): string;
    public function toCanonicalKey(): string;
}
