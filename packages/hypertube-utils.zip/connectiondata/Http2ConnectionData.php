<?php

declare(strict_types=1);

namespace utils\connectiondata;

use utils\type\ConnectionType;

final class Http2ConnectionData extends ConnectionData
{
    private const DEFAULT_RESPONSE_TIMEOUT_SECONDS = 180;

    private string $hostName;
    private int $responseTimeoutInSeconds;

    public function __construct(
        string $hostName,
        int $responseTimeoutInSeconds = self::DEFAULT_RESPONSE_TIMEOUT_SECONDS
    ) {
        $this->hostName = $hostName;
        $this->responseTimeoutInSeconds = $responseTimeoutInSeconds;
    }

    public function getConnectionType(): ConnectionType
    {
        return ConnectionType::HTTP2();
    }

    public function serializeConnectionData(): array
    {
        return [$this->getConnectionType()->getValue(), 0, 0, 0, 0, 0, 0 ];
    }

    public function getHostname(): string
    {
        return $this->hostName;
    }

    public function getResponseTimeoutInSeconds(): int
    {
        return $this->responseTimeoutInSeconds;
    }

}
