<?php

declare(strict_types=1);

namespace utils\connectiondata;

use utils\type\ConnectionType;

final class Http2ConnectionData extends ConnectionData
{
    private const DEFAULT_CONNECT_TIMEOUT_SECONDS = 60;

    private string $hostName;
    private int $timeoutInSeconds;

    public function __construct(
        string $hostName,
        int $timeoutInSeconds = self::DEFAULT_CONNECT_TIMEOUT_SECONDS
    ) {
        $this->hostName = $hostName;
        $this->timeoutInSeconds = $timeoutInSeconds;
    }

    public function getConnectionType(): ConnectionType
    {
        return ConnectionType::HTTP2();
    }

    public function serializeConnectionData(): array
    {
        return [$this->getConnectionType()->getValue(), 0, 0, 0, 0, 0, 0 ];
    }

    public function getHostname(): string
    {
        return $this->hostName;
    }

    public function getTimeoutInSeconds(): int
    {
        return $this->timeoutInSeconds;
    }
}
