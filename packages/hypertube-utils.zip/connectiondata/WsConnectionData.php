<?php

declare(strict_types=1);

namespace utils\connectiondata;

use utils\type\ConnectionType;

final class WsConnectionData extends ConnectionData
{
    private const DEFAULT_CONNECT_TIMEOUT_SECONDS = 60;

    private string $hostName;
    private int $connectTimeoutInSeconds;

    public function __construct(
        string $hostName,
        int $connectTimeoutInSeconds = self::DEFAULT_CONNECT_TIMEOUT_SECONDS
    ) {
        $this->hostName = $hostName;
        $this->connectTimeoutInSeconds = $connectTimeoutInSeconds;
    }

    public function getConnectionType(): ConnectionType
    {
        return ConnectionType::WEB_SOCKET();
    }

    public function serializeConnectionData(): array
    {
        return [$this->getConnectionType()->getValue(), 0, 0, 0, 0, 0, 0 ];
    }

    public function getHostname(): string
    {
        return $this->hostName;
    }

    public function getConnectTimeoutInSeconds(): int
    {
        return $this->connectTimeoutInSeconds;
    }
}
