<?php

declare(strict_types=1);

namespace HypertubePhpUtils\type;

use HypertubePhpUtils\Enum;
use ReflectionClass;

final class ExceptionType extends Enum
{
    public const EXCEPTION = 0;
    public const IO_EXCEPTION = 1;
    public const FILE_NOT_FOUND_EXCEPTION = 2;
    public const RUNTIME_EXCEPTION = 3;
    public const ARITHMETIC_EXCEPTION = 4 ;
    public const ILLEGAL_ARGUMENT_EXCEPTION = 5;
    public const INDEX_OUT_OF_BOUNDS_EXCEPTION = 6;
    public const NULL_POINTER_EXCEPTION = 7;
    public const DIVIDE_BY_ZERO_EXCEPTION = 8;
    public const PLUGIN_NOT_FOUND = 9;
    public const INVALID_OPERATION_EXCEPTION = 10;
    public const PLUGIN_OPERATION_EXCEPTION = 11;
    public const PLUGIN_RESOLVING_EXCEPTION = 12;

    private const UNRECOGNIZED_CODE_EXCEPTION = '[Hypertube] Unrecognized exception wire code %s; default EXCEPTION type used.';

    private static ?string $fallbackNotice = null;

    public static function consumeFallbackNotice(): ?string
    {
        $notice = self::$fallbackNotice;
        self::$fallbackNotice = null;

        return $notice;
    }

    private static function asDefaultException(string $notice): self
    {
        self::$fallbackNotice = $notice;

        return self::EXCEPTION();
    }

    /**
     * @param mixed $value
     */
    public static function from($value): self
    {
        self::$fallbackNotice = null;

            if (!is_int($value) && !is_string($value)) {
                return self::asDefaultException(sprintf(
                    self::UNRECOGNIZED_CODE_EXCEPTION,
                    is_scalar($value) ? (string) $value : gettype($value)
                ));
            }

            $wireCode = filter_var($value, FILTER_VALIDATE_INT);
            if ($wireCode === false) {
                return self::asDefaultException(sprintf(
                    self::UNRECOGNIZED_CODE_EXCEPTION,
                    is_scalar($value) ? (string) $value : gettype($value)
                ));
            }

            $constants = (new ReflectionClass(self::class))->getConstants();

            if (!in_array($wireCode, $constants, true)) {
                return self::asDefaultException(sprintf(
                    self::UNRECOGNIZED_CODE_EXCEPTION,
                    is_scalar($value) ? (string) $value : gettype($value)
                ));
            }

            return new self($wireCode);
    }

    public static function getExceptionCodeByExceptionName(string $exceptionName): int
    {
        switch ($exceptionName) {
            case 'IOException':
                return self::IO_EXCEPTION;
            case 'FileNotFoundException':
                return self::FILE_NOT_FOUND_EXCEPTION;
            case 'RuntimeException':
                return self::RUNTIME_EXCEPTION;
            case 'ArithmeticError':
                return self::ARITHMETIC_EXCEPTION;
            case 'InvalidArgumentException':
                return self::ILLEGAL_ARGUMENT_EXCEPTION;
            case 'OutOfBoundsException':
            case 'OutOfRangeException':
                return self::INDEX_OUT_OF_BOUNDS_EXCEPTION;
            case 'TypeError':
                return self::NULL_POINTER_EXCEPTION;
            case 'DivisionByZeroError':
                return self::DIVIDE_BY_ZERO_EXCEPTION;
            default:
                return self::EXCEPTION;
        }
    }
}
