<?php

declare(strict_types=1);

namespace utils\type;

use utils\Enum;

final class ConnectionType extends Enum
{
    public const IN_MEMORY = 0;
    public const TCP = 1;
    public const WEB_SOCKET = 2;
    public const HTTP2 = 3;
    public const TCP_TLS = 4;
    public const PLUGIN = 5;
}
