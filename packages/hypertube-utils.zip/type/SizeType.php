<?php

declare(strict_types=1);

namespace utils\type;

use utils\Enum;

final class SizeType extends Enum
{
    public const HYPERTUBE_BOOLEAN_SIZE = 1;
    public const HYPERTUBE_BYTE_SIZE = 1;
    public const HYPERTUBE_CHAR_SIZE = 1;
    public const HYPERTUBE_INTEGER_SIZE = 4;
    public const HYPERTUBE_FLOAT_SIZE = 4;
    public const HYPERTUBE_LONG_SIZE = 8;
    public const HYPERTUBE_DOUBLE_SIZE = 8;
    public const HYPERTUBE_UNSIGNED_LONG_LONG_SIZE = 8;
    public const HYPERTUBE_UNSIGNED_INTEGER_SIZE  = 4;
    public const HYPERTUBE_NULL_SIZE = 1;
    public const HYPERTUBE_UNDEFINED_SIZE = 1;
    public const HYPERTUBE_VOID_SIZE = 1;
}