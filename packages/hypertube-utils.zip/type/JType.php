<?php

declare(strict_types=1);

namespace HypertubePhpUtils\type;

use HypertubePhpUtils\Enum;

final class JType extends Enum
{
    public const HYPERTUBE_COMMAND = 0;
    public const HYPERTUBE_STRING = 1;
    public const HYPERTUBE_INTEGER = 2;
    public const HYPERTUBE_BOOLEAN = 3;
    public const HYPERTUBE_FLOAT = 4;
    public const HYPERTUBE_BYTE = 5;
    public const HYPERTUBE_CHAR = 6;
    public const HYPERTUBE_LONG = 7;
    public const HYPERTUBE_DOUBLE = 8;
    public const HYPERTUBE_UNSIGNED_LONG_LONG = 9;
    public const HYPERTUBE_UNSIGNED_INTEGER = 10;
    public const HYPERTUBE_NULL = 11;
    public const HYPERTUBE_UNDEFINED = 12;
    public const HYPERTUBE_VOID = 13;
}