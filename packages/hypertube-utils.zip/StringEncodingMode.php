<?php

declare(strict_types=1);

namespace utils;

final class StringEncodingMode extends Enum
{
    public const HYPERTUBE_ASCII = 0;
    public const HYPERTUBE_UTF8 = 1;
    public const HYPERTUBE_UTF16 = 2;
    public const HYPERTUBE_UTF32 = 3;
}