<?php

declare(strict_types=1);

namespace HypertubePhpUtils;

final class Color
{
    public int $r;
    public int $g;
    public int $b;
    public int $a;

    public function __construct(int $r, int $g, int $b, int $a = 255)
    {
        $this->r = $r;
        $this->g = $g;
        $this->b = $b;
        $this->a = $a;
    }
}
