<?php

declare(strict_types=1);

namespace HypertubePhpUtils\protocol;

use InvalidArgumentException;

/**
 * Wire-format string encoding without ext-iconv.
 * Matches .NET Hypertube behavior: UTF-8 bytes on the wire, decode is a byte pass-through.
 */
final class StringEncodingHelper
{
    private function __construct()
    {
    }

    /**
     * @return array<int, int>
     */
    public static function utf8StringToByteArray(string $value): array
    {
        if ($value === '') {
            return [];
        }

        if (preg_match('//u', $value) !== 1) {
            throw new InvalidArgumentException('String is not valid UTF-8.');
        }

        $bytes = unpack('C*', $value);

        return $bytes === false ? [] : array_values($bytes);
    }

    /**
     * @param array<int, int> $bytes
     */
    public static function bytesToString(array $bytes): string
    {
        if ($bytes === []) {
            return '';
        }

        return pack('C*', ...$bytes);
    }
}
