<?php

declare(strict_types=1);

namespace HypertubePhpUtils\protocol;

use HypertubePhpUtils\StringEncodingMode;
use InvalidArgumentException;

/**
 * Wire-format string encoding without ext-iconv or ext-mbstring.
 * Outbound PHP strings are UTF-8. Inbound bytes follow StringEncodingMode:
 * ASCII (high bytes become '?'), UTF-8, UTF-16LE, and UTF-32LE.
 */
final class StringEncodingHelper
{
    private const UTF8_REPLACEMENT = "\xEF\xBF\xBD";

    private function __construct()
    {
    }

    public static function assertValidUtf8(string $value): void
    {
        if ($value === '') {
            return;
        }

        if (preg_match('//u', $value) !== 1) {
            throw new InvalidArgumentException('String is not valid UTF-8.');
        }
    }

    public static function decode(StringEncodingMode $mode, string $wire, int $offset, int $length): string
    {
        if ($length === 0) {
            return '';
        }

        $bytes = substr($wire, $offset, $length);
        switch ($mode->getValue()) {
            case StringEncodingMode::HYPERTUBE_ASCII:
                return self::decodeAscii($bytes);
            case StringEncodingMode::HYPERTUBE_UTF8:
                return $bytes;
            case StringEncodingMode::HYPERTUBE_UTF16:
                return self::decodeUtf16Le($bytes);
            case StringEncodingMode::HYPERTUBE_UTF32:
                return self::decodeUtf32Le($bytes);
            default:
                throw new InvalidArgumentException(
                    'String encoding mode is not supported: ' . $mode->getValue()
                );
        }
    }

    private static function decodeAscii(string $bytes): string
    {
        if (preg_match('/[\x80-\xFF]/', $bytes) !== 1) {
            return $bytes;
        }

        return preg_replace('/[\x80-\xFF]/', '?', $bytes) ?? $bytes;
    }

    private static function decodeUtf16Le(string $bytes): string
    {
        $length = strlen($bytes);
        $result = '';
        $i = 0;
        while ($i + 1 < $length) {
            $unit = ord($bytes[$i]) | (ord($bytes[$i + 1]) << 8);
            $i += 2;

            if ($unit >= 0xD800 && $unit <= 0xDBFF) {
                if ($i + 1 >= $length) {
                    $result .= self::UTF8_REPLACEMENT;
                    break;
                }

                $low = ord($bytes[$i]) | (ord($bytes[$i + 1]) << 8);
                if ($low < 0xDC00 || $low > 0xDFFF) {
                    $result .= self::UTF8_REPLACEMENT;
                    continue;
                }

                $i += 2;
                $codePoint = 0x10000 + (($unit - 0xD800) << 10) + ($low - 0xDC00);
                self::appendUtf8($result, $codePoint);
                continue;
            }

            if ($unit >= 0xDC00 && $unit <= 0xDFFF) {
                $result .= self::UTF8_REPLACEMENT;
                continue;
            }

            self::appendUtf8($result, $unit);
        }

        if ($i < $length) {
            $result .= self::UTF8_REPLACEMENT;
        }

        return $result;
    }

    private static function decodeUtf32Le(string $bytes): string
    {
        $length = strlen($bytes);
        $result = '';
        $i = 0;
        while ($i + 3 < $length) {
            $codePoint = ord($bytes[$i])
                | (ord($bytes[$i + 1]) << 8)
                | (ord($bytes[$i + 2]) << 16)
                | (ord($bytes[$i + 3]) << 24);
            $i += 4;

            if ($codePoint > 0x10FFFF || ($codePoint >= 0xD800 && $codePoint <= 0xDFFF)) {
                $result .= self::UTF8_REPLACEMENT;
                continue;
            }

            self::appendUtf8($result, $codePoint);
        }

        if ($i < $length) {
            $result .= self::UTF8_REPLACEMENT;
        }

        return $result;
    }

    private static function appendUtf8(string &$result, int $codePoint): void
    {
        if ($codePoint < 0x80) {
            $result .= chr($codePoint);
            return;
        }

        if ($codePoint < 0x800) {
            $result .= chr(0xC0 | ($codePoint >> 6));
            $result .= chr(0x80 | ($codePoint & 0x3F));
            return;
        }

        if ($codePoint < 0x10000) {
            $result .= chr(0xE0 | ($codePoint >> 12));
            $result .= chr(0x80 | (($codePoint >> 6) & 0x3F));
            $result .= chr(0x80 | ($codePoint & 0x3F));
            return;
        }

        $result .= chr(0xF0 | ($codePoint >> 18));
        $result .= chr(0x80 | (($codePoint >> 12) & 0x3F));
        $result .= chr(0x80 | (($codePoint >> 6) & 0x3F));
        $result .= chr(0x80 | ($codePoint & 0x3F));
    }
}
