<?php

declare(strict_types=1);

namespace HypertubePhpUtils\parsableValueType;

use DateInterval;
use DateTime;
use DateTimeImmutable;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

/**
 * PHP-host parsable value types (aligned with .NET/JVM ValueTypeParser allowlist in Core).
 */
final class ParsableValueTypes
{
    /** @var array<string, true> */
    private const PARSABLE_PHP_CLASS_NAMES = [
        DateTimeImmutable::class => true,
        DateTime::class => true,
        Uuid::class => true,
        Uri::class => true,
        DateInterval::class => true,
    ];

    public static function isParsableClassName(string $className): bool
    {
        return isset(self::PARSABLE_PHP_CLASS_NAMES[$className]);
    }

    public static function isParsableInstance(object $instance): bool
    {
        return self::isParsableClassName(get_class($instance));
    }

    public static function toCommand(object $value, RuntimeName $runtimeName): CommandInterface
    {
        return ParsableValueTypeOutbound::toCommand($runtimeName, $value);
    }
}
