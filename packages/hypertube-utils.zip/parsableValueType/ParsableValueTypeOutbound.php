<?php

declare(strict_types=1);

namespace HypertubePhpUtils\parsableValueType;

use DateInterval;
use DateTime;
use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use Exception;
use HypertubePhpUtils\Color;
use HypertubePhpUtils\Command;
use HypertubePhpUtils\CommandInterface;
use HypertubePhpUtils\error\UnsupportedPayloadItemTypeError;
use HypertubePhpUtils\Point;
use HypertubePhpUtils\RuntimeName;
use HypertubePhpUtils\type\CommandType;
use HypertubePhpUtils\typeParsing\TypeParsingWire;
use HypertubePhpUtils\Uri;
use HypertubePhpUtils\Uuid;

final class ParsableValueTypeOutbound
{
    /** @var array<int, array<string, callable>>|null */
    private static ?array $complexTypeToCommandFunctions = null;

    public static function toCommand(RuntimeName $runtimeName, object $payloadItem): CommandInterface
    {
        $tables = self::complexTypeToCommandFunctions();
        $runtimeKey = $runtimeName->getValue();
        if (!isset($tables[$runtimeKey])) {
            throw new UnsupportedPayloadItemTypeError($payloadItem);
        }

        $className = get_class($payloadItem);
        if (!isset($tables[$runtimeKey][$className])) {
            throw new UnsupportedPayloadItemTypeError($payloadItem);
        }

        return $tables[$runtimeKey][$className]($payloadItem);
    }

    /**
     * @return array<string, callable>
     */
    public static function phpArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'phpDateTimeImmutableToCommand'],
            DateTime::class => [self::class, 'phpDateTimeToCommand'],
            Uuid::class => [self::class, 'phpUuidToCommand'],
            Uri::class => [self::class, 'phpUriToCommand'],
            DateInterval::class => [self::class, 'phpIntervalToCommand'],
        ];
    }

    /**
     * @return array<string, callable>
     */
    public static function netcoreArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'netcoreDateTimeToCommand'],
            DateTime::class => [self::class, 'netcoreDateTimeToCommand'],
            Uuid::class => [self::class, 'netcoreUuidToCommand'],
            Uri::class => [self::class, 'netcoreUriToCommand'],
            DateInterval::class => [self::class, 'netcoreIntervalToCommand'],
            Point::class => [self::class, 'netcorePointToCommand'],
            Color::class => [self::class, 'netcoreColorToCommand'],
        ];
    }

    /**
     * @return array<string, callable>
     */
    public static function jvmArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'jvmDateTimeToCommand'],
            DateTime::class => [self::class, 'jvmDateTimeToCommand'],
            Uuid::class => [self::class, 'jvmUuidToCommand'],
            Uri::class => [self::class, 'jvmUriToCommand'],
            DateInterval::class => [self::class, 'jvmIntervalToCommand'],
            Point::class => [self::class, 'jvmPointToCommand'],
            Color::class => [self::class, 'jvmColorToCommand'],
        ];
    }

    /**
     * @return array<string, callable>
     */
    public static function nodejsArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'nodejsDateTimeToCommand'],
            DateTime::class => [self::class, 'nodejsDateTimeToCommand'],
            Uuid::class => [self::class, 'nodejsUuidToCommand'],
            Uri::class => [self::class, 'nodejsUriToCommand'],
            DateInterval::class => [self::class, 'nodejsIntervalToCommand'],
            Point::class => [self::class, 'nodejsPointToCommand'],
            Color::class => [self::class, 'nodejsColorToCommand'],
        ];
    }

    /**
     * @return array<string, callable>
     */
    public static function pythonArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'pythonDateTimeToCommand'],
            DateTime::class => [self::class, 'pythonDateTimeToCommand'],
            Uuid::class => [self::class, 'pythonUuidToCommand'],
            Uri::class => [self::class, 'pythonUriToCommand'],
            DateInterval::class => [self::class, 'pythonIntervalToCommand'],
            Point::class => [self::class, 'pythonPointToCommand'],
            Color::class => [self::class, 'pythonColorToCommand'],
        ];
    }

    /**
     * @return array<string, callable>
     */
    public static function rubyArgumentFactories(): array
    {
        return [
            DateTimeImmutable::class => [self::class, 'rubyDateTimeToCommand'],
            DateTime::class => [self::class, 'rubyDateTimeToCommand'],
            Uuid::class => [self::class, 'rubyUuidToCommand'],
            Uri::class => [self::class, 'rubyUriToCommand'],
            DateInterval::class => [self::class, 'rubyIntervalToCommand'],
            Point::class => [self::class, 'rubyPointToCommand'],
            Color::class => [self::class, 'rubyColorToCommand'],
        ];
    }

    /**
     * @return array<int, array<string, callable>>
     */
    private static function complexTypeToCommandFunctions(): array
    {
        if (self::$complexTypeToCommandFunctions === null) {
            self::$complexTypeToCommandFunctions = [
                RuntimeName::NETCORE => self::netcoreArgumentFactories(),
                RuntimeName::JVM => self::jvmArgumentFactories(),
                RuntimeName::NODEJS => self::nodejsArgumentFactories(),
                RuntimeName::PYTHON => self::pythonArgumentFactories(),
                RuntimeName::PHP => self::phpArgumentFactories(),
                RuntimeName::RUBY => self::rubyArgumentFactories(),
            ];
        }

        return self::$complexTypeToCommandFunctions;
    }

    /**
     * @throws Exception
     */
    public static function phpDateTimeImmutableToCommand(DateTimeInterface $value): Command
    {
        $runtime = RuntimeName::PHP();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'DateTimeImmutable'),
            TypeParsingWire::toIso($value),
        ]);
    }

    /**
     * @param DateTimeInterface $value
     * @throws Exception
     */
    public static function phpDateTimeToCommand($value): Command
    {
        $runtime = RuntimeName::PHP();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'DateTime'),
            TypeParsingWire::toIso($value),
        ]);
    }

    public static function phpUuidToCommand(Uuid $value): Command
    {
        $runtime = RuntimeName::PHP();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, Uuid::class),
            'fromString',
            $value->toString(),
        ]);
    }

    public static function phpUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::PHP();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, Uri::class),
            $value->toString(),
        ]);
    }

    public static function phpIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::PHP();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'DateInterval'),
            TypeParsingWire::intervalToTicks($value),
        ]);
    }

    /**
     * @throws Exception
     */
    public static function netcoreDateTimeToCommand(DateTimeInterface $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command(
            $runtime,
            CommandType::COMPLEX_VALUE_TYPE(),
            'System.DateTime',
            TypeParsingWire::toIso($value)
        );
    }

    public static function netcoreUuidToCommand(Uuid $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'System.Guid'),
            $value->toString(),
        ]);
    }

    public static function netcoreUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'System.Uri'),
            $value->toString(),
        ]);
    }

    public static function netcoreIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'System.TimeSpan'),
            TypeParsingWire::intervalToTicks($value),
        ]);
    }

    public static function netcorePointToCommand(Point $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'System.Drawing.Point'),
            $value->x,
            $value->y,
        ]);
    }

    public static function netcoreColorToCommand(Color $value): Command
    {
        $runtime = RuntimeName::NETCORE();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'System.Drawing.Color'),
            'FromArgb',
            TypeParsingWire::colorChannel($value->a),
            TypeParsingWire::colorChannel($value->r),
            TypeParsingWire::colorChannel($value->g),
            TypeParsingWire::colorChannel($value->b),
        ]);
    }

    /**
     * @throws Exception
     */
    public static function jvmDateTimeToCommand(DateTimeInterface $value): Command
    {
        $runtime = RuntimeName::JVM();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.time.Instant'),
            'parse',
            TypeParsingWire::toIso($value),
        ]);
    }

    public static function jvmUuidToCommand(Uuid $value): Command
    {
        $runtime = RuntimeName::JVM();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.util.UUID'),
            'fromString',
            $value->toString(),
        ]);
    }

    public static function jvmUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::JVM();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.net.URI'),
            'create',
            $value->toString(),
        ]);
    }

    public static function jvmIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::JVM();
        $ticks = TypeParsingWire::intervalToTicks($value);
        $seconds = intdiv($ticks, TypeParsingWire::TICKS_PER_SECOND);
        $nanoAdjustment = ($ticks % TypeParsingWire::TICKS_PER_SECOND) * 100;

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.time.Duration'),
            'ofSeconds',
            $seconds,
            $nanoAdjustment,
        ]);
    }

    public static function jvmPointToCommand(Point $value): Command
    {
        $runtime = RuntimeName::JVM();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.awt.Point'),
            $value->x,
            $value->y,
        ]);
    }

    public static function jvmColorToCommand(Color $value): Command
    {
        $runtime = RuntimeName::JVM();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'java.awt.Color'),
            TypeParsingWire::colorChannel($value->r),
            TypeParsingWire::colorChannel($value->g),
            TypeParsingWire::colorChannel($value->b),
            TypeParsingWire::colorChannel($value->a),
        ]);
    }

    /**
     * @throws Exception
     */
    public static function nodejsDateTimeToCommand(DateTimeInterface $value): Command
    {
        $runtime = RuntimeName::NODEJS();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'Date'),
            TypeParsingWire::toIso($value),
        ]);
    }

    public static function nodejsUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::NODEJS();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'URL'),
            $value->toString(),
        ]);
    }

    public static function nodejsIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::NODEJS();
        $parts = TypeParsingWire::intervalToSecondsAndMicros($value);
        $milliseconds = $parts['seconds'] * 1000 + $parts['microseconds'] / 1000;

        return new Command($runtime, CommandType::VALUE(), $milliseconds);
    }

    public static function nodejsUuidToCommand(Uuid $value): Command
    {
        return new Command(RuntimeName::NODEJS(), CommandType::VALUE(), $value->toString());
    }

    public static function nodejsPointToCommand(Point $value): Command
    {
        return new Command(
            RuntimeName::NODEJS(),
            CommandType::COMPLEX_VALUE_TYPE(),
            'Point',
            $value->x,
            $value->y
        );
    }

    public static function nodejsColorToCommand(Color $value): Command
    {
        return new Command(
            RuntimeName::NODEJS(),
            CommandType::COMPLEX_VALUE_TYPE(),
            'Color',
            TypeParsingWire::colorChannel($value->a),
            TypeParsingWire::colorChannel($value->r),
            TypeParsingWire::colorChannel($value->g),
            TypeParsingWire::colorChannel($value->b)
        );
    }

    /**
     * @param DateTimeInterface $value
     * @throws Exception
     */
    public static function pythonDateTimeToCommand($value): Command
    {
        $runtime = RuntimeName::PYTHON();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'datetime.datetime'),
            'fromisoformat',
            TypeParsingWire::toIso($value, false),
        ]);
    }

    public static function pythonUuidToCommand(Uuid $value): Command
    {
        $runtime = RuntimeName::PYTHON();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'uuid'),
            'UUID',
            $value->toString(),
        ]);
    }

    public static function pythonUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::PYTHON();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'urllib.parse'),
            'urlparse',
            $value->toString(),
        ]);
    }

    public static function pythonIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::PYTHON();
        $parts = TypeParsingWire::intervalToSecondsAndMicros($value);

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'datetime.timedelta'),
            0,
            $parts['seconds'],
            $parts['microseconds'],
        ]);
    }

    public static function pythonPointToCommand(Point $value): Command
    {
        return new Command(
            RuntimeName::PYTHON(),
            CommandType::COMPLEX_VALUE_TYPE(),
            'Point',
            $value->x,
            $value->y
        );
    }

    public static function pythonColorToCommand(Color $value): Command
    {
        return new Command(
            RuntimeName::PYTHON(),
            CommandType::COMPLEX_VALUE_TYPE(),
            'Color',
            TypeParsingWire::colorChannel($value->a),
            TypeParsingWire::colorChannel($value->r),
            TypeParsingWire::colorChannel($value->g),
            TypeParsingWire::colorChannel($value->b)
        );
    }

    /**
     * @throws Exception
     */
    public static function rubyDateTimeToCommand(DateTimeInterface $value): Command
    {
        $runtime = RuntimeName::RUBY();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'Time'),
            'parse',
            self::rubyTimeParseIso($value),
        ]);
    }

    public static function rubyUuidToCommand(Uuid $value): Command
    {
        $runtime = RuntimeName::RUBY();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'Hypertube::Utils::Uuid'),
            $value->toString(),
        ]);
    }

    public static function rubyUriToCommand(Uri $value): Command
    {
        $runtime = RuntimeName::RUBY();

        return new Command($runtime, CommandType::INVOKE_STATIC_METHOD(), [
            TypeParsingWire::getTypeCommand($runtime, 'URI'),
            'parse',
            $value->toString(),
        ]);
    }

    public static function rubyIntervalToCommand(DateInterval $value): Command
    {
        $runtime = RuntimeName::RUBY();
        $parts = TypeParsingWire::intervalToSecondsAndMicros($value);

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'Hypertube::Utils::Duration'),
            $parts['milliseconds'],
        ]);
    }

    public static function rubyPointToCommand(Point $value): Command
    {
        $runtime = RuntimeName::RUBY();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'Hypertube::Utils::Point'),
            $value->x,
            $value->y,
        ]);
    }

    public static function rubyColorToCommand(Color $value): Command
    {
        $runtime = RuntimeName::RUBY();

        return new Command($runtime, CommandType::CREATE_INSTANCE(), [
            TypeParsingWire::getTypeCommand($runtime, 'Hypertube::Utils::Color'),
            TypeParsingWire::colorChannel($value->r),
            TypeParsingWire::colorChannel($value->g),
            TypeParsingWire::colorChannel($value->b),
            TypeParsingWire::colorChannel($value->a),
        ]);
    }

    /**
     * @throws Exception
     */
    private static function rubyTimeParseIso(DateTimeInterface $value): string
    {
        if ($value instanceof DateTimeImmutable) {
            $immutable = $value;
        } elseif ($value instanceof DateTime) {
            $immutable = DateTimeImmutable::createFromMutable($value);
        } else {
            $immutable = new DateTimeImmutable($value->format('Y-m-d\TH:i:s.uP'));
        }

        $utc = $immutable->setTimezone(new DateTimeZone('UTC'));

        return $utc->format('Y-m-d\TH:i:s.v') . '+00:00';
    }
}
